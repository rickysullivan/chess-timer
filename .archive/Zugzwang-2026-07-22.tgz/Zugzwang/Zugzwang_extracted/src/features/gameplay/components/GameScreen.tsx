import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/gameplay/components/GameScreen.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5db2b99c"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { RotateCcw, Undo2 } from "/node_modules/.vite/deps/lucide-react.js?v=5db2b99c";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=5db2b99c"; const useCallback = __vite__cjsImport2_react["useCallback"]; const useEffect = __vite__cjsImport2_react["useEffect"]; const useState = __vite__cjsImport2_react["useState"];
import { AlertDialog, Button } from "/node_modules/.vite/deps/@heroui_react.js?v=5db2b99c";
import { formatMs } from "/src/app/types.ts";
export function GameScreen(props) {
  _s();
  const { onDismissOnboarding, onReset } = props;
  const shouldShowOnboardingCue = props.settings.layoutMode === "adaptive" && !props.onboardingSeen;
  const [isResetDialogOpen, setIsResetDialogOpen] = useState(false);
  const isEnded = Boolean(props.timeoutSide);
  const handleReset = useCallback(() => {
    setIsResetDialogOpen(true);
  }, []);
  const handleResetConfirm = useCallback(() => {
    onReset();
  }, [onReset]);
  useEffect(() => {
    if (!shouldShowOnboardingCue) return;
    const timer = window.setTimeout(() => {
      onDismissOnboarding();
    }, 3e3);
    return () => {
      window.clearTimeout(timer);
    };
  }, [onDismissOnboarding, shouldShowOnboardingCue]);
  const activeIndicatorText = `${props.activeSide} to move`;
  const pausedDigitSizeClass = props.settings.largeDigitsMode ? "text-5xl md:text-6xl" : "text-2xl";
  const activeDigitSizeClass = props.settings.largeDigitsMode ? "text-7xl md:text-8xl" : "text-4xl md:text-5xl";
  const inactiveDigitSizeClass = props.settings.largeDigitsMode ? "text-5xl md:text-6xl" : "text-2xl";
  const isPlaying = !props.isPaused && !isEnded;
  const hideChrome = isPlaying;
  return /* @__PURE__ */ jsxDEV("main", { id: "game-screen", className: "flex min-h-screen flex-col bg-slate-100", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-full flex-1 flex-col px-5 py-4 md:py-6", children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          id: "game-chrome",
          className: `transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] ${hideChrome ? "mt-0 max-h-0 overflow-hidden opacity-0" : "mt-0 max-h-40 opacity-100"}`,
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-2", children: [
              /* @__PURE__ */ jsxDEV("div", { id: "game-brand", className: "inline-flex items-center gap-1.5 rounded-full bg-slate-900 px-3 py-1 text-sm font-semibold text-white sm:px-3.5 sm:py-1.5", children: [
                "Zugzwang",
                /* @__PURE__ */ jsxDEV("span", { className: "rounded-full bg-orange-500/25 px-1.5 py-0.5 text-[11px] font-bold text-orange-400 sm:px-2 sm:text-xs", children: props.startedControl.label }, void 0, false, {
                  fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                  lineNumber: 76,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 74,
                columnNumber: 13
              }, this),
              props.headerActions
            ] }, void 0, true, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 73,
              columnNumber: 11
            }, this),
            props.actionMessage ? /* @__PURE__ */ jsxDEV(
              "p",
              {
                id: "game-action-message",
                className: `mt-2 text-sm ${props.actionMessage.tone === "success" ? "text-emerald-700" : props.actionMessage.tone === "error" ? "text-red-600" : "text-slate-600"}`,
                role: "status",
                "aria-live": "polite",
                children: props.actionMessage.text
              },
              void 0,
              false,
              {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 83,
                columnNumber: 11
              },
              this
            ) : null,
            shouldShowOnboardingCue ? /* @__PURE__ */ jsxDEV("div", { id: "game-onboarding", className: "mt-3 flex items-start justify-between gap-3 rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-900", children: [
              /* @__PURE__ */ jsxDEV("p", { children: "Tap your side to switch. Tap the small strip to pause." }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 100,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: props.onDismissOnboarding,
                  "aria-label": "Dismiss onboarding tip",
                  className: "inline-flex items-center justify-center rounded-md border border-sky-300 bg-white px-2 py-1 text-xs font-semibold uppercase tracking-[0.08em] text-sky-800 transition hover:bg-sky-100",
                  children: "Dismiss"
                },
                void 0,
                false,
                {
                  fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                  lineNumber: 101,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 99,
              columnNumber: 11
            }, this) : null,
            props.warningBanner
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
          lineNumber: 67,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("p", { className: "sr-only", "aria-live": "polite", "aria-atomic": "true", children: props.liveAnnouncement }, void 0, false, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
        lineNumber: 114,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { id: "game-timers", className: `flex flex-1 flex-col min-h-0 ${hideChrome ? "mt-0" : "mt-4"} transition-[margin] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)]`, children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] ${hideChrome ? "max-h-0 overflow-hidden opacity-0" : "max-h-6 opacity-100"}`,
            children: /* @__PURE__ */ jsxDEV("p", { id: "game-active-indicator", className: "text-xs font-semibold uppercase tracking-[0.12em] text-slate-500", children: activeIndicatorText }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 124,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
            lineNumber: 119,
            columnNumber: 11
          },
          this
        ),
        props.activeDelayRemainingMs > 0 && !props.isPaused && !props.timeoutSide ? /* @__PURE__ */ jsxDEV("p", { id: "game-delay-indicator", className: "mt-0.5 text-xs font-medium uppercase tracking-[0.12em] text-slate-500", "aria-live": "polite", children: [
          "Delay: ",
          (props.activeDelayRemainingMs / 1e3).toFixed(1),
          "s"
        ] }, void 0, true, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
          lineNumber: 127,
          columnNumber: 11
        }, this) : null,
        props.isPaused && !isEnded ? /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex flex-1 flex-col gap-3 animate-fade-in", "aria-live": "polite", children: [
          /* @__PURE__ */ jsxDEV("div", { className: `flex flex-1 gap-5 ${props.settings.layoutMode === "classic" ? "flex-col sm:flex-row" : "flex-col md:flex-row"}`, role: "group", "aria-label": "Paused timers", children: [
            /* @__PURE__ */ jsxDEV("div", { className: `flex flex-1 flex-col justify-center rounded-xl border px-4 py-4 ${props.settings.layoutMode === "classic" ? "items-center text-center" : "text-left"} ${props.settings.highContrastMode ? "border-2 border-slate-800 bg-white text-slate-900" : "border border-slate-200 bg-slate-50 text-slate-900"}`, children: /* @__PURE__ */ jsxDEV("div", { className: "rotate-180", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.12em] text-slate-500", children: "Black" }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 137,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: `mt-1 font-semibold tabular-nums ${pausedDigitSizeClass}`, children: formatMs(props.remainingMs.Black) }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 138,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 136,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 135,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: `flex flex-1 flex-col justify-center rounded-xl border px-4 py-4 ${props.settings.layoutMode === "classic" ? "items-center text-center" : "text-left"} ${props.settings.highContrastMode ? "border-2 border-slate-800 bg-white text-slate-900" : "border border-slate-200 bg-slate-50 text-slate-900"}`, children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.12em] text-slate-500", children: "White" }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 144,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: `mt-1 font-semibold tabular-nums ${pausedDigitSizeClass}`, children: formatMs(props.remainingMs.White) }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 145,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 143,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
            lineNumber: 134,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              className: "w-full",
              onPress: props.onPauseResume,
              "aria-label": `Resume game with ${props.activeSide} to move`,
              children: [
                "Resume (",
                props.activeSide,
                " to move)"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 150,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
          lineNumber: 133,
          columnNumber: 11
        }, this) : isEnded ? /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex flex-1 flex-col gap-3 animate-fade-in", "aria-live": "polite", children: [
          /* @__PURE__ */ jsxDEV("div", { className: `flex flex-1 gap-5 ${props.settings.layoutMode === "classic" ? "flex-col sm:flex-row" : "flex-col md:flex-row"}`, role: "group", "aria-label": "Game ended timers", children: [
            /* @__PURE__ */ jsxDEV("div", { className: `flex flex-1 flex-col justify-center rounded-xl border px-4 py-4 ${props.settings.layoutMode === "classic" ? "items-center text-center" : "text-left"} ${props.timeoutSide === "Black" ? "border border-slate-200 bg-slate-100 opacity-60" : "border-2 border-emerald-400 bg-emerald-50 text-emerald-900"}`, children: /* @__PURE__ */ jsxDEV("div", { className: "rotate-180", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.12em] text-slate-500", children: "Black" }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 163,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: `mt-1 font-semibold tabular-nums ${pausedDigitSizeClass} ${props.timeoutSide === "Black" ? "line-through" : ""}`, children: formatMs(props.remainingMs.Black) }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 164,
                columnNumber: 21
              }, this),
              props.timeoutSide === "Black" ? /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs font-semibold uppercase tracking-[0.12em] text-red-600", children: "Time Out" }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 168,
                columnNumber: 19
              }, this) : null
            ] }, void 0, true, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 162,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 161,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: `flex flex-1 flex-col justify-center rounded-xl border px-4 py-4 ${props.settings.layoutMode === "classic" ? "items-center text-center" : "text-left"} ${props.timeoutSide === "White" ? "border border-slate-200 bg-slate-100 opacity-60" : "border-2 border-emerald-400 bg-emerald-50 text-emerald-900"}`, children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.12em] text-slate-500", children: "White" }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 173,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: `mt-1 font-semibold tabular-nums ${pausedDigitSizeClass} ${props.timeoutSide === "White" ? "line-through" : ""}`, children: formatMs(props.remainingMs.White) }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 174,
                columnNumber: 19
              }, this),
              props.timeoutSide === "White" ? /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs font-semibold uppercase tracking-[0.12em] text-red-600", children: "Time Out" }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 178,
                columnNumber: 17
              }, this) : null
            ] }, void 0, true, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 172,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
            lineNumber: 160,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-center text-sm font-semibold text-red-600", role: "alert", children: [
            props.timeoutSide,
            " ran out of time.",
            " ",
            props.timeoutSide === "White" ? "Black wins!" : "White wins!"
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
            lineNumber: 182,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2", role: "group", "aria-label": "Game end controls", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: "outline",
                onPress: props.onBackToSetup,
                "aria-label": "Return to setup screen",
                children: "Back to Setup"
              },
              void 0,
              false,
              {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 187,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: "danger-soft",
                onPress: handleReset,
                "aria-label": "Reset game to initial time control",
                children: [
                  /* @__PURE__ */ jsxDEV(RotateCcw, { className: "mr-2 size-4" }, void 0, false, {
                    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                    lineNumber: 199,
                    columnNumber: 19
                  }, this),
                  "Reset"
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 194,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
            lineNumber: 186,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
          lineNumber: 159,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `flex flex-1 min-h-0 gap-5 ${hideChrome ? "mt-0" : "mt-3"} transition-[margin] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] ${props.settings.layoutMode === "adaptive" ? "flex-col md:h-auto md:flex-row" : "flex-col sm:flex-row"} ${props.settings.highContrastMode ? "border-2 border-slate-900 bg-slate-50 p-2" : ""}`,
            "aria-live": "polite",
            children: props.settings.layoutMode === "classic" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  id: "timer-black",
                  onClick: () => props.onSideTap("Black"),
                  disabled: isEnded,
                  "aria-label": `Black ${props.activeSide === "Black" ? "active" : "inactive"} timer. ${formatMs(props.remainingMs.Black)}. ${props.activeSide === "Black" ? "Tap to pass turn." : "Tap to pause game."}`,
                  className: `flex flex-1 flex-col items-center justify-center rounded-3xl px-4 py-4 text-center transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring ${props.settings.highContrastMode ? props.activeSide === "Black" ? "border-2 border-slate-950 bg-amber-200 text-slate-950 hover:bg-amber-300" : "border-2 border-slate-700 bg-white text-slate-800 hover:bg-slate-100" : props.activeSide === "Black" ? "border border-orange-200 bg-orange-50 text-slate-900 hover:bg-orange-100" : "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`,
                  children: /* @__PURE__ */ jsxDEV("div", { className: "rotate-180", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.12em]", children: [
                      "Black",
                      props.activeSide === "Black" ? " (active)" : ""
                    ] }, void 0, true, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 230,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: `mt-2 font-semibold tabular-nums ${activeDigitSizeClass}`, children: formatMs(props.remainingMs.Black) }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 231,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs font-medium uppercase tracking-[0.12em] text-slate-500", children: props.activeSide === "Black" ? "Tap to pass turn" : "Tap to pause" }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 234,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                    lineNumber: 229,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                  lineNumber: 213,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  id: "timer-white",
                  onClick: () => props.onSideTap("White"),
                  disabled: isEnded,
                  "aria-label": `White ${props.activeSide === "White" ? "active" : "inactive"} timer. ${formatMs(props.remainingMs.White)}. ${props.activeSide === "White" ? "Tap to pass turn." : "Tap to pause game."}`,
                  className: `flex flex-1 flex-col items-center justify-center rounded-3xl px-4 py-4 text-center transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring ${props.settings.highContrastMode ? props.activeSide === "White" ? "border-2 border-slate-950 bg-amber-200 text-slate-950 hover:bg-amber-300" : "border-2 border-slate-700 bg-white text-slate-800 hover:bg-slate-100" : props.activeSide === "White" ? "border border-orange-200 bg-orange-50 text-slate-900 hover:bg-orange-100" : "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`,
                  children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.12em]", children: [
                      "White",
                      props.activeSide === "White" ? " (active)" : ""
                    ] }, void 0, true, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 254,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: `mt-2 font-semibold tabular-nums ${activeDigitSizeClass}`, children: formatMs(props.remainingMs.White) }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 255,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs font-medium uppercase tracking-[0.12em] text-slate-500", children: props.activeSide === "White" ? "Tap to pass turn" : "Tap to pause" }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 258,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                  lineNumber: 238,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 212,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  id: "timer-black",
                  onClick: () => props.onSideTap("Black"),
                  disabled: isEnded,
                  "aria-label": `Black ${props.activeSide === "Black" ? "active" : "inactive"} timer. ${formatMs(props.remainingMs.Black)}. ${props.activeSide === "Black" ? "Tap to pass turn." : "Tap to pause game."}`,
                  className: `flex transition-all duration-200 ease-in-out ${props.activeSide === "Black" ? "flex-[3]" : "flex-1"} flex-col justify-center rounded-3xl px-4 ${props.activeSide === "Black" ? "py-4" : "py-3"} text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring ${props.settings.highContrastMode ? props.activeSide === "Black" ? "border-2 border-slate-950 bg-amber-200 text-slate-950 hover:bg-amber-300" : "border-2 border-slate-700 bg-white text-slate-800 hover:bg-slate-100" : props.activeSide === "Black" ? "border border-orange-200 bg-orange-50 text-slate-900 hover:bg-orange-100" : "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`,
                  children: /* @__PURE__ */ jsxDEV("div", { className: "rotate-180", children: props.activeSide === "Black" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.12em]", children: "Black (active)" }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 284,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: `mt-2 font-semibold tabular-nums ${activeDigitSizeClass}`, children: formatMs(props.remainingMs.Black) }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 285,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs font-medium uppercase tracking-[0.12em] text-slate-500", children: "Tap to pass turn" }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 288,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                    lineNumber: 283,
                    columnNumber: 19
                  }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.12em]", children: "Black" }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 292,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: `mt-1 font-semibold tabular-nums text-slate-900 ${inactiveDigitSizeClass}`, children: formatMs(props.remainingMs.Black) }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 293,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs font-medium uppercase tracking-[0.12em] text-slate-500", children: "Tap to pause" }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 296,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                    lineNumber: 291,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                    lineNumber: 281,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                  lineNumber: 263,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  id: "timer-white",
                  onClick: () => props.onSideTap("White"),
                  disabled: isEnded,
                  "aria-label": `White ${props.activeSide === "White" ? "active" : "inactive"} timer. ${formatMs(props.remainingMs.White)}. ${props.activeSide === "White" ? "Tap to pass turn." : "Tap to pause game."}`,
                  className: `flex transition-all duration-200 ease-in-out ${props.activeSide === "White" ? "flex-[3]" : "flex-1"} flex-col justify-center rounded-3xl px-4 ${props.activeSide === "White" ? "py-4" : "py-3"} text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring ${props.settings.highContrastMode ? props.activeSide === "White" ? "border-2 border-slate-950 bg-amber-200 text-slate-950 hover:bg-amber-300" : "border-2 border-slate-700 bg-white text-slate-800 hover:bg-slate-100" : props.activeSide === "White" ? "border border-orange-200 bg-orange-50 text-slate-900 hover:bg-orange-100" : "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`,
                  children: props.activeSide === "White" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.12em]", children: "White (active)" }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 322,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: `mt-2 font-semibold tabular-nums ${activeDigitSizeClass}`, children: formatMs(props.remainingMs.White) }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 323,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs font-medium uppercase tracking-[0.12em] text-slate-500", children: "Tap to pass turn" }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 326,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                    lineNumber: 321,
                    columnNumber: 17
                  }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.12em]", children: "White" }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 330,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: `mt-1 font-semibold tabular-nums text-slate-900 ${inactiveDigitSizeClass}`, children: formatMs(props.remainingMs.White) }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 331,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs font-medium uppercase tracking-[0.12em] text-slate-500", children: "Tap to pause" }, void 0, false, {
                      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                      lineNumber: 334,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                    lineNumber: 329,
                    columnNumber: 17
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                  lineNumber: 302,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 262,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
            lineNumber: 205,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
        lineNumber: 118,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          id: "game-controls",
          className: `transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] ${hideChrome ? "max-h-0 overflow-hidden opacity-0" : "max-h-40 opacity-100"}`,
          children: [
            !isEnded && props.isPaused ? /* @__PURE__ */ jsxDEV("div", { id: "game-pause-controls", className: "mt-4 grid grid-cols-2 gap-2", role: "group", "aria-label": "Paused game controls", children: [
              /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onPress: props.onUndo, isDisabled: !props.canUndo, "aria-label": "Undo last turn switch", className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(Undo2, { className: "mr-2 size-4" }, void 0, false, {
                  fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                  lineNumber: 353,
                  columnNumber: 17
                }, this),
                "Undo"
              ] }, void 0, true, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 352,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onPress: handleReset, "aria-label": "Reset game to initial time control", className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(RotateCcw, { className: "mr-2 size-4" }, void 0, false, {
                  fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                  lineNumber: 357,
                  columnNumber: 17
                }, this),
                "Reset"
              ] }, void 0, true, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
                lineNumber: 356,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 351,
              columnNumber: 11
            }, this) : null,
            !isEnded ? /* @__PURE__ */ jsxDEV("div", { id: "game-back-to-setup", className: "pt-4", children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onPress: props.onBackToSetup, "aria-label": "Return to setup screen", className: "w-full", children: "Back to Setup" }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 365,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
              lineNumber: 364,
              columnNumber: 11
            }, this) : null
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
          lineNumber: 344,
          columnNumber: 1
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
      lineNumber: 66,
      columnNumber: 7
    }, this),
    props.settingsDrawer,
    /* @__PURE__ */ jsxDEV(AlertDialog, { children: /* @__PURE__ */ jsxDEV(AlertDialog.Backdrop, { isOpen: isResetDialogOpen, onOpenChange: setIsResetDialogOpen, isDismissable: true, children: /* @__PURE__ */ jsxDEV(AlertDialog.Container, { children: /* @__PURE__ */ jsxDEV(AlertDialog.Dialog, { className: "sm:max-w-[400px]", children: [
      /* @__PURE__ */ jsxDEV(AlertDialog.Header, { children: /* @__PURE__ */ jsxDEV(AlertDialog.Heading, { className: "text-lg font-semibold text-slate-900", children: "Reset game?" }, void 0, false, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
        lineNumber: 379,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
        lineNumber: 378,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(AlertDialog.Body, { children: /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600", children: "This will reset the game and clear undo history. This action cannot be undone." }, void 0, false, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
        lineNumber: 382,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
        lineNumber: 381,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(AlertDialog.Footer, { className: "flex-col-reverse sm:flex-row", children: [
        /* @__PURE__ */ jsxDEV(Button, { slot: "close", variant: "tertiary", className: "w-full sm:w-auto text-slate-700", children: "Cancel" }, void 0, false, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
          lineNumber: 387,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { slot: "close", variant: "danger", onPress: handleResetConfirm, className: "w-full sm:w-auto", children: "Reset" }, void 0, false, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
          lineNumber: 390,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
        lineNumber: 386,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
      lineNumber: 377,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
      lineNumber: 376,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
      lineNumber: 375,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
      lineNumber: 374,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx",
    lineNumber: 65,
    columnNumber: 5
  }, this);
}
_s(GameScreen, "oKCA2R3oOu918bKtTQBqZaB2JzA=");
_c = GameScreen;
var _c;
$RefreshReg$(_c, "GameScreen");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/rickysullivan/Projects/chess-timer/src/features/gameplay/components/GameScreen.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkVjLFNBd0lFLFVBeElGOztBQTNFZCxTQUFTQSxXQUFXQyxhQUFhO0FBQ2pDLFNBQVNDLGFBQWFDLFdBQVdDLGdCQUFnQztBQUNqRSxTQUFTQyxhQUFhQyxjQUFjO0FBQ3BDLFNBQVNDLGdCQUF1RjtBQXlCekYsZ0JBQVNDLFdBQVdDLE9BQXdCO0FBQUFDLEtBQUE7QUFDakQsUUFBTSxFQUFFQyxxQkFBcUJDLFFBQVEsSUFBSUg7QUFFekMsUUFBTUksMEJBQTBCSixNQUFNSyxTQUFTQyxlQUFlLGNBQWMsQ0FBQ04sTUFBTU87QUFDbkYsUUFBTSxDQUFDQyxtQkFBbUJDLG9CQUFvQixJQUFJZCxTQUFTLEtBQUs7QUFDaEUsUUFBTWUsVUFBVUMsUUFBUVgsTUFBTVksV0FBVztBQUV6QyxRQUFNQyxjQUFjcEIsWUFBWSxNQUFNO0FBQ3BDZ0IseUJBQXFCLElBQUk7QUFBQSxFQUMzQixHQUFHLEVBQUU7QUFFTCxRQUFNSyxxQkFBcUJyQixZQUFZLE1BQU07QUFDM0NVLFlBQVE7QUFBQSxFQUNWLEdBQUcsQ0FBQ0EsT0FBTyxDQUFDO0FBRVpULFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ1Usd0JBQXlCO0FBRTlCLFVBQU1XLFFBQVFDLE9BQU9DLFdBQVcsTUFBTTtBQUNwQ2YsMEJBQW9CO0FBQUEsSUFDdEIsR0FBRyxHQUFJO0FBRVAsV0FBTyxNQUFNO0FBQ1hjLGFBQU9FLGFBQWFILEtBQUs7QUFBQSxJQUMzQjtBQUFBLEVBQ0YsR0FBRyxDQUFDYixxQkFBcUJFLHVCQUF1QixDQUFDO0FBRWpELFFBQU1lLHNCQUFzQixHQUFHbkIsTUFBTW9CLFVBQVU7QUFDL0MsUUFBTUMsdUJBQXVCckIsTUFBTUssU0FBU2lCLGtCQUFrQix5QkFBeUI7QUFDdkYsUUFBTUMsdUJBQXVCdkIsTUFBTUssU0FBU2lCLGtCQUFrQix5QkFBeUI7QUFDdkYsUUFBTUUseUJBQXlCeEIsTUFBTUssU0FBU2lCLGtCQUFrQix5QkFBeUI7QUFFekYsUUFBTUcsWUFBWSxDQUFDekIsTUFBTTBCLFlBQVksQ0FBQ2hCO0FBQ3RDLFFBQU1pQixhQUFhRjtBQUVuQixTQUNFLHVCQUFDLFVBQUssSUFBRyxlQUFjLFdBQVUsMkNBQy9CO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLElBQUc7QUFBQSxVQUNILFdBQVcsZ0VBQ1RFLGFBQWEsMkNBQTJDLDJCQUEyQjtBQUFBLFVBR3JGO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxJQUFHLGNBQWEsV0FBVSw2SEFBMkg7QUFBQTtBQUFBLGdCQUV4Six1QkFBQyxVQUFLLFdBQVUsd0dBQ2IzQixnQkFBTTRCLGVBQWVDLFNBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQzdCLE1BQU04QjtBQUFBQSxpQkFQVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFDQzlCLE1BQU0rQixnQkFDTDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLElBQUc7QUFBQSxnQkFDSCxXQUFXLGdCQUNUL0IsTUFBTStCLGNBQWNDLFNBQVMsWUFDekIscUJBQ0FoQyxNQUFNK0IsY0FBY0MsU0FBUyxVQUMzQixpQkFDQSxnQkFBZ0I7QUFBQSxnQkFFeEIsTUFBSztBQUFBLGdCQUNMLGFBQVU7QUFBQSxnQkFFVGhDLGdCQUFNK0IsY0FBY0U7QUFBQUE7QUFBQUEsY0FadkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYUEsSUFDRTtBQUFBLFlBQ0g3QiwwQkFDQyx1QkFBQyxTQUFJLElBQUcsbUJBQWtCLFdBQVUseUhBQ2xDO0FBQUEscUNBQUMsT0FBRSxzRUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGNBQ3pEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTSixNQUFNRTtBQUFBQSxrQkFDZixjQUFXO0FBQUEsa0JBQ1gsV0FBVTtBQUFBLGtCQUF3TDtBQUFBO0FBQUEsZ0JBSnBNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQSxJQUNFO0FBQUEsWUFDSEYsTUFBTWtDO0FBQUFBO0FBQUFBO0FBQUFBLFFBNUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTZDQTtBQUFBLE1BRUEsdUJBQUMsT0FBRSxXQUFVLFdBQVUsYUFBVSxVQUFTLGVBQVksUUFDbkRsQyxnQkFBTW1DLG9CQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxJQUFHLGVBQWMsV0FBVyxnQ0FBZ0NSLGFBQWEsU0FBUyxNQUFNLHNFQUMzRjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXLGdFQUNUQSxhQUFhLHNDQUFzQyxxQkFBcUI7QUFBQSxZQUcxRSxpQ0FBQyxPQUFFLElBQUcseUJBQXdCLFdBQVUsb0VBQW9FUixpQ0FBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0k7QUFBQTtBQUFBLFVBTGxJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQ25CLE1BQU1vQyx5QkFBeUIsS0FBSyxDQUFDcEMsTUFBTTBCLFlBQVksQ0FBQzFCLE1BQU1ZLGNBQzdELHVCQUFDLE9BQUUsSUFBRyx3QkFBdUIsV0FBVSx5RUFBd0UsYUFBVSxVQUFRO0FBQUE7QUFBQSxXQUN0SFosTUFBTW9DLHlCQUF5QixLQUFNQyxRQUFRLENBQUM7QUFBQSxVQUFFO0FBQUEsYUFEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBQ0U7QUFBQSxRQUVIckMsTUFBTTBCLFlBQVksQ0FBQ2hCLFVBQ2xCLHVCQUFDLFNBQUksV0FBVSxtREFBa0QsYUFBVSxVQUN6RTtBQUFBLGlDQUFDLFNBQUksV0FBVyxxQkFBcUJWLE1BQU1LLFNBQVNDLGVBQWUsWUFBWSx5QkFBeUIsc0JBQXNCLElBQUksTUFBSyxTQUFRLGNBQVcsaUJBQ3hKO0FBQUEsbUNBQUMsU0FBSSxXQUFXLG1FQUFtRU4sTUFBTUssU0FBU0MsZUFBZSxZQUFZLDZCQUE2QixXQUFXLElBQUlOLE1BQU1LLFNBQVNpQyxtQkFBbUIsc0RBQXNELG9EQUFvRCxJQUNuVCxpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSxvRUFBbUUscUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFGO0FBQUEsY0FDckYsdUJBQUMsT0FBRSxXQUFXLG1DQUFtQ2pCLG9CQUFvQixJQUNsRXZCLG1CQUFTRSxNQUFNdUMsWUFBWUMsS0FBSyxLQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVyxtRUFBbUV4QyxNQUFNSyxTQUFTQyxlQUFlLFlBQVksNkJBQTZCLFdBQVcsSUFBSU4sTUFBTUssU0FBU2lDLG1CQUFtQixzREFBc0Qsb0RBQW9ELElBQ25UO0FBQUEscUNBQUMsT0FBRSxXQUFVLG9FQUFtRSxxQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUY7QUFBQSxjQUNyRix1QkFBQyxPQUFFLFdBQVcsbUNBQW1DakIsb0JBQW9CLElBQ2xFdkIsbUJBQVNFLE1BQU11QyxZQUFZRSxLQUFLLEtBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBU3pDLE1BQU0wQztBQUFBQSxjQUNmLGNBQVksb0JBQW9CMUMsTUFBTW9CLFVBQVU7QUFBQSxjQUFXO0FBQUE7QUFBQSxnQkFFbERwQixNQUFNb0I7QUFBQUEsZ0JBQVc7QUFBQTtBQUFBO0FBQUEsWUFMNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBLElBQ0VWLFVBQ0YsdUJBQUMsU0FBSSxXQUFVLG1EQUFrRCxhQUFVLFVBQ3pFO0FBQUEsaUNBQUMsU0FBSSxXQUFXLHFCQUFxQlYsTUFBTUssU0FBU0MsZUFBZSxZQUFZLHlCQUF5QixzQkFBc0IsSUFBSSxNQUFLLFNBQVEsY0FBVyxxQkFDeEo7QUFBQSxtQ0FBQyxTQUFJLFdBQVcsbUVBQW1FTixNQUFNSyxTQUFTQyxlQUFlLFlBQVksNkJBQTZCLFdBQVcsSUFBSU4sTUFBTVksZ0JBQWdCLFVBQVUsb0RBQW9ELDREQUE0RCxJQUN2VCxpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSxvRUFBbUUscUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFGO0FBQUEsY0FDckYsdUJBQUMsT0FBRSxXQUFXLG1DQUFtQ1Msb0JBQW9CLElBQUlyQixNQUFNWSxnQkFBZ0IsVUFBVSxpQkFBaUIsRUFBRSxJQUN6SGQsbUJBQVNFLE1BQU11QyxZQUFZQyxLQUFLLEtBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNDeEMsTUFBTVksZ0JBQWdCLFVBQ3JCLHVCQUFDLE9BQUUsV0FBVSx1RUFBc0Usd0JBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJGLElBQ3pGO0FBQUEsaUJBUE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVyxtRUFBbUVaLE1BQU1LLFNBQVNDLGVBQWUsWUFBWSw2QkFBNkIsV0FBVyxJQUFJTixNQUFNWSxnQkFBZ0IsVUFBVSxvREFBb0QsNERBQTRELElBQ3ZUO0FBQUEscUNBQUMsT0FBRSxXQUFVLG9FQUFtRSxxQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUY7QUFBQSxjQUNyRix1QkFBQyxPQUFFLFdBQVcsbUNBQW1DUyxvQkFBb0IsSUFBSXJCLE1BQU1ZLGdCQUFnQixVQUFVLGlCQUFpQixFQUFFLElBQ3pIZCxtQkFBU0UsTUFBTXVDLFlBQVlFLEtBQUssS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0N6QyxNQUFNWSxnQkFBZ0IsVUFDckIsdUJBQUMsT0FBRSxXQUFVLHVFQUFzRSx3QkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkYsSUFDekY7QUFBQSxpQkFQTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxrREFBaUQsTUFBSyxTQUNoRVo7QUFBQUEsa0JBQU1ZO0FBQUFBLFlBQVk7QUFBQSxZQUFrQjtBQUFBLFlBQ3BDWixNQUFNWSxnQkFBZ0IsVUFBVSxnQkFBZ0I7QUFBQSxlQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQXlCLE1BQUssU0FBUSxjQUFXLHFCQUM5RDtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLFNBQVNaLE1BQU0yQztBQUFBQSxnQkFDZixjQUFXO0FBQUEsZ0JBQXdCO0FBQUE7QUFBQSxjQUhyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFRO0FBQUEsZ0JBQ1IsU0FBUzlCO0FBQUFBLGdCQUNULGNBQVc7QUFBQSxnQkFFWDtBQUFBLHlDQUFDLGFBQVUsV0FBVSxpQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUxwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLGVBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxhQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNENBLElBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVcsNkJBQTZCYyxhQUFhLFNBQVMsTUFBTSxzRUFDbEUzQixNQUFNSyxTQUFTQyxlQUFlLGFBQWEsbUNBQW1DLHNCQUFzQixJQUNsR04sTUFBTUssU0FBU2lDLG1CQUFtQiw4Q0FBOEMsRUFBRTtBQUFBLFlBQ3RGLGFBQVU7QUFBQSxZQUVUdEMsZ0JBQU1LLFNBQVNDLGVBQWUsWUFDN0IsbUNBQ0U7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsSUFBRztBQUFBLGtCQUNILFNBQVMsTUFBTU4sTUFBTTRDLFVBQVUsT0FBTztBQUFBLGtCQUN0QyxVQUFVbEM7QUFBQUEsa0JBQ1YsY0FBWSxTQUFTVixNQUFNb0IsZUFBZSxVQUFVLFdBQVcsVUFBVSxXQUFXdEIsU0FBU0UsTUFBTXVDLFlBQVlDLEtBQUssQ0FBQyxLQUFLeEMsTUFBTW9CLGVBQWUsVUFBVSxzQkFBc0Isb0JBQW9CO0FBQUEsa0JBQ25NLFdBQVcsbUxBQ1RwQixNQUFNSyxTQUFTaUMsbUJBQ1h0QyxNQUFNb0IsZUFBZSxVQUNuQiw2RUFDQSx5RUFDRnBCLE1BQU1vQixlQUFlLFVBQ25CLDZFQUNBLG1FQUFtRTtBQUFBLGtCQUczRSxpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSxxREFBb0Q7QUFBQTtBQUFBLHNCQUFNcEIsTUFBTW9CLGVBQWUsVUFBVSxjQUFjO0FBQUEseUJBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVIO0FBQUEsb0JBQ3ZILHVCQUFDLE9BQUUsV0FBVyxtQ0FBbUNHLG9CQUFvQixJQUNsRXpCLG1CQUFTRSxNQUFNdUMsWUFBWUMsS0FBSyxLQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHVFQUF1RXhDLGdCQUFNb0IsZUFBZSxVQUFVLHFCQUFxQixrQkFBeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUo7QUFBQSx1QkFMeko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUEsZ0JBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXVCQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLElBQUc7QUFBQSxrQkFDSCxTQUFTLE1BQU1wQixNQUFNNEMsVUFBVSxPQUFPO0FBQUEsa0JBQ3RDLFVBQVVsQztBQUFBQSxrQkFDVixjQUFZLFNBQVNWLE1BQU1vQixlQUFlLFVBQVUsV0FBVyxVQUFVLFdBQVd0QixTQUFTRSxNQUFNdUMsWUFBWUUsS0FBSyxDQUFDLEtBQUt6QyxNQUFNb0IsZUFBZSxVQUFVLHNCQUFzQixvQkFBb0I7QUFBQSxrQkFDbk0sV0FBVyxtTEFDVHBCLE1BQU1LLFNBQVNpQyxtQkFDWHRDLE1BQU1vQixlQUFlLFVBQ25CLDZFQUNBLHlFQUNGcEIsTUFBTW9CLGVBQWUsVUFDbkIsNkVBQ0EsbUVBQW1FO0FBQUEsa0JBRzNFO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHFEQUFvRDtBQUFBO0FBQUEsc0JBQU1wQixNQUFNb0IsZUFBZSxVQUFVLGNBQWM7QUFBQSx5QkFBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUg7QUFBQSxvQkFDdkgsdUJBQUMsT0FBRSxXQUFXLG1DQUFtQ0csb0JBQW9CLElBQ2xFekIsbUJBQVNFLE1BQU11QyxZQUFZRSxLQUFLLEtBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUsdUVBQXVFekMsZ0JBQU1vQixlQUFlLFVBQVUscUJBQXFCLGtCQUF4STtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1SjtBQUFBO0FBQUE7QUFBQSxnQkFwQnpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXFCQTtBQUFBLGlCQS9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdEQSxJQUVBLG1DQUNFO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLElBQUc7QUFBQSxrQkFDSCxTQUFTLE1BQU1wQixNQUFNNEMsVUFBVSxPQUFPO0FBQUEsa0JBQ3RDLFVBQVVsQztBQUFBQSxrQkFDVixjQUFZLFNBQVNWLE1BQU1vQixlQUFlLFVBQVUsV0FBVyxVQUFVLFdBQVd0QixTQUFTRSxNQUFNdUMsWUFBWUMsS0FBSyxDQUFDLEtBQUt4QyxNQUFNb0IsZUFBZSxVQUFVLHNCQUFzQixvQkFBb0I7QUFBQSxrQkFDbk0sV0FBVyxnREFDVHBCLE1BQU1vQixlQUFlLFVBQVUsYUFBYSxRQUFRLDZDQUNUcEIsTUFBTW9CLGVBQWUsVUFBVSxTQUFTLE1BQU0sZ0dBQ3pGcEIsTUFBTUssU0FBU2lDLG1CQUNYdEMsTUFBTW9CLGVBQWUsVUFDbkIsNkVBQ0EseUVBQ0ZwQixNQUFNb0IsZUFBZSxVQUNuQiw2RUFDQSxtRUFBbUU7QUFBQSxrQkFHM0UsaUNBQUMsU0FBSSxXQUFVLGNBQ1pwQixnQkFBTW9CLGVBQWUsVUFDcEIsbUNBQ0U7QUFBQSwyQ0FBQyxPQUFFLFdBQVUscURBQW9ELDhCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErRTtBQUFBLG9CQUMvRSx1QkFBQyxPQUFFLFdBQVcsbUNBQW1DRyxvQkFBb0IsSUFDbEV6QixtQkFBU0UsTUFBTXVDLFlBQVlDLEtBQUssS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSx1RUFBc0UsZ0NBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1HO0FBQUEsdUJBTHJHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUEsSUFFQSxtQ0FDRTtBQUFBLDJDQUFDLE9BQUUsV0FBVSxxREFBb0QscUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNFO0FBQUEsb0JBQ3RFLHVCQUFDLE9BQUUsV0FBVyxrREFBa0RoQixzQkFBc0IsSUFDbkYxQixtQkFBU0UsTUFBTXVDLFlBQVlDLEtBQUssS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSx1RUFBc0UsNEJBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStGO0FBQUEsdUJBTGpHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUEsS0FoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFrQkE7QUFBQTtBQUFBLGdCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FxQ0E7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxJQUFHO0FBQUEsa0JBQ0gsU0FBUyxNQUFNeEMsTUFBTTRDLFVBQVUsT0FBTztBQUFBLGtCQUN0QyxVQUFVbEM7QUFBQUEsa0JBQ1YsY0FBWSxTQUFTVixNQUFNb0IsZUFBZSxVQUFVLFdBQVcsVUFBVSxXQUFXdEIsU0FBU0UsTUFBTXVDLFlBQVlFLEtBQUssQ0FBQyxLQUFLekMsTUFBTW9CLGVBQWUsVUFBVSxzQkFBc0Isb0JBQW9CO0FBQUEsa0JBQ25NLFdBQVcsZ0RBQ1RwQixNQUFNb0IsZUFBZSxVQUFVLGFBQWEsUUFBUSw2Q0FDVHBCLE1BQU1vQixlQUFlLFVBQVUsU0FBUyxNQUFNLGdHQUN6RnBCLE1BQU1LLFNBQVNpQyxtQkFDWHRDLE1BQU1vQixlQUFlLFVBQ25CLDZFQUNBLHlFQUNGcEIsTUFBTW9CLGVBQWUsVUFDbkIsNkVBQ0EsbUVBQW1FO0FBQUEsa0JBRzFFcEIsZ0JBQU1vQixlQUFlLFVBQ3BCLG1DQUNFO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHFEQUFvRCw4QkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0U7QUFBQSxvQkFDL0UsdUJBQUMsT0FBRSxXQUFXLG1DQUFtQ0csb0JBQW9CLElBQ2xFekIsbUJBQVNFLE1BQU11QyxZQUFZRSxLQUFLLEtBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUsdUVBQXNFLGdDQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtRztBQUFBLHVCQUxyRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BLElBRUEsbUNBQ0U7QUFBQSwyQ0FBQyxPQUFFLFdBQVUscURBQW9ELHFCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFzRTtBQUFBLG9CQUN0RSx1QkFBQyxPQUFFLFdBQVcsa0RBQWtEakIsc0JBQXNCLElBQ25GMUIsbUJBQVNFLE1BQU11QyxZQUFZRSxLQUFLLEtBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUsdUVBQXNFLDRCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErRjtBQUFBLHVCQUxqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUE7QUFBQSxnQkFqQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUNBO0FBQUEsaUJBM0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEVBO0FBQUE7QUFBQSxVQXJJSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUF1SUE7QUFBQSxXQTlOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ09BO0FBQUEsTUFFUjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ1MsSUFBRztBQUFBLFVBQ0gsV0FBVyxnRUFDVGQsYUFBYSxzQ0FBc0Msc0JBQXNCO0FBQUEsVUFHMUU7QUFBQSxhQUFDakIsV0FBV1YsTUFBTTBCLFdBQ2pCLHVCQUFDLFNBQUksSUFBRyx1QkFBc0IsV0FBVSwrQkFBOEIsTUFBSyxTQUFRLGNBQVcsd0JBQzVGO0FBQUEscUNBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUzFCLE1BQU02QyxRQUFRLFlBQVksQ0FBQzdDLE1BQU04QyxTQUFTLGNBQVcseUJBQXdCLFdBQVUsVUFDeEg7QUFBQSx1Q0FBQyxTQUFNLFdBQVUsaUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThCO0FBQUE7QUFBQSxtQkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsVUFBTyxTQUFRLFdBQVUsU0FBU2pDLGFBQWEsY0FBVyxzQ0FBcUMsV0FBVSxVQUN4RztBQUFBLHVDQUFDLGFBQVUsV0FBVSxpQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0M7QUFBQTtBQUFBLG1CQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQSxJQUNFO0FBQUEsWUFFSCxDQUFDSCxVQUNBLHVCQUFDLFNBQUksSUFBRyxzQkFBcUIsV0FBVSxRQUNyQyxpQ0FBQyxVQUFPLFNBQVEsU0FBUSxTQUFTVixNQUFNMkMsZUFBZSxjQUFXLDBCQUF5QixXQUFVLFVBQVEsNkJBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBLElBQ0U7QUFBQTtBQUFBO0FBQUEsUUF6QmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BMEJRO0FBQUEsU0FoVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlUQTtBQUFBLElBQ0MzQyxNQUFNK0M7QUFBQUEsSUFFUCx1QkFBQyxlQUNDLGlDQUFDLFlBQVksVUFBWixFQUFxQixRQUFRdkMsbUJBQW1CLGNBQWNDLHNCQUFzQixlQUFhLE1BQ2hHLGlDQUFDLFlBQVksV0FBWixFQUNDLGlDQUFDLFlBQVksUUFBWixFQUFtQixXQUFVLG9CQUM1QjtBQUFBLDZCQUFDLFlBQVksUUFBWixFQUNDLGlDQUFDLFlBQVksU0FBWixFQUFvQixXQUFVLHdDQUF1QywyQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRixLQURuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFlBQVksTUFBWixFQUNDLGlDQUFDLE9BQUUsV0FBVSxrQkFBZ0IsOEZBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BQ0EsdUJBQUMsWUFBWSxRQUFaLEVBQW1CLFdBQVUsZ0NBQzVCO0FBQUEsK0JBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUSxZQUFXLFdBQVUsbUNBQWlDLHNCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQU8sTUFBSyxTQUFRLFNBQVEsVUFBUyxTQUFTSyxvQkFBb0IsV0FBVSxvQkFBa0IscUJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBLEtBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQkEsS0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLE9BNVVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2VUE7QUFFSjtBQUFDYixHQW5YZUYsWUFBVTtBQUFBLEtBQVZBO0FBQVUsSUFBQWlEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJvdGF0ZUNjdyIsIlVuZG8yIiwidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkFsZXJ0RGlhbG9nIiwiQnV0dG9uIiwiZm9ybWF0TXMiLCJHYW1lU2NyZWVuIiwicHJvcHMiLCJfcyIsIm9uRGlzbWlzc09uYm9hcmRpbmciLCJvblJlc2V0Iiwic2hvdWxkU2hvd09uYm9hcmRpbmdDdWUiLCJzZXR0aW5ncyIsImxheW91dE1vZGUiLCJvbmJvYXJkaW5nU2VlbiIsImlzUmVzZXREaWFsb2dPcGVuIiwic2V0SXNSZXNldERpYWxvZ09wZW4iLCJpc0VuZGVkIiwiQm9vbGVhbiIsInRpbWVvdXRTaWRlIiwiaGFuZGxlUmVzZXQiLCJoYW5kbGVSZXNldENvbmZpcm0iLCJ0aW1lciIsIndpbmRvdyIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJhY3RpdmVJbmRpY2F0b3JUZXh0IiwiYWN0aXZlU2lkZSIsInBhdXNlZERpZ2l0U2l6ZUNsYXNzIiwibGFyZ2VEaWdpdHNNb2RlIiwiYWN0aXZlRGlnaXRTaXplQ2xhc3MiLCJpbmFjdGl2ZURpZ2l0U2l6ZUNsYXNzIiwiaXNQbGF5aW5nIiwiaXNQYXVzZWQiLCJoaWRlQ2hyb21lIiwic3RhcnRlZENvbnRyb2wiLCJsYWJlbCIsImhlYWRlckFjdGlvbnMiLCJhY3Rpb25NZXNzYWdlIiwidG9uZSIsInRleHQiLCJ3YXJuaW5nQmFubmVyIiwibGl2ZUFubm91bmNlbWVudCIsImFjdGl2ZURlbGF5UmVtYWluaW5nTXMiLCJ0b0ZpeGVkIiwiaGlnaENvbnRyYXN0TW9kZSIsInJlbWFpbmluZ01zIiwiQmxhY2siLCJXaGl0ZSIsIm9uUGF1c2VSZXN1bWUiLCJvbkJhY2tUb1NldHVwIiwib25TaWRlVGFwIiwib25VbmRvIiwiY2FuVW5kbyIsInNldHRpbmdzRHJhd2VyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR2FtZVNjcmVlbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUm90YXRlQ2N3LCBVbmRvMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVN0YXRlLCB0eXBlIFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQWxlcnREaWFsb2csIEJ1dHRvbiB9IGZyb20gJ0BoZXJvdWkvcmVhY3QnXG5pbXBvcnQgeyBmb3JtYXRNcywgdHlwZSBBY3Rpb25NZXNzYWdlVG9uZSwgdHlwZSBBcHBTZXR0aW5ncywgdHlwZSBTaWRlLCB0eXBlIFRpbWVDb250cm9sIH0gZnJvbSAnQC9hcHAvdHlwZXMnXG5cbnR5cGUgR2FtZVNjcmVlblByb3BzID0ge1xuICBoZWFkZXJBY3Rpb25zOiBSZWFjdE5vZGVcbiAgd2FybmluZ0Jhbm5lcjogUmVhY3ROb2RlXG4gIHNldHRpbmdzRHJhd2VyOiBSZWFjdE5vZGVcbiAgYWN0aW9uTWVzc2FnZTogeyB0b25lOiBBY3Rpb25NZXNzYWdlVG9uZTsgdGV4dDogc3RyaW5nIH0gfCBudWxsXG4gIGxpdmVBbm5vdW5jZW1lbnQ6IHN0cmluZ1xuICBzZXR0aW5nczogQXBwU2V0dGluZ3NcbiAgc3RhcnRlZENvbnRyb2w6IFRpbWVDb250cm9sXG4gIGFjdGl2ZVNpZGU6IFNpZGVcbiAgcmVtYWluaW5nTXM6IFJlY29yZDxTaWRlLCBudW1iZXI+XG4gIGFjdGl2ZURlbGF5UmVtYWluaW5nTXM6IG51bWJlclxuICB0aW1lb3V0U2lkZTogU2lkZSB8IG51bGxcbiAgaXNQYXVzZWQ6IGJvb2xlYW5cbiAgY2FuVW5kbzogYm9vbGVhblxuICBvbmJvYXJkaW5nU2VlbjogYm9vbGVhblxuICBvbkRpc21pc3NPbmJvYXJkaW5nOiAoKSA9PiB2b2lkXG4gIG9uU2lkZVRhcDogKHNpZGU6IFNpZGUpID0+IHZvaWRcbiAgb25QYXVzZVJlc3VtZTogKCkgPT4gdm9pZFxuICBvblVuZG86ICgpID0+IHZvaWRcbiAgb25SZXNldDogKCkgPT4gdm9pZFxuICBvbkJhY2tUb1NldHVwOiAoKSA9PiB2b2lkXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBHYW1lU2NyZWVuKHByb3BzOiBHYW1lU2NyZWVuUHJvcHMpIHtcbiAgY29uc3QgeyBvbkRpc21pc3NPbmJvYXJkaW5nLCBvblJlc2V0IH0gPSBwcm9wc1xuICBcbiAgY29uc3Qgc2hvdWxkU2hvd09uYm9hcmRpbmdDdWUgPSBwcm9wcy5zZXR0aW5ncy5sYXlvdXRNb2RlID09PSAnYWRhcHRpdmUnICYmICFwcm9wcy5vbmJvYXJkaW5nU2VlblxuICBjb25zdCBbaXNSZXNldERpYWxvZ09wZW4sIHNldElzUmVzZXREaWFsb2dPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBpc0VuZGVkID0gQm9vbGVhbihwcm9wcy50aW1lb3V0U2lkZSlcblxuICBjb25zdCBoYW5kbGVSZXNldCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBzZXRJc1Jlc2V0RGlhbG9nT3Blbih0cnVlKVxuICB9LCBbXSlcblxuICBjb25zdCBoYW5kbGVSZXNldENvbmZpcm0gPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgb25SZXNldCgpXG4gIH0sIFtvblJlc2V0XSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghc2hvdWxkU2hvd09uYm9hcmRpbmdDdWUpIHJldHVyblxuXG4gICAgY29uc3QgdGltZXIgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBvbkRpc21pc3NPbmJvYXJkaW5nKClcbiAgICB9LCAzMDAwKVxuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpXG4gICAgfVxuICB9LCBbb25EaXNtaXNzT25ib2FyZGluZywgc2hvdWxkU2hvd09uYm9hcmRpbmdDdWVdKVxuXG4gIGNvbnN0IGFjdGl2ZUluZGljYXRvclRleHQgPSBgJHtwcm9wcy5hY3RpdmVTaWRlfSB0byBtb3ZlYFxuICBjb25zdCBwYXVzZWREaWdpdFNpemVDbGFzcyA9IHByb3BzLnNldHRpbmdzLmxhcmdlRGlnaXRzTW9kZSA/ICd0ZXh0LTV4bCBtZDp0ZXh0LTZ4bCcgOiAndGV4dC0yeGwnXG4gIGNvbnN0IGFjdGl2ZURpZ2l0U2l6ZUNsYXNzID0gcHJvcHMuc2V0dGluZ3MubGFyZ2VEaWdpdHNNb2RlID8gJ3RleHQtN3hsIG1kOnRleHQtOHhsJyA6ICd0ZXh0LTR4bCBtZDp0ZXh0LTV4bCdcbiAgY29uc3QgaW5hY3RpdmVEaWdpdFNpemVDbGFzcyA9IHByb3BzLnNldHRpbmdzLmxhcmdlRGlnaXRzTW9kZSA/ICd0ZXh0LTV4bCBtZDp0ZXh0LTZ4bCcgOiAndGV4dC0yeGwnXG5cbiAgY29uc3QgaXNQbGF5aW5nID0gIXByb3BzLmlzUGF1c2VkICYmICFpc0VuZGVkXG4gIGNvbnN0IGhpZGVDaHJvbWUgPSBpc1BsYXlpbmdcblxuICByZXR1cm4gKFxuICAgIDxtYWluIGlkPVwiZ2FtZS1zY3JlZW5cIiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiBmbGV4LWNvbCBiZy1zbGF0ZS0xMDBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwgZmxleC0xIGZsZXgtY29sIHB4LTUgcHktNCBtZDpweS02XCI+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBpZD1cImdhbWUtY2hyb21lXCJcbiAgICAgICAgICBjbGFzc05hbWU9e2B0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZWFzZS1bY3ViaWMtYmV6aWVyKDAuNCwwLDAuMiwxKV0gJHtcbiAgICAgICAgICAgIGhpZGVDaHJvbWUgPyAnbXQtMCBtYXgtaC0wIG92ZXJmbG93LWhpZGRlbiBvcGFjaXR5LTAnIDogJ210LTAgbWF4LWgtNDAgb3BhY2l0eS0xMDAnXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgPGRpdiBpZD1cImdhbWUtYnJhbmRcIiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgYmctc2xhdGUtOTAwIHB4LTMgcHktMSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzbTpweC0zLjUgc206cHktMS41XCI+XG4gICAgICAgICAgICAgIFp1Z3p3YW5nXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBiZy1vcmFuZ2UtNTAwLzI1IHB4LTEuNSBweS0wLjUgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtb3JhbmdlLTQwMCBzbTpweC0yIHNtOnRleHQteHNcIj5cbiAgICAgICAgICAgICAgICB7cHJvcHMuc3RhcnRlZENvbnRyb2wubGFiZWx9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge3Byb3BzLmhlYWRlckFjdGlvbnN9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge3Byb3BzLmFjdGlvbk1lc3NhZ2UgPyAoXG4gICAgICAgICAgICA8cFxuICAgICAgICAgICAgICBpZD1cImdhbWUtYWN0aW9uLW1lc3NhZ2VcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BtdC0yIHRleHQtc20gJHtcbiAgICAgICAgICAgICAgICBwcm9wcy5hY3Rpb25NZXNzYWdlLnRvbmUgPT09ICdzdWNjZXNzJ1xuICAgICAgICAgICAgICAgICAgPyAndGV4dC1lbWVyYWxkLTcwMCdcbiAgICAgICAgICAgICAgICAgIDogcHJvcHMuYWN0aW9uTWVzc2FnZS50b25lID09PSAnZXJyb3InXG4gICAgICAgICAgICAgICAgICAgID8gJ3RleHQtcmVkLTYwMCdcbiAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS02MDAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICByb2xlPVwic3RhdHVzXCJcbiAgICAgICAgICAgICAgYXJpYS1saXZlPVwicG9saXRlXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3Byb3BzLmFjdGlvbk1lc3NhZ2UudGV4dH1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICB7c2hvdWxkU2hvd09uYm9hcmRpbmdDdWUgPyAoXG4gICAgICAgICAgICA8ZGl2IGlkPVwiZ2FtZS1vbmJvYXJkaW5nXCIgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2t5LTIwMCBiZy1za3ktNTAgcHgtNCBweS0zIHRleHQtc20gdGV4dC1za3ktOTAwXCI+XG4gICAgICAgICAgICAgIDxwPlRhcCB5b3VyIHNpZGUgdG8gc3dpdGNoLiBUYXAgdGhlIHNtYWxsIHN0cmlwIHRvIHBhdXNlLjwvcD5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3Byb3BzLm9uRGlzbWlzc09uYm9hcmRpbmd9XG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkRpc21pc3Mgb25ib2FyZGluZyB0aXBcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2t5LTMwMCBiZy13aGl0ZSBweC0yIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4wOGVtXSB0ZXh0LXNreS04MDAgdHJhbnNpdGlvbiBob3ZlcjpiZy1za3ktMTAwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIERpc21pc3NcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICB7cHJvcHMud2FybmluZ0Jhbm5lcn1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwic3Itb25seVwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiIGFyaWEtYXRvbWljPVwidHJ1ZVwiPlxuICAgICAgICAgIHtwcm9wcy5saXZlQW5ub3VuY2VtZW50fVxuICAgICAgICA8L3A+XG5cbiAgICAgICAgPGRpdiBpZD1cImdhbWUtdGltZXJzXCIgY2xhc3NOYW1lPXtgZmxleCBmbGV4LTEgZmxleC1jb2wgbWluLWgtMCAke2hpZGVDaHJvbWUgPyAnbXQtMCcgOiAnbXQtNCd9IHRyYW5zaXRpb24tW21hcmdpbl0gZHVyYXRpb24tMzAwIGVhc2UtW2N1YmljLWJlemllcigwLjQsMCwwLjIsMSldYH0+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2UtW2N1YmljLWJlemllcigwLjQsMCwwLjIsMSldICR7XG4gICAgICAgICAgICAgIGhpZGVDaHJvbWUgPyAnbWF4LWgtMCBvdmVyZmxvdy1oaWRkZW4gb3BhY2l0eS0wJyA6ICdtYXgtaC02IG9wYWNpdHktMTAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHAgaWQ9XCJnYW1lLWFjdGl2ZS1pbmRpY2F0b3JcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dIHRleHQtc2xhdGUtNTAwXCI+e2FjdGl2ZUluZGljYXRvclRleHR9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtwcm9wcy5hY3RpdmVEZWxheVJlbWFpbmluZ01zID4gMCAmJiAhcHJvcHMuaXNQYXVzZWQgJiYgIXByb3BzLnRpbWVvdXRTaWRlID8gKFxuICAgICAgICAgICAgPHAgaWQ9XCJnYW1lLWRlbGF5LWluZGljYXRvclwiIGNsYXNzTmFtZT1cIm10LTAuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xMmVtXSB0ZXh0LXNsYXRlLTUwMFwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxuICAgICAgICAgICAgICBEZWxheTogeyhwcm9wcy5hY3RpdmVEZWxheVJlbWFpbmluZ01zIC8gMTAwMCkudG9GaXhlZCgxKX1zXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKSA6IG51bGx9XG5cbiAgICAgICAgICB7cHJvcHMuaXNQYXVzZWQgJiYgIWlzRW5kZWQgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBmbGV4LTEgZmxleC1jb2wgZ2FwLTMgYW5pbWF0ZS1mYWRlLWluXCIgYXJpYS1saXZlPVwicG9saXRlXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBmbGV4LTEgZ2FwLTUgJHtwcm9wcy5zZXR0aW5ncy5sYXlvdXRNb2RlID09PSAnY2xhc3NpYycgPyAnZmxleC1jb2wgc206ZmxleC1yb3cnIDogJ2ZsZXgtY29sIG1kOmZsZXgtcm93J31gfSByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwiUGF1c2VkIHRpbWVyc1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBmbGV4LTEgZmxleC1jb2wganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgcHgtNCBweS00ICR7cHJvcHMuc2V0dGluZ3MubGF5b3V0TW9kZSA9PT0gJ2NsYXNzaWMnID8gJ2l0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlcicgOiAndGV4dC1sZWZ0J30gJHtwcm9wcy5zZXR0aW5ncy5oaWdoQ29udHJhc3RNb2RlID8gJ2JvcmRlci0yIGJvcmRlci1zbGF0ZS04MDAgYmctd2hpdGUgdGV4dC1zbGF0ZS05MDAnIDogJ2JvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXNsYXRlLTUwIHRleHQtc2xhdGUtOTAwJ31gfT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm90YXRlLTE4MFwiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dIHRleHQtc2xhdGUtNTAwXCI+QmxhY2s8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17YG10LTEgZm9udC1zZW1pYm9sZCB0YWJ1bGFyLW51bXMgJHtwYXVzZWREaWdpdFNpemVDbGFzc31gfT5cbiAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0TXMocHJvcHMucmVtYWluaW5nTXMuQmxhY2spfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggZmxleC0xIGZsZXgtY29sIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIHB4LTQgcHktNCAke3Byb3BzLnNldHRpbmdzLmxheW91dE1vZGUgPT09ICdjbGFzc2ljJyA/ICdpdGVtcy1jZW50ZXIgdGV4dC1jZW50ZXInIDogJ3RleHQtbGVmdCd9ICR7cHJvcHMuc2V0dGluZ3MuaGlnaENvbnRyYXN0TW9kZSA/ICdib3JkZXItMiBib3JkZXItc2xhdGUtODAwIGJnLXdoaXRlIHRleHQtc2xhdGUtOTAwJyA6ICdib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS01MCB0ZXh0LXNsYXRlLTkwMCd9YH0+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dIHRleHQtc2xhdGUtNTAwXCI+V2hpdGU8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2BtdC0xIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zICR7cGF1c2VkRGlnaXRTaXplQ2xhc3N9YH0+XG4gICAgICAgICAgICAgICAgICAgIHtmb3JtYXRNcyhwcm9wcy5yZW1haW5pbmdNcy5XaGl0ZSl9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcbiAgICAgICAgICAgICAgICBvblByZXNzPXtwcm9wcy5vblBhdXNlUmVzdW1lfVxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BSZXN1bWUgZ2FtZSB3aXRoICR7cHJvcHMuYWN0aXZlU2lkZX0gdG8gbW92ZWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBSZXN1bWUgKHtwcm9wcy5hY3RpdmVTaWRlfSB0byBtb3ZlKVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiBpc0VuZGVkID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggZmxleC0xIGZsZXgtY29sIGdhcC0zIGFuaW1hdGUtZmFkZS1pblwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggZmxleC0xIGdhcC01ICR7cHJvcHMuc2V0dGluZ3MubGF5b3V0TW9kZSA9PT0gJ2NsYXNzaWMnID8gJ2ZsZXgtY29sIHNtOmZsZXgtcm93JyA6ICdmbGV4LWNvbCBtZDpmbGV4LXJvdyd9YH0gcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD1cIkdhbWUgZW5kZWQgdGltZXJzXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4IGZsZXgtMSBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJvcmRlciBweC00IHB5LTQgJHtwcm9wcy5zZXR0aW5ncy5sYXlvdXRNb2RlID09PSAnY2xhc3NpYycgPyAnaXRlbXMtY2VudGVyIHRleHQtY2VudGVyJyA6ICd0ZXh0LWxlZnQnfSAke3Byb3BzLnRpbWVvdXRTaWRlID09PSAnQmxhY2snID8gJ2JvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXNsYXRlLTEwMCBvcGFjaXR5LTYwJyA6ICdib3JkZXItMiBib3JkZXItZW1lcmFsZC00MDAgYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtOTAwJ31gfT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm90YXRlLTE4MFwiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dIHRleHQtc2xhdGUtNTAwXCI+QmxhY2s8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17YG10LTEgZm9udC1zZW1pYm9sZCB0YWJ1bGFyLW51bXMgJHtwYXVzZWREaWdpdFNpemVDbGFzc30gJHtwcm9wcy50aW1lb3V0U2lkZSA9PT0gJ0JsYWNrJyA/ICdsaW5lLXRocm91Z2gnIDogJyd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdE1zKHByb3BzLnJlbWFpbmluZ01zLkJsYWNrKX1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICB7cHJvcHMudGltZW91dFNpZGUgPT09ICdCbGFjaycgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dIHRleHQtcmVkLTYwMFwiPlRpbWUgT3V0PC9wPlxuICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBmbGV4LTEgZmxleC1jb2wganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgcHgtNCBweS00ICR7cHJvcHMuc2V0dGluZ3MubGF5b3V0TW9kZSA9PT0gJ2NsYXNzaWMnID8gJ2l0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlcicgOiAndGV4dC1sZWZ0J30gJHtwcm9wcy50aW1lb3V0U2lkZSA9PT0gJ1doaXRlJyA/ICdib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS0xMDAgb3BhY2l0eS02MCcgOiAnYm9yZGVyLTIgYm9yZGVyLWVtZXJhbGQtNDAwIGJnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTkwMCd9YH0+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dIHRleHQtc2xhdGUtNTAwXCI+V2hpdGU8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2BtdC0xIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zICR7cGF1c2VkRGlnaXRTaXplQ2xhc3N9ICR7cHJvcHMudGltZW91dFNpZGUgPT09ICdXaGl0ZScgPyAnbGluZS10aHJvdWdoJyA6ICcnfWB9PlxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0TXMocHJvcHMucmVtYWluaW5nTXMuV2hpdGUpfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAge3Byb3BzLnRpbWVvdXRTaWRlID09PSAnV2hpdGUnID8gKFxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTJlbV0gdGV4dC1yZWQtNjAwXCI+VGltZSBPdXQ8L3A+XG4gICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXJlZC02MDBcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgICAgICB7cHJvcHMudGltZW91dFNpZGV9IHJhbiBvdXQgb2YgdGltZS57JyAnfVxuICAgICAgICAgICAgICAgIHtwcm9wcy50aW1lb3V0U2lkZSA9PT0gJ1doaXRlJyA/ICdCbGFjayB3aW5zIScgOiAnV2hpdGUgd2lucyEnfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJHYW1lIGVuZCBjb250cm9sc1wiPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgIG9uUHJlc3M9e3Byb3BzLm9uQmFja1RvU2V0dXB9XG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiUmV0dXJuIHRvIHNldHVwIHNjcmVlblwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQmFjayB0byBTZXR1cFxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJkYW5nZXItc29mdFwiXG4gICAgICAgICAgICAgICAgICBvblByZXNzPXtoYW5kbGVSZXNldH1cbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJSZXNldCBnYW1lIHRvIGluaXRpYWwgdGltZSBjb250cm9sXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cIm1yLTIgc2l6ZS00XCIgLz5cbiAgICAgICAgICAgICAgICAgIFJlc2V0XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBmbGV4LTEgbWluLWgtMCBnYXAtNSAke2hpZGVDaHJvbWUgPyAnbXQtMCcgOiAnbXQtMyd9IHRyYW5zaXRpb24tW21hcmdpbl0gZHVyYXRpb24tMzAwIGVhc2UtW2N1YmljLWJlemllcigwLjQsMCwwLjIsMSldICR7XG4gICAgICAgICAgICAgICAgcHJvcHMuc2V0dGluZ3MubGF5b3V0TW9kZSA9PT0gJ2FkYXB0aXZlJyA/ICdmbGV4LWNvbCBtZDpoLWF1dG8gbWQ6ZmxleC1yb3cnIDogJ2ZsZXgtY29sIHNtOmZsZXgtcm93J1xuICAgICAgICAgICAgICB9ICR7cHJvcHMuc2V0dGluZ3MuaGlnaENvbnRyYXN0TW9kZSA/ICdib3JkZXItMiBib3JkZXItc2xhdGUtOTAwIGJnLXNsYXRlLTUwIHAtMicgOiAnJ31gfVxuICAgICAgICAgICAgICBhcmlhLWxpdmU9XCJwb2xpdGVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7cHJvcHMuc2V0dGluZ3MubGF5b3V0TW9kZSA9PT0gJ2NsYXNzaWMnID8gKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBpZD1cInRpbWVyLWJsYWNrXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcHJvcHMub25TaWRlVGFwKCdCbGFjaycpfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNFbmRlZH1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YEJsYWNrICR7cHJvcHMuYWN0aXZlU2lkZSA9PT0gJ0JsYWNrJyA/ICdhY3RpdmUnIDogJ2luYWN0aXZlJ30gdGltZXIuICR7Zm9ybWF0TXMocHJvcHMucmVtYWluaW5nTXMuQmxhY2spfS4gJHtwcm9wcy5hY3RpdmVTaWRlID09PSAnQmxhY2snID8gJ1RhcCB0byBwYXNzIHR1cm4uJyA6ICdUYXAgdG8gcGF1c2UgZ2FtZS4nfWB9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggZmxleC0xIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLTN4bCBweC00IHB5LTQgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbiBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtb2Zmc2V0LTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLXJpbmcgJHtcbiAgICAgICAgICAgICAgICAgICAgICBwcm9wcy5zZXR0aW5ncy5oaWdoQ29udHJhc3RNb2RlXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHByb3BzLmFjdGl2ZVNpZGUgPT09ICdCbGFjaydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTk1MCBiZy1hbWJlci0yMDAgdGV4dC1zbGF0ZS05NTAgaG92ZXI6YmctYW1iZXItMzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItMiBib3JkZXItc2xhdGUtNzAwIGJnLXdoaXRlIHRleHQtc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTEwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogcHJvcHMuYWN0aXZlU2lkZSA9PT0gJ0JsYWNrJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXIgYm9yZGVyLW9yYW5nZS0yMDAgYmctb3JhbmdlLTUwIHRleHQtc2xhdGUtOTAwIGhvdmVyOmJnLW9yYW5nZS0xMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHRleHQtc2xhdGUtNjAwIGhvdmVyOmJnLXNsYXRlLTUwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3RhdGUtMTgwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xMmVtXVwiPkJsYWNre3Byb3BzLmFjdGl2ZVNpZGUgPT09ICdCbGFjaycgPyAnIChhY3RpdmUpJyA6ICcnfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2BtdC0yIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zICR7YWN0aXZlRGlnaXRTaXplQ2xhc3N9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0TXMocHJvcHMucmVtYWluaW5nTXMuQmxhY2spfVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dIHRleHQtc2xhdGUtNTAwXCI+e3Byb3BzLmFjdGl2ZVNpZGUgPT09ICdCbGFjaycgPyAnVGFwIHRvIHBhc3MgdHVybicgOiAnVGFwIHRvIHBhdXNlJ308L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGltZXItd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBwcm9wcy5vblNpZGVUYXAoJ1doaXRlJyl9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0VuZGVkfVxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgV2hpdGUgJHtwcm9wcy5hY3RpdmVTaWRlID09PSAnV2hpdGUnID8gJ2FjdGl2ZScgOiAnaW5hY3RpdmUnfSB0aW1lci4gJHtmb3JtYXRNcyhwcm9wcy5yZW1haW5pbmdNcy5XaGl0ZSl9LiAke3Byb3BzLmFjdGl2ZVNpZGUgPT09ICdXaGl0ZScgPyAnVGFwIHRvIHBhc3MgdHVybi4nIDogJ1RhcCB0byBwYXVzZSBnYW1lLid9YH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBmbGV4LTEgZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtM3hsIHB4LTQgcHktNCB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uIGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1vZmZzZXQtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtcmluZyAke1xuICAgICAgICAgICAgICAgICAgICAgIHByb3BzLnNldHRpbmdzLmhpZ2hDb250cmFzdE1vZGVcbiAgICAgICAgICAgICAgICAgICAgICAgID8gcHJvcHMuYWN0aXZlU2lkZSA9PT0gJ1doaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItMiBib3JkZXItc2xhdGUtOTUwIGJnLWFtYmVyLTIwMCB0ZXh0LXNsYXRlLTk1MCBob3ZlcjpiZy1hbWJlci0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci0yIGJvcmRlci1zbGF0ZS03MDAgYmctd2hpdGUgdGV4dC1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtMTAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiBwcm9wcy5hY3RpdmVTaWRlID09PSAnV2hpdGUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlciBib3JkZXItb3JhbmdlLTIwMCBiZy1vcmFuZ2UtNTAgdGV4dC1zbGF0ZS05MDAgaG92ZXI6Ymctb3JhbmdlLTEwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgdGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtNTAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dXCI+V2hpdGV7cHJvcHMuYWN0aXZlU2lkZSA9PT0gJ1doaXRlJyA/ICcgKGFjdGl2ZSknIDogJyd9PC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2BtdC0yIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zICR7YWN0aXZlRGlnaXRTaXplQ2xhc3N9YH0+XG4gICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdE1zKHByb3BzLnJlbWFpbmluZ01zLldoaXRlKX1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dIHRleHQtc2xhdGUtNTAwXCI+e3Byb3BzLmFjdGl2ZVNpZGUgPT09ICdXaGl0ZScgPyAnVGFwIHRvIHBhc3MgdHVybicgOiAnVGFwIHRvIHBhdXNlJ308L3A+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0aW1lci1ibGFja1wiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHByb3BzLm9uU2lkZVRhcCgnQmxhY2snKX1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRW5kZWR9XG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BCbGFjayAke3Byb3BzLmFjdGl2ZVNpZGUgPT09ICdCbGFjaycgPyAnYWN0aXZlJyA6ICdpbmFjdGl2ZSd9IHRpbWVyLiAke2Zvcm1hdE1zKHByb3BzLnJlbWFpbmluZ01zLkJsYWNrKX0uICR7cHJvcHMuYWN0aXZlU2lkZSA9PT0gJ0JsYWNrJyA/ICdUYXAgdG8gcGFzcyB0dXJuLicgOiAnVGFwIHRvIHBhdXNlIGdhbWUuJ31gfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBlYXNlLWluLW91dCAke1xuICAgICAgICAgICAgICAgICAgICAgIHByb3BzLmFjdGl2ZVNpZGUgPT09ICdCbGFjaycgPyAnZmxleC1bM10nIDogJ2ZsZXgtMSdcbiAgICAgICAgICAgICAgICAgICAgfSBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLTN4bCBweC00ICR7cHJvcHMuYWN0aXZlU2lkZSA9PT0gJ0JsYWNrJyA/ICdweS00JyA6ICdweS0zJ30gdGV4dC1sZWZ0IGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1vZmZzZXQtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtcmluZyAke1xuICAgICAgICAgICAgICAgICAgICAgIHByb3BzLnNldHRpbmdzLmhpZ2hDb250cmFzdE1vZGVcbiAgICAgICAgICAgICAgICAgICAgICAgID8gcHJvcHMuYWN0aXZlU2lkZSA9PT0gJ0JsYWNrJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItMiBib3JkZXItc2xhdGUtOTUwIGJnLWFtYmVyLTIwMCB0ZXh0LXNsYXRlLTk1MCBob3ZlcjpiZy1hbWJlci0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci0yIGJvcmRlci1zbGF0ZS03MDAgYmctd2hpdGUgdGV4dC1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtMTAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiBwcm9wcy5hY3RpdmVTaWRlID09PSAnQmxhY2snXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlciBib3JkZXItb3JhbmdlLTIwMCBiZy1vcmFuZ2UtNTAgdGV4dC1zbGF0ZS05MDAgaG92ZXI6Ymctb3JhbmdlLTEwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgdGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtNTAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdGF0ZS0xODBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7cHJvcHMuYWN0aXZlU2lkZSA9PT0gJ0JsYWNrJyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTJlbV1cIj5CbGFjayAoYWN0aXZlKTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPXtgbXQtMiBmb250LXNlbWlib2xkIHRhYnVsYXItbnVtcyAke2FjdGl2ZURpZ2l0U2l6ZUNsYXNzfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRNcyhwcm9wcy5yZW1haW5pbmdNcy5CbGFjayl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xMmVtXSB0ZXh0LXNsYXRlLTUwMFwiPlRhcCB0byBwYXNzIHR1cm48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xMmVtXVwiPkJsYWNrPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2BtdC0xIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zIHRleHQtc2xhdGUtOTAwICR7aW5hY3RpdmVEaWdpdFNpemVDbGFzc31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0TXMocHJvcHMucmVtYWluaW5nTXMuQmxhY2spfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTJlbV0gdGV4dC1zbGF0ZS01MDBcIj5UYXAgdG8gcGF1c2U8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBpZD1cInRpbWVyLXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcHJvcHMub25TaWRlVGFwKCdXaGl0ZScpfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNFbmRlZH1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YFdoaXRlICR7cHJvcHMuYWN0aXZlU2lkZSA9PT0gJ1doaXRlJyA/ICdhY3RpdmUnIDogJ2luYWN0aXZlJ30gdGltZXIuICR7Zm9ybWF0TXMocHJvcHMucmVtYWluaW5nTXMuV2hpdGUpfS4gJHtwcm9wcy5hY3RpdmVTaWRlID09PSAnV2hpdGUnID8gJ1RhcCB0byBwYXNzIHR1cm4uJyA6ICdUYXAgdG8gcGF1c2UgZ2FtZS4nfWB9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGVhc2UtaW4tb3V0ICR7XG4gICAgICAgICAgICAgICAgICAgICAgcHJvcHMuYWN0aXZlU2lkZSA9PT0gJ1doaXRlJyA/ICdmbGV4LVszXScgOiAnZmxleC0xJ1xuICAgICAgICAgICAgICAgICAgICB9IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtM3hsIHB4LTQgJHtwcm9wcy5hY3RpdmVTaWRlID09PSAnV2hpdGUnID8gJ3B5LTQnIDogJ3B5LTMnfSB0ZXh0LWxlZnQgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW9mZnNldC0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1yaW5nICR7XG4gICAgICAgICAgICAgICAgICAgICAgcHJvcHMuc2V0dGluZ3MuaGlnaENvbnRyYXN0TW9kZVxuICAgICAgICAgICAgICAgICAgICAgICAgPyBwcm9wcy5hY3RpdmVTaWRlID09PSAnV2hpdGUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci0yIGJvcmRlci1zbGF0ZS05NTAgYmctYW1iZXItMjAwIHRleHQtc2xhdGUtOTUwIGhvdmVyOmJnLWFtYmVyLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTcwMCBiZy13aGl0ZSB0ZXh0LXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS0xMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHByb3BzLmFjdGl2ZVNpZGUgPT09ICdXaGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyIGJvcmRlci1vcmFuZ2UtMjAwIGJnLW9yYW5nZS01MCB0ZXh0LXNsYXRlLTkwMCBob3ZlcjpiZy1vcmFuZ2UtMTAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSB0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS01MCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtwcm9wcy5hY3RpdmVTaWRlID09PSAnV2hpdGUnID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dXCI+V2hpdGUgKGFjdGl2ZSk8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2BtdC0yIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zICR7YWN0aXZlRGlnaXRTaXplQ2xhc3N9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRNcyhwcm9wcy5yZW1haW5pbmdNcy5XaGl0ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dIHRleHQtc2xhdGUtNTAwXCI+VGFwIHRvIHBhc3MgdHVybjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xMmVtXVwiPldoaXRlPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPXtgbXQtMSBmb250LXNlbWlib2xkIHRhYnVsYXItbnVtcyB0ZXh0LXNsYXRlLTkwMCAke2luYWN0aXZlRGlnaXRTaXplQ2xhc3N9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRNcyhwcm9wcy5yZW1haW5pbmdNcy5XaGl0ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dIHRleHQtc2xhdGUtNTAwXCI+VGFwIHRvIHBhdXNlPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuPGRpdlxuICAgICAgICAgIGlkPVwiZ2FtZS1jb250cm9sc1wiXG4gICAgICAgICAgY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2UtW2N1YmljLWJlemllcigwLjQsMCwwLjIsMSldICR7XG4gICAgICAgICAgICBoaWRlQ2hyb21lID8gJ21heC1oLTAgb3ZlcmZsb3ctaGlkZGVuIG9wYWNpdHktMCcgOiAnbWF4LWgtNDAgb3BhY2l0eS0xMDAnXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICB7IWlzRW5kZWQgJiYgcHJvcHMuaXNQYXVzZWQgPyAoXG4gICAgICAgICAgICA8ZGl2IGlkPVwiZ2FtZS1wYXVzZS1jb250cm9sc1wiIGNsYXNzTmFtZT1cIm10LTQgZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJQYXVzZWQgZ2FtZSBjb250cm9sc1wiPlxuICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25QcmVzcz17cHJvcHMub25VbmRvfSBpc0Rpc2FibGVkPXshcHJvcHMuY2FuVW5kb30gYXJpYS1sYWJlbD1cIlVuZG8gbGFzdCB0dXJuIHN3aXRjaFwiIGNsYXNzTmFtZT1cInctZnVsbFwiPlxuICAgICAgICAgICAgICAgIDxVbmRvMiBjbGFzc05hbWU9XCJtci0yIHNpemUtNFwiIC8+XG4gICAgICAgICAgICAgICAgVW5kb1xuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIG9uUHJlc3M9e2hhbmRsZVJlc2V0fSBhcmlhLWxhYmVsPVwiUmVzZXQgZ2FtZSB0byBpbml0aWFsIHRpbWUgY29udHJvbFwiIGNsYXNzTmFtZT1cInctZnVsbFwiPlxuICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwibXItMiBzaXplLTRcIiAvPlxuICAgICAgICAgICAgICAgIFJlc2V0XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IG51bGx9XG5cbiAgICAgICAgICB7IWlzRW5kZWQgPyAoXG4gICAgICAgICAgICA8ZGl2IGlkPVwiZ2FtZS1iYWNrLXRvLXNldHVwXCIgY2xhc3NOYW1lPVwicHQtNFwiPlxuICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uUHJlc3M9e3Byb3BzLm9uQmFja1RvU2V0dXB9IGFyaWEtbGFiZWw9XCJSZXR1cm4gdG8gc2V0dXAgc2NyZWVuXCIgY2xhc3NOYW1lPVwidy1mdWxsXCI+XG4gICAgICAgICAgICAgICAgQmFjayB0byBTZXR1cFxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAge3Byb3BzLnNldHRpbmdzRHJhd2VyfVxuXG4gICAgICA8QWxlcnREaWFsb2c+XG4gICAgICAgIDxBbGVydERpYWxvZy5CYWNrZHJvcCBpc09wZW49e2lzUmVzZXREaWFsb2dPcGVufSBvbk9wZW5DaGFuZ2U9e3NldElzUmVzZXREaWFsb2dPcGVufSBpc0Rpc21pc3NhYmxlPlxuICAgICAgICAgIDxBbGVydERpYWxvZy5Db250YWluZXI+XG4gICAgICAgICAgICA8QWxlcnREaWFsb2cuRGlhbG9nIGNsYXNzTmFtZT1cInNtOm1heC13LVs0MDBweF1cIj5cbiAgICAgICAgICAgICAgPEFsZXJ0RGlhbG9nLkhlYWRlcj5cbiAgICAgICAgICAgICAgICA8QWxlcnREaWFsb2cuSGVhZGluZyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5SZXNldCBnYW1lPzwvQWxlcnREaWFsb2cuSGVhZGluZz5cbiAgICAgICAgICAgICAgPC9BbGVydERpYWxvZy5IZWFkZXI+XG4gICAgICAgICAgICAgIDxBbGVydERpYWxvZy5Cb2R5PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgICAgICAgICBUaGlzIHdpbGwgcmVzZXQgdGhlIGdhbWUgYW5kIGNsZWFyIHVuZG8gaGlzdG9yeS4gVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvQWxlcnREaWFsb2cuQm9keT5cbiAgICAgICAgICAgICAgPEFsZXJ0RGlhbG9nLkZvb3RlciBjbGFzc05hbWU9XCJmbGV4LWNvbC1yZXZlcnNlIHNtOmZsZXgtcm93XCI+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBzbG90PVwiY2xvc2VcIiB2YXJpYW50PVwidGVydGlhcnlcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIHRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uIHNsb3Q9XCJjbG9zZVwiIHZhcmlhbnQ9XCJkYW5nZXJcIiBvblByZXNzPXtoYW5kbGVSZXNldENvbmZpcm19IGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgIFJlc2V0XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvQWxlcnREaWFsb2cuRm9vdGVyPlxuICAgICAgICAgICAgPC9BbGVydERpYWxvZy5EaWFsb2c+XG4gICAgICAgICAgPC9BbGVydERpYWxvZy5Db250YWluZXI+XG4gICAgICAgIDwvQWxlcnREaWFsb2cuQmFja2Ryb3A+XG4gICAgICA8L0FsZXJ0RGlhbG9nPlxuICAgIDwvbWFpbj5cbiAgKVxufSJdLCJmaWxlIjoiL1VzZXJzL3JpY2t5c3VsbGl2YW4vUHJvamVjdHMvY2hlc3MtdGltZXIvc3JjL2ZlYXR1cmVzL2dhbWVwbGF5L2NvbXBvbmVudHMvR2FtZVNjcmVlbi50c3gifQ==