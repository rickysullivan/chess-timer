import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/settings/components/SettingsDrawer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5db2b99c"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Drawer, Switch } from "/node_modules/.vite/deps/@heroui_react.js?v=5db2b99c";
export function SettingsDrawer(props) {
  const { isOpen, onClose, onUpdateSetting, settings } = props;
  return /* @__PURE__ */ jsxDEV(Drawer, { children: /* @__PURE__ */ jsxDEV(Drawer.Backdrop, { isOpen, onOpenChange: onClose, isDismissable: true, children: /* @__PURE__ */ jsxDEV(Drawer.Content, { placement: "bottom", children: /* @__PURE__ */ jsxDEV(Drawer.Dialog, { className: "rounded-t-2xl", children: [
    /* @__PURE__ */ jsxDEV(Drawer.Handle, {}, void 0, false, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
      lineNumber: 19,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Drawer.CloseTrigger, { className: "rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900" }, void 0, false, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
      lineNumber: 20,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Drawer.Header, { children: /* @__PURE__ */ jsxDEV(Drawer.Heading, { children: "Settings" }, void 0, false, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
      lineNumber: 22,
      columnNumber: 15
    }, this) }, void 0, false, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
      lineNumber: 21,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Drawer.Body, { children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxDEV(
        Switch,
        {
          isSelected: settings.sound,
          onChange: () => onUpdateSetting("sound", !settings.sound),
          "aria-label": "Sound",
          children: /* @__PURE__ */ jsxDEV(Switch.Content, { children: [
            /* @__PURE__ */ jsxDEV(Switch.Control, { children: /* @__PURE__ */ jsxDEV(Switch.Thumb, {}, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 33,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 32,
              columnNumber: 21
            }, this),
            "Sound"
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
            lineNumber: 31,
            columnNumber: 19
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
          lineNumber: 26,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Switch,
        {
          isSelected: settings.vibration,
          onChange: () => onUpdateSetting("vibration", !settings.vibration),
          "aria-label": "Vibration",
          children: /* @__PURE__ */ jsxDEV(Switch.Content, { children: [
            /* @__PURE__ */ jsxDEV(Switch.Control, { children: /* @__PURE__ */ jsxDEV(Switch.Thumb, {}, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 46,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 45,
              columnNumber: 21
            }, this),
            "Vibration"
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
            lineNumber: 44,
            columnNumber: 19
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
          lineNumber: 39,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Switch,
        {
          isSelected: settings.keepScreenAwake,
          onChange: () => onUpdateSetting("keepScreenAwake", !settings.keepScreenAwake),
          "aria-label": "Keep screen awake",
          children: /* @__PURE__ */ jsxDEV(Switch.Content, { children: [
            /* @__PURE__ */ jsxDEV(Switch.Control, { children: /* @__PURE__ */ jsxDEV(Switch.Thumb, {}, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 59,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 58,
              columnNumber: 21
            }, this),
            "Keep screen awake"
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
            lineNumber: 57,
            columnNumber: 19
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
          lineNumber: 52,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Switch,
        {
          isSelected: settings.highContrastMode,
          onChange: () => onUpdateSetting("highContrastMode", !settings.highContrastMode),
          "aria-label": "High-contrast mode",
          children: /* @__PURE__ */ jsxDEV(Switch.Content, { children: [
            /* @__PURE__ */ jsxDEV(Switch.Control, { children: /* @__PURE__ */ jsxDEV(Switch.Thumb, {}, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 72,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 71,
              columnNumber: 21
            }, this),
            "High-contrast mode"
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
            lineNumber: 70,
            columnNumber: 19
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
          lineNumber: 65,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Switch,
        {
          isSelected: settings.largeDigitsMode,
          onChange: () => onUpdateSetting("largeDigitsMode", !settings.largeDigitsMode),
          "aria-label": "Large digits mode",
          children: /* @__PURE__ */ jsxDEV(Switch.Content, { children: [
            /* @__PURE__ */ jsxDEV(Switch.Control, { children: /* @__PURE__ */ jsxDEV(Switch.Thumb, {}, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 85,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 84,
              columnNumber: 21
            }, this),
            "Large digits mode"
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
            lineNumber: 83,
            columnNumber: 19
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
          lineNumber: 78,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-slate-200 px-4 py-3", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-slate-800", children: "Layout mode" }, void 0, false, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
          lineNumber: 92,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 grid grid-cols-2 gap-2", role: "group", "aria-label": "Layout mode", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => onUpdateSetting("layoutMode", "adaptive"),
              "aria-pressed": settings.layoutMode === "adaptive",
              className: `rounded-lg border px-3 py-2 text-xs font-semibold uppercase tracking-[0.12em] transition ${settings.layoutMode === "adaptive" ? "border-primary bg-orange-50 text-slate-900" : "border-slate-200 bg-white text-slate-500 hover:bg-slate-50"}`,
              children: "Adaptive"
            },
            void 0,
            false,
            {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 94,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => onUpdateSetting("layoutMode", "classic"),
              "aria-pressed": settings.layoutMode === "classic",
              className: `rounded-lg border px-3 py-2 text-xs font-semibold uppercase tracking-[0.12em] transition ${settings.layoutMode === "classic" ? "border-primary bg-orange-50 text-slate-900" : "border-slate-200 bg-white text-slate-500 hover:bg-slate-50"}`,
              children: "Classic"
            },
            void 0,
            false,
            {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
              lineNumber: 106,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
          lineNumber: 93,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
        lineNumber: 91,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
      lineNumber: 25,
      columnNumber: 15
    }, this) }, void 0, false, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
      lineNumber: 24,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
    lineNumber: 18,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
    lineNumber: 17,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
    lineNumber: 16,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}
_c = SettingsDrawer;
var _c;
$RefreshReg$(_c, "SettingsDrawer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/rickysullivan/Projects/chess-timer/src/features/settings/components/SettingsDrawer.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JZO0FBbEJaLFNBQVNBLFFBQVFDLGNBQWM7QUFVeEIsZ0JBQVNDLGVBQWVDLE9BQTRCO0FBQ3pELFFBQU0sRUFBRUMsUUFBUUMsU0FBU0MsaUJBQWlCQyxTQUFTLElBQUlKO0FBRXZELFNBQ0UsdUJBQUMsVUFDQyxpQ0FBQyxPQUFPLFVBQVAsRUFBZ0IsUUFBZ0IsY0FBY0UsU0FBUyxlQUFhLE1BQ25FLGlDQUFDLE9BQU8sU0FBUCxFQUFlLFdBQVUsVUFDeEIsaUNBQUMsT0FBTyxRQUFQLEVBQWMsV0FBVSxpQkFDdkI7QUFBQSwyQkFBQyxPQUFPLFFBQVAsSUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxJQUNkLHVCQUFDLE9BQU8sY0FBUCxFQUFvQixXQUFVLHNGQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlIO0FBQUEsSUFDakgsdUJBQUMsT0FBTyxRQUFQLEVBQ0MsaUNBQUMsT0FBTyxTQUFQLEVBQWUsd0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsS0FEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxPQUFPLE1BQVAsRUFDQyxpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxZQUFZRSxTQUFTQztBQUFBQSxVQUNyQixVQUFVLE1BQU1GLGdCQUFnQixTQUFTLENBQUNDLFNBQVNDLEtBQUs7QUFBQSxVQUN4RCxjQUFXO0FBQUEsVUFFWCxpQ0FBQyxPQUFPLFNBQVAsRUFDQztBQUFBLG1DQUFDLE9BQU8sU0FBUCxFQUNDLGlDQUFDLE9BQU8sT0FBUCxJQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWEsS0FEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFBZ0I7QUFBQSxlQUhsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUE7QUFBQSxRQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVdBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsWUFBWUQsU0FBU0U7QUFBQUEsVUFDckIsVUFBVSxNQUFNSCxnQkFBZ0IsYUFBYSxDQUFDQyxTQUFTRSxTQUFTO0FBQUEsVUFDaEUsY0FBVztBQUFBLFVBRVgsaUNBQUMsT0FBTyxTQUFQLEVBQ0M7QUFBQSxtQ0FBQyxPQUFPLFNBQVAsRUFDQyxpQ0FBQyxPQUFPLE9BQVAsSUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFhLEtBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQWdCO0FBQUEsZUFIbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBO0FBQUEsUUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFXQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFlBQVlGLFNBQVNHO0FBQUFBLFVBQ3JCLFVBQVUsTUFBTUosZ0JBQWdCLG1CQUFtQixDQUFDQyxTQUFTRyxlQUFlO0FBQUEsVUFDNUUsY0FBVztBQUFBLFVBRVgsaUNBQUMsT0FBTyxTQUFQLEVBQ0M7QUFBQSxtQ0FBQyxPQUFPLFNBQVAsRUFDQyxpQ0FBQyxPQUFPLE9BQVAsSUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFhLEtBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQWdCO0FBQUEsZUFIbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBO0FBQUEsUUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFXQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFlBQVlILFNBQVNJO0FBQUFBLFVBQ3JCLFVBQVUsTUFBTUwsZ0JBQWdCLG9CQUFvQixDQUFDQyxTQUFTSSxnQkFBZ0I7QUFBQSxVQUM5RSxjQUFXO0FBQUEsVUFFWCxpQ0FBQyxPQUFPLFNBQVAsRUFDQztBQUFBLG1DQUFDLE9BQU8sU0FBUCxFQUNDLGlDQUFDLE9BQU8sT0FBUCxJQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWEsS0FEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFBZ0I7QUFBQSxlQUhsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUE7QUFBQSxRQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVdBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsWUFBWUosU0FBU0s7QUFBQUEsVUFDckIsVUFBVSxNQUFNTixnQkFBZ0IsbUJBQW1CLENBQUNDLFNBQVNLLGVBQWU7QUFBQSxVQUM1RSxjQUFXO0FBQUEsVUFFWCxpQ0FBQyxPQUFPLFNBQVAsRUFDQztBQUFBLG1DQUFDLE9BQU8sU0FBUCxFQUNDLGlDQUFDLE9BQU8sT0FBUCxJQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWEsS0FEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFBZ0I7QUFBQSxlQUhsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUE7QUFBQSxRQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUsc0NBQXFDLDJCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZEO0FBQUEsUUFDN0QsdUJBQUMsU0FBSSxXQUFVLCtCQUE4QixNQUFLLFNBQVEsY0FBVyxlQUNuRTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1OLGdCQUFnQixjQUFjLFVBQVU7QUFBQSxjQUN2RCxnQkFBY0MsU0FBU00sZUFBZTtBQUFBLGNBQ3RDLFdBQVcsNEZBQ1ROLFNBQVNNLGVBQWUsYUFDcEIsK0NBQ0EsNERBQTREO0FBQUEsY0FDL0Q7QUFBQTtBQUFBLFlBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1QLGdCQUFnQixjQUFjLFNBQVM7QUFBQSxjQUN0RCxnQkFBY0MsU0FBU00sZUFBZTtBQUFBLGNBQ3RDLFdBQVcsNEZBQ1ROLFNBQVNNLGVBQWUsWUFDcEIsK0NBQ0EsNERBQTREO0FBQUEsY0FDL0Q7QUFBQTtBQUFBLFlBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxhQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUJBO0FBQUEsV0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRCQTtBQUFBLFNBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErRkEsS0FoR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlHQTtBQUFBLE9BdkdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3R0EsS0F6R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBHQSxLQTNHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNEdBLEtBN0dGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4R0E7QUFFSjtBQUFDQyxLQXBIZVo7QUFBYyxJQUFBWTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJEcmF3ZXIiLCJTd2l0Y2giLCJTZXR0aW5nc0RyYXdlciIsInByb3BzIiwiaXNPcGVuIiwib25DbG9zZSIsIm9uVXBkYXRlU2V0dGluZyIsInNldHRpbmdzIiwic291bmQiLCJ2aWJyYXRpb24iLCJrZWVwU2NyZWVuQXdha2UiLCJoaWdoQ29udHJhc3RNb2RlIiwibGFyZ2VEaWdpdHNNb2RlIiwibGF5b3V0TW9kZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNldHRpbmdzRHJhd2VyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEcmF3ZXIsIFN3aXRjaCB9IGZyb20gJ0BoZXJvdWkvcmVhY3QnXG5pbXBvcnQgdHlwZSB7IEFwcFNldHRpbmdzIH0gZnJvbSAnQC9hcHAvdHlwZXMnXG5cbnR5cGUgU2V0dGluZ3NEcmF3ZXJQcm9wcyA9IHtcbiAgaXNPcGVuOiBib29sZWFuXG4gIHNldHRpbmdzOiBBcHBTZXR0aW5nc1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkXG4gIG9uVXBkYXRlU2V0dGluZzogPEsgZXh0ZW5kcyBrZXlvZiBBcHBTZXR0aW5ncz4oa2V5OiBLLCB2YWx1ZTogQXBwU2V0dGluZ3NbS10pID0+IHZvaWRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFNldHRpbmdzRHJhd2VyKHByb3BzOiBTZXR0aW5nc0RyYXdlclByb3BzKSB7XG4gIGNvbnN0IHsgaXNPcGVuLCBvbkNsb3NlLCBvblVwZGF0ZVNldHRpbmcsIHNldHRpbmdzIH0gPSBwcm9wc1xuXG4gIHJldHVybiAoXG4gICAgPERyYXdlcj5cbiAgICAgIDxEcmF3ZXIuQmFja2Ryb3AgaXNPcGVuPXtpc09wZW59IG9uT3BlbkNoYW5nZT17b25DbG9zZX0gaXNEaXNtaXNzYWJsZT5cbiAgICAgICAgPERyYXdlci5Db250ZW50IHBsYWNlbWVudD1cImJvdHRvbVwiPlxuICAgICAgICAgIDxEcmF3ZXIuRGlhbG9nIGNsYXNzTmFtZT1cInJvdW5kZWQtdC0yeGxcIj5cbiAgICAgICAgICAgIDxEcmF3ZXIuSGFuZGxlIC8+XG4gICAgICAgICAgICA8RHJhd2VyLkNsb3NlVHJpZ2dlciBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNjAwIGhvdmVyOmJnLXNsYXRlLTIwMCBob3Zlcjp0ZXh0LXNsYXRlLTkwMFwiIC8+XG4gICAgICAgICAgICA8RHJhd2VyLkhlYWRlcj5cbiAgICAgICAgICAgICAgPERyYXdlci5IZWFkaW5nPlNldHRpbmdzPC9EcmF3ZXIuSGVhZGluZz5cbiAgICAgICAgICAgIDwvRHJhd2VyLkhlYWRlcj5cbiAgICAgICAgICAgIDxEcmF3ZXIuQm9keT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8U3dpdGNoXG4gICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkPXtzZXR0aW5ncy5zb3VuZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBvblVwZGF0ZVNldHRpbmcoJ3NvdW5kJywgIXNldHRpbmdzLnNvdW5kKX1cbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTb3VuZFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFN3aXRjaC5Db250ZW50PlxuICAgICAgICAgICAgICAgICAgICA8U3dpdGNoLkNvbnRyb2w+XG4gICAgICAgICAgICAgICAgICAgICAgPFN3aXRjaC5UaHVtYiAvPlxuICAgICAgICAgICAgICAgICAgICA8L1N3aXRjaC5Db250cm9sPlxuICAgICAgICAgICAgICAgICAgICBTb3VuZFxuICAgICAgICAgICAgICAgICAgPC9Td2l0Y2guQ29udGVudD5cbiAgICAgICAgICAgICAgICA8L1N3aXRjaD5cblxuICAgICAgICAgICAgICAgIDxTd2l0Y2hcbiAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWQ9e3NldHRpbmdzLnZpYnJhdGlvbn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBvblVwZGF0ZVNldHRpbmcoJ3ZpYnJhdGlvbicsICFzZXR0aW5ncy52aWJyYXRpb24pfVxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlZpYnJhdGlvblwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFN3aXRjaC5Db250ZW50PlxuICAgICAgICAgICAgICAgICAgICA8U3dpdGNoLkNvbnRyb2w+XG4gICAgICAgICAgICAgICAgICAgICAgPFN3aXRjaC5UaHVtYiAvPlxuICAgICAgICAgICAgICAgICAgICA8L1N3aXRjaC5Db250cm9sPlxuICAgICAgICAgICAgICAgICAgICBWaWJyYXRpb25cbiAgICAgICAgICAgICAgICAgIDwvU3dpdGNoLkNvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPC9Td2l0Y2g+XG5cbiAgICAgICAgICAgICAgICA8U3dpdGNoXG4gICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkPXtzZXR0aW5ncy5rZWVwU2NyZWVuQXdha2V9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gb25VcGRhdGVTZXR0aW5nKCdrZWVwU2NyZWVuQXdha2UnLCAhc2V0dGluZ3Mua2VlcFNjcmVlbkF3YWtlKX1cbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJLZWVwIHNjcmVlbiBhd2FrZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFN3aXRjaC5Db250ZW50PlxuICAgICAgICAgICAgICAgICAgICA8U3dpdGNoLkNvbnRyb2w+XG4gICAgICAgICAgICAgICAgICAgICAgPFN3aXRjaC5UaHVtYiAvPlxuICAgICAgICAgICAgICAgICAgICA8L1N3aXRjaC5Db250cm9sPlxuICAgICAgICAgICAgICAgICAgICBLZWVwIHNjcmVlbiBhd2FrZVxuICAgICAgICAgICAgICAgICAgPC9Td2l0Y2guQ29udGVudD5cbiAgICAgICAgICAgICAgICA8L1N3aXRjaD5cblxuICAgICAgICAgICAgICAgIDxTd2l0Y2hcbiAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWQ9e3NldHRpbmdzLmhpZ2hDb250cmFzdE1vZGV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gb25VcGRhdGVTZXR0aW5nKCdoaWdoQ29udHJhc3RNb2RlJywgIXNldHRpbmdzLmhpZ2hDb250cmFzdE1vZGUpfVxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkhpZ2gtY29udHJhc3QgbW9kZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFN3aXRjaC5Db250ZW50PlxuICAgICAgICAgICAgICAgICAgICA8U3dpdGNoLkNvbnRyb2w+XG4gICAgICAgICAgICAgICAgICAgICAgPFN3aXRjaC5UaHVtYiAvPlxuICAgICAgICAgICAgICAgICAgICA8L1N3aXRjaC5Db250cm9sPlxuICAgICAgICAgICAgICAgICAgICBIaWdoLWNvbnRyYXN0IG1vZGVcbiAgICAgICAgICAgICAgICAgIDwvU3dpdGNoLkNvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPC9Td2l0Y2g+XG5cbiAgICAgICAgICAgICAgICA8U3dpdGNoXG4gICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkPXtzZXR0aW5ncy5sYXJnZURpZ2l0c01vZGV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gb25VcGRhdGVTZXR0aW5nKCdsYXJnZURpZ2l0c01vZGUnLCAhc2V0dGluZ3MubGFyZ2VEaWdpdHNNb2RlKX1cbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJMYXJnZSBkaWdpdHMgbW9kZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFN3aXRjaC5Db250ZW50PlxuICAgICAgICAgICAgICAgICAgICA8U3dpdGNoLkNvbnRyb2w+XG4gICAgICAgICAgICAgICAgICAgICAgPFN3aXRjaC5UaHVtYiAvPlxuICAgICAgICAgICAgICAgICAgICA8L1N3aXRjaC5Db250cm9sPlxuICAgICAgICAgICAgICAgICAgICBMYXJnZSBkaWdpdHMgbW9kZVxuICAgICAgICAgICAgICAgICAgPC9Td2l0Y2guQ29udGVudD5cbiAgICAgICAgICAgICAgICA8L1N3aXRjaD5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBweC00IHB5LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS04MDBcIj5MYXlvdXQgbW9kZTwvcD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBncmlkIGdyaWQtY29scy0yIGdhcC0yXCIgcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD1cIkxheW91dCBtb2RlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblVwZGF0ZVNldHRpbmcoJ2xheW91dE1vZGUnLCAnYWRhcHRpdmUnKX1cbiAgICAgICAgICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9e3NldHRpbmdzLmxheW91dE1vZGUgPT09ICdhZGFwdGl2ZSd9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcm91bmRlZC1sZyBib3JkZXIgcHgtMyBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTJlbV0gdHJhbnNpdGlvbiAke1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0dGluZ3MubGF5b3V0TW9kZSA9PT0gJ2FkYXB0aXZlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItcHJpbWFyeSBiZy1vcmFuZ2UtNTAgdGV4dC1zbGF0ZS05MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgdGV4dC1zbGF0ZS01MDAgaG92ZXI6Ymctc2xhdGUtNTAnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBBZGFwdGl2ZVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVXBkYXRlU2V0dGluZygnbGF5b3V0TW9kZScsICdjbGFzc2ljJyl9XG4gICAgICAgICAgICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXtzZXR0aW5ncy5sYXlvdXRNb2RlID09PSAnY2xhc3NpYyd9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcm91bmRlZC1sZyBib3JkZXIgcHgtMyBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTJlbV0gdHJhbnNpdGlvbiAke1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0dGluZ3MubGF5b3V0TW9kZSA9PT0gJ2NsYXNzaWMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1wcmltYXJ5IGJnLW9yYW5nZS01MCB0ZXh0LXNsYXRlLTkwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSB0ZXh0LXNsYXRlLTUwMCBob3ZlcjpiZy1zbGF0ZS01MCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIENsYXNzaWNcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L0RyYXdlci5Cb2R5PlxuICAgICAgICAgIDwvRHJhd2VyLkRpYWxvZz5cbiAgICAgICAgPC9EcmF3ZXIuQ29udGVudD5cbiAgICAgIDwvRHJhd2VyLkJhY2tkcm9wPlxuICAgIDwvRHJhd2VyPlxuICApXG59Il0sImZpbGUiOiIvVXNlcnMvcmlja3lzdWxsaXZhbi9Qcm9qZWN0cy9jaGVzcy10aW1lci9zcmMvZmVhdHVyZXMvc2V0dGluZ3MvY29tcG9uZW50cy9TZXR0aW5nc0RyYXdlci50c3gifQ==