import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/setup/components/SetupScreen.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5db2b99c"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Button } from "/node_modules/.vite/deps/@heroui_react.js?v=5db2b99c";
import { PRESETS } from "/src/app/types.ts";
export function SetupScreen(props) {
  return /* @__PURE__ */ jsxDEV("main", { className: "min-h-screen bg-slate-100", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex min-h-screen w-full max-w-xl flex-col px-5 py-8 md:py-10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-6 flex items-center justify-between gap-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center gap-1.5 rounded-full bg-slate-900 px-3 py-1 text-sm font-semibold text-white sm:px-3.5 sm:py-1.5", children: "Zugzwang" }, void 0, false, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
          lineNumber: 39,
          columnNumber: 11
        }, this),
        props.headerActions
      ] }, void 0, true, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      props.actionMessage ? /* @__PURE__ */ jsxDEV(
        "p",
        {
          className: `mb-3 text-sm ${props.actionMessage.tone === "success" ? "text-emerald-700" : props.actionMessage.tone === "error" ? "text-red-600" : "text-slate-600"}`,
          role: "status",
          "aria-live": "polite",
          children: props.actionMessage.text
        },
        void 0,
        false,
        {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
          lineNumber: 45,
          columnNumber: 9
        },
        this
      ) : null,
      /* @__PURE__ */ jsxDEV("p", { className: "sr-only", "aria-live": "polite", "aria-atomic": "true", children: props.liveAnnouncement }, void 0, false, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
        lineNumber: 59,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-balance text-3xl font-semibold tracking-tight text-slate-950 md:text-4xl", children: "Every second counts." }, void 0, false, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
        lineNumber: 63,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-sm text-slate-600 md:text-base", children: "A simple chess timer for over-the-board play." }, void 0, false, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
        lineNumber: 66,
        columnNumber: 9
      }, this),
      props.warningBanner,
      /* @__PURE__ */ jsxDEV("section", { className: "mt-6", "aria-label": "Time control selection", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-2", role: "listbox", "aria-label": "Time control presets", children: [
          PRESETS.map((preset) => {
            const isSelected = props.controlSource === "preset" && preset.id === props.selectedPreset;
            return /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                role: "option",
                "aria-selected": isSelected,
                "aria-label": `Select preset ${preset.label}, ${preset.description}`,
                onClick: () => props.onPresetSelect(preset.id),
                className: `flex flex-col items-center rounded-xl border px-2 py-3 text-center transition ${isSelected ? "border-orange-300 bg-orange-50 ring-1 ring-orange-300/40" : "border-slate-200 bg-white hover:bg-slate-50"}`,
                children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold text-slate-900", children: preset.label }, void 0, false, {
                    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
                    lineNumber: 90,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-500", children: preset.description }, void 0, false, {
                    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
                    lineNumber: 91,
                    columnNumber: 19
                  }, this)
                ]
              },
              preset.id,
              true,
              {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
                lineNumber: 77,
                columnNumber: 17
              },
              this
            );
          }),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              role: "option",
              "aria-selected": props.controlSource === "custom",
              "aria-label": "Use custom time controls",
              onClick: () => props.onControlSourceChange("custom"),
              className: `flex items-center justify-center rounded-xl border px-2 py-3 text-center transition ${props.controlSource === "custom" ? "border-orange-300 bg-orange-50 ring-1 ring-orange-300/40" : "border-slate-200 bg-white hover:bg-slate-50"}`,
              children: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-slate-700", children: "Custom" }, void 0, false, {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
                lineNumber: 108,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
              lineNumber: 96,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
          lineNumber: 72,
          columnNumber: 11
        }, this),
        props.controlSource === "custom" ? /* @__PURE__ */ jsxDEV("div", { className: "mt-3 animate-fade-in rounded-2xl border border-slate-200 bg-white p-4 shadow-sm", "aria-label": "Custom time control", children: /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "base-minutes", className: "block text-sm font-medium text-slate-700", children: "Base minutes" }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
              lineNumber: 116,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: "base-minutes",
                type: "number",
                min: 0,
                step: 1,
                inputMode: "decimal",
                value: props.customBaseMinutes,
                onChange: (event) => props.onCustomBaseMinutesChange(event.target.value),
                onBlur: props.onCustomBaseBlur,
                "aria-invalid": Boolean(props.showCustomBaseError),
                "aria-describedby": props.showCustomBaseError ? "base-minutes-error" : void 0,
                className: "mt-1 h-11 w-full rounded-md border border-slate-300 px-3 text-slate-900 outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20"
              },
              void 0,
              false,
              {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
                lineNumber: 119,
                columnNumber: 19
              },
              this
            ),
            props.showCustomBaseError ? /* @__PURE__ */ jsxDEV("p", { id: "base-minutes-error", className: "mt-1 text-sm text-red-600", children: props.showCustomBaseError }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
              lineNumber: 133,
              columnNumber: 17
            }, this) : null
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
            lineNumber: 115,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "increment-seconds", className: "block text-sm font-medium text-slate-700", children: "Increment seconds" }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
              lineNumber: 140,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: "increment-seconds",
                type: "number",
                min: 0,
                step: 1,
                inputMode: "decimal",
                value: props.customIncrementSeconds,
                onChange: (event) => props.onCustomIncrementSecondsChange(event.target.value),
                onBlur: props.onCustomIncrementBlur,
                "aria-invalid": Boolean(props.showCustomIncrementError),
                "aria-describedby": props.showCustomIncrementError ? "increment-seconds-error" : void 0,
                className: "mt-1 h-11 w-full rounded-md border border-slate-300 px-3 text-slate-900 outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20"
              },
              void 0,
              false,
              {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
                lineNumber: 143,
                columnNumber: 19
              },
              this
            ),
            props.showCustomIncrementError ? /* @__PURE__ */ jsxDEV("p", { id: "increment-seconds-error", className: "mt-1 text-sm text-red-600", children: props.showCustomIncrementError }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
              lineNumber: 157,
              columnNumber: 17
            }, this) : null
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
            lineNumber: 139,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "delay-seconds", className: "block text-sm font-medium text-slate-700", children: "Delay seconds" }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
              lineNumber: 164,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: "delay-seconds",
                type: "number",
                min: 0,
                step: 1,
                inputMode: "decimal",
                value: props.customDelaySeconds,
                onChange: (event) => props.onCustomDelaySecondsChange(event.target.value),
                onBlur: props.onCustomDelayBlur,
                "aria-invalid": Boolean(props.showCustomDelayError),
                "aria-describedby": props.showCustomDelayError ? "delay-seconds-error" : void 0,
                className: "mt-1 h-11 w-full rounded-md border border-slate-300 px-3 text-slate-900 outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20"
              },
              void 0,
              false,
              {
                fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
                lineNumber: 167,
                columnNumber: 19
              },
              this
            ),
            props.showCustomDelayError ? /* @__PURE__ */ jsxDEV("p", { id: "delay-seconds-error", className: "mt-1 text-sm text-red-600", children: props.showCustomDelayError }, void 0, false, {
              fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
              lineNumber: 181,
              columnNumber: 17
            }, this) : null
          ] }, void 0, true, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
            lineNumber: 163,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
          lineNumber: 114,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
          lineNumber: 113,
          columnNumber: 11
        }, this) : null
      ] }, void 0, true, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
        lineNumber: 71,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-auto pt-8", children: [
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            className: "h-14 w-full text-lg font-semibold",
            onPress: props.onStart,
            isDisabled: !props.canStart,
            "aria-label": props.selectedControl ? `Start game with ${props.selectedControl.label}` : "Start game",
            children: "Start"
          },
          void 0,
          false,
          {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
            lineNumber: 192,
            columnNumber: 11
          },
          this
        ),
        (props.attemptedStart || props.controlSource === "custom") && props.startError ? /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", role: "alert", children: props.startError }, void 0, false, {
          fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
          lineNumber: 201,
          columnNumber: 11
        }, this) : null
      ] }, void 0, true, {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
        lineNumber: 191,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    props.settingsDrawer
  ] }, void 0, true, {
    fileName: "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
}
_c = SetupScreen;
var _c;
$RefreshReg$(_c, "SetupScreen");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/rickysullivan/Projects/chess-timer/src/features/setup/components/SetupScreen.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NVO0FBckNWLFNBQVNBLGNBQWM7QUFDdkIsU0FBU0MsZUFBNkU7QUErQi9FLGdCQUFTQyxZQUFZQyxPQUF5QjtBQUNuRCxTQUNFLHVCQUFDLFVBQUssV0FBVSw2QkFDZDtBQUFBLDJCQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSw2SEFBMkgsd0JBQTFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0NBLE1BQU1DO0FBQUFBLFdBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQ0QsTUFBTUUsZ0JBQ0w7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVcsZ0JBQ1RGLE1BQU1FLGNBQWNDLFNBQVMsWUFDekIscUJBQ0FILE1BQU1FLGNBQWNDLFNBQVMsVUFDM0IsaUJBQ0EsZ0JBQWdCO0FBQUEsVUFFeEIsTUFBSztBQUFBLFVBQ0wsYUFBVTtBQUFBLFVBRVRILGdCQUFNRSxjQUFjRTtBQUFBQTtBQUFBQSxRQVh2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFZQSxJQUNFO0FBQUEsTUFDSix1QkFBQyxPQUFFLFdBQVUsV0FBVSxhQUFVLFVBQVMsZUFBWSxRQUNuREosZ0JBQU1LLG9CQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsUUFBRyxXQUFVLGlGQUErRSxvQ0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsNENBQTBDLDZEQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDTCxNQUFNTTtBQUFBQSxNQUVQLHVCQUFDLGFBQVEsV0FBVSxRQUFPLGNBQVcsMEJBQ25DO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBCQUF5QixNQUFLLFdBQVUsY0FBVyx3QkFDL0RSO0FBQUFBLGtCQUFRUyxJQUFJLENBQUNDLFdBQVc7QUFDdkIsa0JBQU1DLGFBQWFULE1BQU1VLGtCQUFrQixZQUFZRixPQUFPRyxPQUFPWCxNQUFNWTtBQUUzRSxtQkFDRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsaUJBQWVIO0FBQUFBLGdCQUNmLGNBQVksaUJBQWlCRCxPQUFPSyxLQUFLLEtBQUtMLE9BQU9NLFdBQVc7QUFBQSxnQkFDaEUsU0FBUyxNQUFNZCxNQUFNZSxlQUFlUCxPQUFPRyxFQUFFO0FBQUEsZ0JBQzdDLFdBQVcsaUZBQ1RGLGFBQ0ksNkRBQ0EsNkNBQTZDO0FBQUEsZ0JBR25EO0FBQUEseUNBQUMsVUFBSyxXQUFVLHdDQUF3Q0QsaUJBQU9LLFNBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFFO0FBQUEsa0JBQ3JFLHVCQUFDLFVBQUssV0FBVSwwQkFBMEJMLGlCQUFPTSxlQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RDtBQUFBO0FBQUE7QUFBQSxjQWJ4RE4sT0FBT0c7QUFBQUEsY0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBZUE7QUFBQSxVQUVKLENBQUM7QUFBQSxVQUVEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxpQkFBZVgsTUFBTVUsa0JBQWtCO0FBQUEsY0FDdkMsY0FBVztBQUFBLGNBQ1gsU0FBUyxNQUFNVixNQUFNZ0Isc0JBQXNCLFFBQVE7QUFBQSxjQUNuRCxXQUFXLHVGQUNUaEIsTUFBTVUsa0JBQWtCLFdBQ3BCLDZEQUNBLDZDQUE2QztBQUFBLGNBR25ELGlDQUFDLFVBQUssV0FBVSx3Q0FBdUMsc0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZEO0FBQUE7QUFBQSxZQVovRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLGFBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQ0E7QUFBQSxRQUVDVixNQUFNVSxrQkFBa0IsV0FDdkIsdUJBQUMsU0FBSSxXQUFVLG1GQUFrRixjQUFXLHVCQUMxRyxpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFNBQVEsZ0JBQWUsV0FBVSw0Q0FBMEMsNEJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILE1BQUs7QUFBQSxnQkFDTCxLQUFLO0FBQUEsZ0JBQ0wsTUFBTTtBQUFBLGdCQUNOLFdBQVU7QUFBQSxnQkFDVixPQUFPVixNQUFNaUI7QUFBQUEsZ0JBQ2IsVUFBVSxDQUFDQyxVQUFVbEIsTUFBTW1CLDBCQUEwQkQsTUFBTUUsT0FBT0MsS0FBSztBQUFBLGdCQUN2RSxRQUFRckIsTUFBTXNCO0FBQUFBLGdCQUNkLGdCQUFjQyxRQUFRdkIsTUFBTXdCLG1CQUFtQjtBQUFBLGdCQUMvQyxvQkFBa0J4QixNQUFNd0Isc0JBQXNCLHVCQUF1QkM7QUFBQUEsZ0JBQ3JFLFdBQVU7QUFBQTtBQUFBLGNBWFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV3FLO0FBQUEsWUFFcEt6QixNQUFNd0Isc0JBQ0wsdUJBQUMsT0FBRSxJQUFHLHNCQUFxQixXQUFVLDZCQUNsQ3hCLGdCQUFNd0IsdUJBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxJQUNFO0FBQUEsZUFyQk47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFNBQVEscUJBQW9CLFdBQVUsNENBQTBDLGlDQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLElBQUc7QUFBQSxnQkFDSCxNQUFLO0FBQUEsZ0JBQ0wsS0FBSztBQUFBLGdCQUNMLE1BQU07QUFBQSxnQkFDTixXQUFVO0FBQUEsZ0JBQ1YsT0FBT3hCLE1BQU0wQjtBQUFBQSxnQkFDYixVQUFVLENBQUNSLFVBQVVsQixNQUFNMkIsK0JBQStCVCxNQUFNRSxPQUFPQyxLQUFLO0FBQUEsZ0JBQzVFLFFBQVFyQixNQUFNNEI7QUFBQUEsZ0JBQ2QsZ0JBQWNMLFFBQVF2QixNQUFNNkIsd0JBQXdCO0FBQUEsZ0JBQ3BELG9CQUFrQjdCLE1BQU02QiwyQkFBMkIsNEJBQTRCSjtBQUFBQSxnQkFDL0UsV0FBVTtBQUFBO0FBQUEsY0FYWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXcUs7QUFBQSxZQUVwS3pCLE1BQU02QiwyQkFDTCx1QkFBQyxPQUFFLElBQUcsMkJBQTBCLFdBQVUsNkJBQ3ZDN0IsZ0JBQU02Qiw0QkFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLElBQ0U7QUFBQSxlQXJCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sU0FBUSxpQkFBZ0IsV0FBVSw0Q0FBMEMsNkJBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILE1BQUs7QUFBQSxnQkFDTCxLQUFLO0FBQUEsZ0JBQ0wsTUFBTTtBQUFBLGdCQUNOLFdBQVU7QUFBQSxnQkFDVixPQUFPN0IsTUFBTThCO0FBQUFBLGdCQUNiLFVBQVUsQ0FBQ1osVUFBVWxCLE1BQU0rQiwyQkFBMkJiLE1BQU1FLE9BQU9DLEtBQUs7QUFBQSxnQkFDeEUsUUFBUXJCLE1BQU1nQztBQUFBQSxnQkFDZCxnQkFBY1QsUUFBUXZCLE1BQU1pQyxvQkFBb0I7QUFBQSxnQkFDaEQsb0JBQWtCakMsTUFBTWlDLHVCQUF1Qix3QkFBd0JSO0FBQUFBLGdCQUN2RSxXQUFVO0FBQUE7QUFBQSxjQVhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdxSztBQUFBLFlBRXBLekIsTUFBTWlDLHVCQUNMLHVCQUFDLE9BQUUsSUFBRyx1QkFBc0IsV0FBVSw2QkFDbkNqQyxnQkFBTWlDLHdCQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFDRTtBQUFBLGVBckJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsYUF2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdFQSxLQXpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEVBLElBQ0U7QUFBQSxXQXJITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0hBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsU0FBU2pDLE1BQU1rQztBQUFBQSxZQUNmLFlBQVksQ0FBQ2xDLE1BQU1tQztBQUFBQSxZQUNuQixjQUFZbkMsTUFBTW9DLGtCQUFrQixtQkFBbUJwQyxNQUFNb0MsZ0JBQWdCdkIsS0FBSyxLQUFLO0FBQUEsWUFBYTtBQUFBO0FBQUEsVUFKdEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxTQUNFYixNQUFNcUMsa0JBQWtCckMsTUFBTVUsa0JBQWtCLGFBQWFWLE1BQU1zQyxhQUNuRSx1QkFBQyxPQUFFLFdBQVUsNkJBQTRCLE1BQUssU0FDM0N0QyxnQkFBTXNDLGNBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBQ0U7QUFBQSxXQWJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLFNBeEtGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5S0E7QUFBQSxJQUNDdEMsTUFBTXVDO0FBQUFBLE9BM0tUO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0S0E7QUFFSjtBQUFDQyxLQWhMZXpDO0FBQVcsSUFBQXlDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkJ1dHRvbiIsIlBSRVNFVFMiLCJTZXR1cFNjcmVlbiIsInByb3BzIiwiaGVhZGVyQWN0aW9ucyIsImFjdGlvbk1lc3NhZ2UiLCJ0b25lIiwidGV4dCIsImxpdmVBbm5vdW5jZW1lbnQiLCJ3YXJuaW5nQmFubmVyIiwibWFwIiwicHJlc2V0IiwiaXNTZWxlY3RlZCIsImNvbnRyb2xTb3VyY2UiLCJpZCIsInNlbGVjdGVkUHJlc2V0IiwibGFiZWwiLCJkZXNjcmlwdGlvbiIsIm9uUHJlc2V0U2VsZWN0Iiwib25Db250cm9sU291cmNlQ2hhbmdlIiwiY3VzdG9tQmFzZU1pbnV0ZXMiLCJldmVudCIsIm9uQ3VzdG9tQmFzZU1pbnV0ZXNDaGFuZ2UiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm9uQ3VzdG9tQmFzZUJsdXIiLCJCb29sZWFuIiwic2hvd0N1c3RvbUJhc2VFcnJvciIsInVuZGVmaW5lZCIsImN1c3RvbUluY3JlbWVudFNlY29uZHMiLCJvbkN1c3RvbUluY3JlbWVudFNlY29uZHNDaGFuZ2UiLCJvbkN1c3RvbUluY3JlbWVudEJsdXIiLCJzaG93Q3VzdG9tSW5jcmVtZW50RXJyb3IiLCJjdXN0b21EZWxheVNlY29uZHMiLCJvbkN1c3RvbURlbGF5U2Vjb25kc0NoYW5nZSIsIm9uQ3VzdG9tRGVsYXlCbHVyIiwic2hvd0N1c3RvbURlbGF5RXJyb3IiLCJvblN0YXJ0IiwiY2FuU3RhcnQiLCJzZWxlY3RlZENvbnRyb2wiLCJhdHRlbXB0ZWRTdGFydCIsInN0YXJ0RXJyb3IiLCJzZXR0aW5nc0RyYXdlciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNldHVwU2NyZWVuLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQGhlcm91aS9yZWFjdCdcbmltcG9ydCB7IFBSRVNFVFMsIHR5cGUgQWN0aW9uTWVzc2FnZVRvbmUsIHR5cGUgQ29udHJvbFNvdXJjZSwgdHlwZSBUaW1lQ29udHJvbCB9IGZyb20gJ0AvYXBwL3R5cGVzJ1xuXG50eXBlIFNldHVwU2NyZWVuUHJvcHMgPSB7XG4gIGhlYWRlckFjdGlvbnM6IFJlYWN0Tm9kZVxuICB3YXJuaW5nQmFubmVyOiBSZWFjdE5vZGVcbiAgc2V0dGluZ3NEcmF3ZXI6IFJlYWN0Tm9kZVxuICBhY3Rpb25NZXNzYWdlOiB7IHRvbmU6IEFjdGlvbk1lc3NhZ2VUb25lOyB0ZXh0OiBzdHJpbmcgfSB8IG51bGxcbiAgbGl2ZUFubm91bmNlbWVudDogc3RyaW5nXG4gIGNvbnRyb2xTb3VyY2U6IENvbnRyb2xTb3VyY2VcbiAgc2VsZWN0ZWRQcmVzZXQ6IHN0cmluZ1xuICBjdXN0b21CYXNlTWludXRlczogc3RyaW5nXG4gIGN1c3RvbUluY3JlbWVudFNlY29uZHM6IHN0cmluZ1xuICBjdXN0b21EZWxheVNlY29uZHM6IHN0cmluZ1xuICBzaG93Q3VzdG9tQmFzZUVycm9yOiBzdHJpbmcgfCBmYWxzZSB8IG51bGxcbiAgc2hvd0N1c3RvbUluY3JlbWVudEVycm9yOiBzdHJpbmcgfCBmYWxzZSB8IG51bGxcbiAgc2hvd0N1c3RvbURlbGF5RXJyb3I6IHN0cmluZyB8IGZhbHNlIHwgbnVsbFxuICBzZWxlY3RlZENvbnRyb2w6IFRpbWVDb250cm9sIHwgbnVsbFxuICBzdGFydEVycm9yOiBzdHJpbmcgfCBudWxsXG4gIGF0dGVtcHRlZFN0YXJ0OiBib29sZWFuXG4gIGNhblN0YXJ0OiBib29sZWFuXG4gIG9uQ29udHJvbFNvdXJjZUNoYW5nZTogKHNvdXJjZTogQ29udHJvbFNvdXJjZSkgPT4gdm9pZFxuICBvblByZXNldFNlbGVjdDogKHByZXNldElkOiBzdHJpbmcpID0+IHZvaWRcbiAgb25DdXN0b21CYXNlTWludXRlc0NoYW5nZTogKHZhbHVlOiBzdHJpbmcpID0+IHZvaWRcbiAgb25DdXN0b21JbmNyZW1lbnRTZWNvbmRzQ2hhbmdlOiAodmFsdWU6IHN0cmluZykgPT4gdm9pZFxuICBvbkN1c3RvbURlbGF5U2Vjb25kc0NoYW5nZTogKHZhbHVlOiBzdHJpbmcpID0+IHZvaWRcbiAgb25DdXN0b21CYXNlQmx1cjogKCkgPT4gdm9pZFxuICBvbkN1c3RvbUluY3JlbWVudEJsdXI6ICgpID0+IHZvaWRcbiAgb25DdXN0b21EZWxheUJsdXI6ICgpID0+IHZvaWRcbiAgb25TdGFydDogKCkgPT4gdm9pZFxufVxuXG5leHBvcnQgZnVuY3Rpb24gU2V0dXBTY3JlZW4ocHJvcHM6IFNldHVwU2NyZWVuUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtMTAwXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gZmxleCBtaW4taC1zY3JlZW4gdy1mdWxsIG1heC13LXhsIGZsZXgtY29sIHB4LTUgcHktOCBtZDpweS0xMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgYmctc2xhdGUtOTAwIHB4LTMgcHktMSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzbTpweC0zLjUgc206cHktMS41XCI+XG4gICAgICAgICAgICBadWd6d2FuZ1xuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtwcm9wcy5oZWFkZXJBY3Rpb25zfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge3Byb3BzLmFjdGlvbk1lc3NhZ2UgPyAoXG4gICAgICAgICAgPHBcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YG1iLTMgdGV4dC1zbSAke1xuICAgICAgICAgICAgICBwcm9wcy5hY3Rpb25NZXNzYWdlLnRvbmUgPT09ICdzdWNjZXNzJ1xuICAgICAgICAgICAgICAgID8gJ3RleHQtZW1lcmFsZC03MDAnXG4gICAgICAgICAgICAgICAgOiBwcm9wcy5hY3Rpb25NZXNzYWdlLnRvbmUgPT09ICdlcnJvcidcbiAgICAgICAgICAgICAgICAgID8gJ3RleHQtcmVkLTYwMCdcbiAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNjAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICByb2xlPVwic3RhdHVzXCJcbiAgICAgICAgICAgIGFyaWEtbGl2ZT1cInBvbGl0ZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge3Byb3BzLmFjdGlvbk1lc3NhZ2UudGV4dH1cbiAgICAgICAgICA8L3A+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgICA8cCBjbGFzc05hbWU9XCJzci1vbmx5XCIgYXJpYS1saXZlPVwicG9saXRlXCIgYXJpYS1hdG9taWM9XCJ0cnVlXCI+XG4gICAgICAgICAge3Byb3BzLmxpdmVBbm5vdW5jZW1lbnR9XG4gICAgICAgIDwvcD5cblxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1iYWxhbmNlIHRleHQtM3hsIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1zbGF0ZS05NTAgbWQ6dGV4dC00eGxcIj5cbiAgICAgICAgICBFdmVyeSBzZWNvbmQgY291bnRzLlxuICAgICAgICA8L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtc20gdGV4dC1zbGF0ZS02MDAgbWQ6dGV4dC1iYXNlXCI+XG4gICAgICAgICAgQSBzaW1wbGUgY2hlc3MgdGltZXIgZm9yIG92ZXItdGhlLWJvYXJkIHBsYXkuXG4gICAgICAgIDwvcD5cbiAgICAgICAge3Byb3BzLndhcm5pbmdCYW5uZXJ9XG5cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibXQtNlwiIGFyaWEtbGFiZWw9XCJUaW1lIGNvbnRyb2wgc2VsZWN0aW9uXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yXCIgcm9sZT1cImxpc3Rib3hcIiBhcmlhLWxhYmVsPVwiVGltZSBjb250cm9sIHByZXNldHNcIj5cbiAgICAgICAgICAgIHtQUkVTRVRTLm1hcCgocHJlc2V0KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBwcm9wcy5jb250cm9sU291cmNlID09PSAncHJlc2V0JyAmJiBwcmVzZXQuaWQgPT09IHByb3BzLnNlbGVjdGVkUHJlc2V0XG5cbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e3ByZXNldC5pZH1cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgcm9sZT1cIm9wdGlvblwiXG4gICAgICAgICAgICAgICAgICBhcmlhLXNlbGVjdGVkPXtpc1NlbGVjdGVkfVxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YFNlbGVjdCBwcmVzZXQgJHtwcmVzZXQubGFiZWx9LCAke3ByZXNldC5kZXNjcmlwdGlvbn1gfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcHJvcHMub25QcmVzZXRTZWxlY3QocHJlc2V0LmlkKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIHB4LTIgcHktMyB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uICR7XG4gICAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItb3JhbmdlLTMwMCBiZy1vcmFuZ2UtNTAgcmluZy0xIHJpbmctb3JhbmdlLTMwMC80MCdcbiAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIGhvdmVyOmJnLXNsYXRlLTUwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+e3ByZXNldC5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+e3ByZXNldC5kZXNjcmlwdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIH0pfVxuXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICByb2xlPVwib3B0aW9uXCJcbiAgICAgICAgICAgICAgYXJpYS1zZWxlY3RlZD17cHJvcHMuY29udHJvbFNvdXJjZSA9PT0gJ2N1c3RvbSd9XG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJVc2UgY3VzdG9tIHRpbWUgY29udHJvbHNcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBwcm9wcy5vbkNvbnRyb2xTb3VyY2VDaGFuZ2UoJ2N1c3RvbScpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJvcmRlciBweC0yIHB5LTMgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbiAke1xuICAgICAgICAgICAgICAgIHByb3BzLmNvbnRyb2xTb3VyY2UgPT09ICdjdXN0b20nXG4gICAgICAgICAgICAgICAgICA/ICdib3JkZXItb3JhbmdlLTMwMCBiZy1vcmFuZ2UtNTAgcmluZy0xIHJpbmctb3JhbmdlLTMwMC80MCdcbiAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgaG92ZXI6Ymctc2xhdGUtNTAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5DdXN0b208L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHtwcm9wcy5jb250cm9sU291cmNlID09PSAnY3VzdG9tJyA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBhbmltYXRlLWZhZGUtaW4gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcC00IHNoYWRvdy1zbVwiIGFyaWEtbGFiZWw9XCJDdXN0b20gdGltZSBjb250cm9sXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImJhc2UtbWludXRlc1wiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgQmFzZSBtaW51dGVzXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPVwiYmFzZS1taW51dGVzXCJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgIG1pbj17MH1cbiAgICAgICAgICAgICAgICAgICAgc3RlcD17MX1cbiAgICAgICAgICAgICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwcm9wcy5jdXN0b21CYXNlTWludXRlc31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gcHJvcHMub25DdXN0b21CYXNlTWludXRlc0NoYW5nZShldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBvbkJsdXI9e3Byb3BzLm9uQ3VzdG9tQmFzZUJsdXJ9XG4gICAgICAgICAgICAgICAgICAgIGFyaWEtaW52YWxpZD17Qm9vbGVhbihwcm9wcy5zaG93Q3VzdG9tQmFzZUVycm9yKX1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1kZXNjcmliZWRieT17cHJvcHMuc2hvd0N1c3RvbUJhc2VFcnJvciA/ICdiYXNlLW1pbnV0ZXMtZXJyb3InIDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGgtMTEgdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgcHgtMyB0ZXh0LXNsYXRlLTkwMCBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbiBmb2N1czpib3JkZXItcHJpbWFyeSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5LzIwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICB7cHJvcHMuc2hvd0N1c3RvbUJhc2VFcnJvciA/IChcbiAgICAgICAgICAgICAgICAgICAgPHAgaWQ9XCJiYXNlLW1pbnV0ZXMtZXJyb3JcIiBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3Byb3BzLnNob3dDdXN0b21CYXNlRXJyb3J9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiaW5jcmVtZW50LXNlY29uZHNcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIEluY3JlbWVudCBzZWNvbmRzXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPVwiaW5jcmVtZW50LXNlY29uZHNcIlxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgbWluPXswfVxuICAgICAgICAgICAgICAgICAgICBzdGVwPXsxfVxuICAgICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJkZWNpbWFsXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Byb3BzLmN1c3RvbUluY3JlbWVudFNlY29uZHN9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHByb3BzLm9uQ3VzdG9tSW5jcmVtZW50U2Vjb25kc0NoYW5nZShldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBvbkJsdXI9e3Byb3BzLm9uQ3VzdG9tSW5jcmVtZW50Qmx1cn1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1pbnZhbGlkPXtCb29sZWFuKHByb3BzLnNob3dDdXN0b21JbmNyZW1lbnRFcnJvcil9XG4gICAgICAgICAgICAgICAgICAgIGFyaWEtZGVzY3JpYmVkYnk9e3Byb3BzLnNob3dDdXN0b21JbmNyZW1lbnRFcnJvciA/ICdpbmNyZW1lbnQtc2Vjb25kcy1lcnJvcicgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgaC0xMSB3LWZ1bGwgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBweC0zIHRleHQtc2xhdGUtOTAwIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uIGZvY3VzOmJvcmRlci1wcmltYXJ5IGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnkvMjBcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIHtwcm9wcy5zaG93Q3VzdG9tSW5jcmVtZW50RXJyb3IgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGlkPVwiaW5jcmVtZW50LXNlY29uZHMtZXJyb3JcIiBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3Byb3BzLnNob3dDdXN0b21JbmNyZW1lbnRFcnJvcn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkZWxheS1zZWNvbmRzXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICBEZWxheSBzZWNvbmRzXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZGVsYXktc2Vjb25kc1wiXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICBtaW49ezB9XG4gICAgICAgICAgICAgICAgICAgIHN0ZXA9ezF9XG4gICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cHJvcHMuY3VzdG9tRGVsYXlTZWNvbmRzfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBwcm9wcy5vbkN1c3RvbURlbGF5U2Vjb25kc0NoYW5nZShldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBvbkJsdXI9e3Byb3BzLm9uQ3VzdG9tRGVsYXlCbHVyfVxuICAgICAgICAgICAgICAgICAgICBhcmlhLWludmFsaWQ9e0Jvb2xlYW4ocHJvcHMuc2hvd0N1c3RvbURlbGF5RXJyb3IpfVxuICAgICAgICAgICAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXtwcm9wcy5zaG93Q3VzdG9tRGVsYXlFcnJvciA/ICdkZWxheS1zZWNvbmRzLWVycm9yJyA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBoLTExIHctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHB4LTMgdGV4dC1zbGF0ZS05MDAgb3V0bGluZS1ub25lIHRyYW5zaXRpb24gZm9jdXM6Ym9yZGVyLXByaW1hcnkgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHJpbWFyeS8yMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAge3Byb3BzLnNob3dDdXN0b21EZWxheUVycm9yID8gKFxuICAgICAgICAgICAgICAgICAgICA8cCBpZD1cImRlbGF5LXNlY29uZHMtZXJyb3JcIiBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3Byb3BzLnNob3dDdXN0b21EZWxheUVycm9yfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtYXV0byBwdC04XCI+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xNCB3LWZ1bGwgdGV4dC1sZyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgIG9uUHJlc3M9e3Byb3BzLm9uU3RhcnR9XG4gICAgICAgICAgICBpc0Rpc2FibGVkPXshcHJvcHMuY2FuU3RhcnR9XG4gICAgICAgICAgICBhcmlhLWxhYmVsPXtwcm9wcy5zZWxlY3RlZENvbnRyb2wgPyBgU3RhcnQgZ2FtZSB3aXRoICR7cHJvcHMuc2VsZWN0ZWRDb250cm9sLmxhYmVsfWAgOiAnU3RhcnQgZ2FtZSd9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgU3RhcnRcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICB7KHByb3BzLmF0dGVtcHRlZFN0YXJ0IHx8IHByb3BzLmNvbnRyb2xTb3VyY2UgPT09ICdjdXN0b20nKSAmJiBwcm9wcy5zdGFydEVycm9yID8gKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgICB7cHJvcHMuc3RhcnRFcnJvcn1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIHtwcm9wcy5zZXR0aW5nc0RyYXdlcn1cbiAgICA8L21haW4+XG4gIClcbn0iXSwiZmlsZSI6Ii9Vc2Vycy9yaWNreXN1bGxpdmFuL1Byb2plY3RzL2NoZXNzLXRpbWVyL3NyYy9mZWF0dXJlcy9zZXR1cC9jb21wb25lbnRzL1NldHVwU2NyZWVuLnRzeCJ9