import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=5db2b99c"; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];
const copyTextToClipboard = async (text) => {
  if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      return false;
    }
  }
  if (typeof document === "undefined") return false;
  try {
    const helper = document.createElement("textarea");
    helper.value = text;
    helper.setAttribute("readonly", "true");
    helper.style.position = "fixed";
    helper.style.opacity = "0";
    document.body.appendChild(helper);
    helper.select();
    const copied = document.execCommand("copy");
    document.body.removeChild(helper);
    return copied;
  } catch {
    return false;
  }
};
export function useInstallShare(options) {
  const { onAppInstalled, onError } = options;
  const [installPromptEvent, setInstallPromptEvent] = useState(null);
  const [isInstalled, setIsInstalled] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined") return;
    const standaloneMatch = window.matchMedia?.("(display-mode: standalone)").matches;
    const iosStandalone = window.navigator.standalone === true;
    if (standaloneMatch || iosStandalone) {
      setIsInstalled(true);
    }
    const handleBeforeInstallPrompt = (event) => {
      const promptEvent = event;
      promptEvent.preventDefault();
      setInstallPromptEvent(promptEvent);
    };
    const handleAppInstalled = () => {
      setIsInstalled(true);
      setInstallPromptEvent(null);
      onAppInstalled?.();
    };
    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleAppInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, [onAppInstalled]);
  const installApp = async () => {
    if (!installPromptEvent) {
      return "unavailable";
    }
    try {
      await installPromptEvent.prompt();
      const choice = await installPromptEvent.userChoice;
      const accepted = choice.outcome === "accepted";
      if (accepted) {
        setIsInstalled(true);
        return "accepted";
      }
      return "dismissed";
    } catch (error) {
      onError?.(error, { operation: "pwa_install" });
      return "error";
    } finally {
      setInstallPromptEvent(null);
    }
  };
  const shareCurrentUrl = async () => {
    if (typeof window === "undefined" || typeof navigator === "undefined") {
      return { method: "copy_link", outcome: "failure" };
    }
    const currentUrl = window.location.href;
    if (typeof navigator.share === "function") {
      try {
        await navigator.share({
          title: "Zugzwang",
          text: "Use this simple chess timer for your next game.",
          url: currentUrl
        });
        return { method: "web_share", outcome: "success" };
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return { method: "web_share", outcome: "canceled" };
        }
        onError?.(error, {
          operation: "web_share"
        });
      }
    }
    const copied = await copyTextToClipboard(currentUrl);
    if (copied) {
      return { method: "copy_link", outcome: "success" };
    }
    return { method: "copy_link", outcome: "failure" };
  };
  return {
    canInstall: Boolean(installPromptEvent) && !isInstalled,
    isInstalled,
    installApp,
    shareCurrentUrl
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUluc3RhbGxTaGFyZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbnR5cGUgQmVmb3JlSW5zdGFsbFByb21wdEV2ZW50ID0gRXZlbnQgJiB7XG4gIHByb21wdDogKCkgPT4gUHJvbWlzZTx2b2lkPlxuICB1c2VyQ2hvaWNlOiBQcm9taXNlPHsgb3V0Y29tZTogJ2FjY2VwdGVkJyB8ICdkaXNtaXNzZWQnOyBwbGF0Zm9ybTogc3RyaW5nIH0+XG59XG5cbmV4cG9ydCB0eXBlIEluc3RhbGxSZXN1bHQgPSAnYWNjZXB0ZWQnIHwgJ2Rpc21pc3NlZCcgfCAndW5hdmFpbGFibGUnIHwgJ2Vycm9yJ1xuXG5leHBvcnQgdHlwZSBTaGFyZVJlc3VsdCA9IHtcbiAgbWV0aG9kOiAnd2ViX3NoYXJlJyB8ICdjb3B5X2xpbmsnXG4gIG91dGNvbWU6ICdzdWNjZXNzJyB8ICdmYWlsdXJlJyB8ICdjYW5jZWxlZCdcbn1cblxudHlwZSBVc2VJbnN0YWxsU2hhcmVPcHRpb25zID0ge1xuICBvbkVycm9yPzogKGVycm9yOiB1bmtub3duLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikgPT4gdm9pZFxuICBvbkFwcEluc3RhbGxlZD86ICgpID0+IHZvaWRcbn1cblxuY29uc3QgY29weVRleHRUb0NsaXBib2FyZCA9IGFzeW5jICh0ZXh0OiBzdHJpbmcpID0+IHtcbiAgaWYgKHR5cGVvZiBuYXZpZ2F0b3IgIT09ICd1bmRlZmluZWQnICYmIG5hdmlnYXRvci5jbGlwYm9hcmQ/LndyaXRlVGV4dCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh0ZXh0KVxuICAgICAgcmV0dXJuIHRydWVcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIGlmICh0eXBlb2YgZG9jdW1lbnQgPT09ICd1bmRlZmluZWQnKSByZXR1cm4gZmFsc2VcblxuICB0cnkge1xuICAgIGNvbnN0IGhlbHBlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3RleHRhcmVhJylcbiAgICBoZWxwZXIudmFsdWUgPSB0ZXh0XG4gICAgaGVscGVyLnNldEF0dHJpYnV0ZSgncmVhZG9ubHknLCAndHJ1ZScpXG4gICAgaGVscGVyLnN0eWxlLnBvc2l0aW9uID0gJ2ZpeGVkJ1xuICAgIGhlbHBlci5zdHlsZS5vcGFjaXR5ID0gJzAnXG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChoZWxwZXIpXG4gICAgaGVscGVyLnNlbGVjdCgpXG4gICAgY29uc3QgY29waWVkID0gZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2NvcHknKVxuICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoaGVscGVyKVxuICAgIHJldHVybiBjb3BpZWRcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUluc3RhbGxTaGFyZShvcHRpb25zOiBVc2VJbnN0YWxsU2hhcmVPcHRpb25zKSB7XG4gIGNvbnN0IHsgb25BcHBJbnN0YWxsZWQsIG9uRXJyb3IgfSA9IG9wdGlvbnNcbiAgY29uc3QgW2luc3RhbGxQcm9tcHRFdmVudCwgc2V0SW5zdGFsbFByb21wdEV2ZW50XSA9IHVzZVN0YXRlPEJlZm9yZUluc3RhbGxQcm9tcHRFdmVudCB8IG51bGw+KG51bGwpXG4gIGNvbnN0IFtpc0luc3RhbGxlZCwgc2V0SXNJbnN0YWxsZWRdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHJldHVyblxuXG4gICAgY29uc3Qgc3RhbmRhbG9uZU1hdGNoID0gd2luZG93Lm1hdGNoTWVkaWE/LignKGRpc3BsYXktbW9kZTogc3RhbmRhbG9uZSknKS5tYXRjaGVzXG4gICAgY29uc3QgaW9zU3RhbmRhbG9uZSA9ICh3aW5kb3cubmF2aWdhdG9yIGFzIE5hdmlnYXRvciAmIHsgc3RhbmRhbG9uZT86IGJvb2xlYW4gfSkuc3RhbmRhbG9uZSA9PT0gdHJ1ZVxuXG4gICAgaWYgKHN0YW5kYWxvbmVNYXRjaCB8fCBpb3NTdGFuZGFsb25lKSB7XG4gICAgICBzZXRJc0luc3RhbGxlZCh0cnVlKVxuICAgIH1cblxuICAgIGNvbnN0IGhhbmRsZUJlZm9yZUluc3RhbGxQcm9tcHQgPSAoZXZlbnQ6IEV2ZW50KSA9PiB7XG4gICAgICBjb25zdCBwcm9tcHRFdmVudCA9IGV2ZW50IGFzIEJlZm9yZUluc3RhbGxQcm9tcHRFdmVudFxuICAgICAgcHJvbXB0RXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgICAgc2V0SW5zdGFsbFByb21wdEV2ZW50KHByb21wdEV2ZW50KVxuICAgIH1cblxuICAgIGNvbnN0IGhhbmRsZUFwcEluc3RhbGxlZCA9ICgpID0+IHtcbiAgICAgIHNldElzSW5zdGFsbGVkKHRydWUpXG4gICAgICBzZXRJbnN0YWxsUHJvbXB0RXZlbnQobnVsbClcbiAgICAgIG9uQXBwSW5zdGFsbGVkPy4oKVxuICAgIH1cblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdiZWZvcmVpbnN0YWxscHJvbXB0JywgaGFuZGxlQmVmb3JlSW5zdGFsbFByb21wdClcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYXBwaW5zdGFsbGVkJywgaGFuZGxlQXBwSW5zdGFsbGVkKVxuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdiZWZvcmVpbnN0YWxscHJvbXB0JywgaGFuZGxlQmVmb3JlSW5zdGFsbFByb21wdClcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdhcHBpbnN0YWxsZWQnLCBoYW5kbGVBcHBJbnN0YWxsZWQpXG4gICAgfVxuICB9LCBbb25BcHBJbnN0YWxsZWRdKVxuXG4gIGNvbnN0IGluc3RhbGxBcHAgPSBhc3luYyAoKTogUHJvbWlzZTxJbnN0YWxsUmVzdWx0PiA9PiB7XG4gICAgaWYgKCFpbnN0YWxsUHJvbXB0RXZlbnQpIHtcbiAgICAgIHJldHVybiAndW5hdmFpbGFibGUnXG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGluc3RhbGxQcm9tcHRFdmVudC5wcm9tcHQoKVxuICAgICAgY29uc3QgY2hvaWNlID0gYXdhaXQgaW5zdGFsbFByb21wdEV2ZW50LnVzZXJDaG9pY2VcbiAgICAgIGNvbnN0IGFjY2VwdGVkID0gY2hvaWNlLm91dGNvbWUgPT09ICdhY2NlcHRlZCdcbiAgICAgIGlmIChhY2NlcHRlZCkge1xuICAgICAgICBzZXRJc0luc3RhbGxlZCh0cnVlKVxuICAgICAgICByZXR1cm4gJ2FjY2VwdGVkJ1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gJ2Rpc21pc3NlZCdcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgb25FcnJvcj8uKGVycm9yLCB7IG9wZXJhdGlvbjogJ3B3YV9pbnN0YWxsJyB9KVxuICAgICAgcmV0dXJuICdlcnJvcidcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SW5zdGFsbFByb21wdEV2ZW50KG51bGwpXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc2hhcmVDdXJyZW50VXJsID0gYXN5bmMgKCk6IFByb21pc2U8U2hhcmVSZXN1bHQ+ID0+IHtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcgfHwgdHlwZW9mIG5hdmlnYXRvciA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHJldHVybiB7IG1ldGhvZDogJ2NvcHlfbGluaycsIG91dGNvbWU6ICdmYWlsdXJlJyB9XG4gICAgfVxuXG4gICAgY29uc3QgY3VycmVudFVybCA9IHdpbmRvdy5sb2NhdGlvbi5ocmVmXG5cbiAgICBpZiAodHlwZW9mIG5hdmlnYXRvci5zaGFyZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgbmF2aWdhdG9yLnNoYXJlKHtcbiAgICAgICAgICB0aXRsZTogJ1p1Z3p3YW5nJyxcbiAgICAgICAgICB0ZXh0OiAnVXNlIHRoaXMgc2ltcGxlIGNoZXNzIHRpbWVyIGZvciB5b3VyIG5leHQgZ2FtZS4nLFxuICAgICAgICAgIHVybDogY3VycmVudFVybCxcbiAgICAgICAgfSlcbiAgICAgICAgcmV0dXJuIHsgbWV0aG9kOiAnd2ViX3NoYXJlJywgb3V0Y29tZTogJ3N1Y2Nlc3MnIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIERPTUV4Y2VwdGlvbiAmJiBlcnJvci5uYW1lID09PSAnQWJvcnRFcnJvcicpIHtcbiAgICAgICAgICByZXR1cm4geyBtZXRob2Q6ICd3ZWJfc2hhcmUnLCBvdXRjb21lOiAnY2FuY2VsZWQnIH1cbiAgICAgICAgfVxuXG4gICAgICAgIG9uRXJyb3I/LihlcnJvciwge1xuICAgICAgICAgIG9wZXJhdGlvbjogJ3dlYl9zaGFyZScsXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgY29waWVkID0gYXdhaXQgY29weVRleHRUb0NsaXBib2FyZChjdXJyZW50VXJsKVxuICAgIGlmIChjb3BpZWQpIHtcbiAgICAgIHJldHVybiB7IG1ldGhvZDogJ2NvcHlfbGluaycsIG91dGNvbWU6ICdzdWNjZXNzJyB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHsgbWV0aG9kOiAnY29weV9saW5rJywgb3V0Y29tZTogJ2ZhaWx1cmUnIH1cbiAgfVxuXG4gIHJldHVybiB7XG4gICAgY2FuSW5zdGFsbDogQm9vbGVhbihpbnN0YWxsUHJvbXB0RXZlbnQpICYmICFpc0luc3RhbGxlZCxcbiAgICBpc0luc3RhbGxlZCxcbiAgICBpbnN0YWxsQXBwLFxuICAgIHNoYXJlQ3VycmVudFVybCxcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFdBQVcsZ0JBQWdCO0FBbUJwQyxNQUFNLHNCQUFzQixPQUFPLFNBQWlCO0FBQ2xELE1BQUksT0FBTyxjQUFjLGVBQWUsVUFBVSxXQUFXLFdBQVc7QUFDdEUsUUFBSTtBQUNGLFlBQU0sVUFBVSxVQUFVLFVBQVUsSUFBSTtBQUN4QyxhQUFPO0FBQUEsSUFDVCxRQUFRO0FBQ04sYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsTUFBSSxPQUFPLGFBQWEsWUFBYSxRQUFPO0FBRTVDLE1BQUk7QUFDRixVQUFNLFNBQVMsU0FBUyxjQUFjLFVBQVU7QUFDaEQsV0FBTyxRQUFRO0FBQ2YsV0FBTyxhQUFhLFlBQVksTUFBTTtBQUN0QyxXQUFPLE1BQU0sV0FBVztBQUN4QixXQUFPLE1BQU0sVUFBVTtBQUN2QixhQUFTLEtBQUssWUFBWSxNQUFNO0FBQ2hDLFdBQU8sT0FBTztBQUNkLFVBQU0sU0FBUyxTQUFTLFlBQVksTUFBTTtBQUMxQyxhQUFTLEtBQUssWUFBWSxNQUFNO0FBQ2hDLFdBQU87QUFBQSxFQUNULFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRU8sZ0JBQVMsZ0JBQWdCLFNBQWlDO0FBQy9ELFFBQU0sRUFBRSxnQkFBZ0IsUUFBUSxJQUFJO0FBQ3BDLFFBQU0sQ0FBQyxvQkFBb0IscUJBQXFCLElBQUksU0FBMEMsSUFBSTtBQUNsRyxRQUFNLENBQUMsYUFBYSxjQUFjLElBQUksU0FBUyxLQUFLO0FBRXBELFlBQVUsTUFBTTtBQUNkLFFBQUksT0FBTyxXQUFXLFlBQWE7QUFFbkMsVUFBTSxrQkFBa0IsT0FBTyxhQUFhLDRCQUE0QixFQUFFO0FBQzFFLFVBQU0sZ0JBQWlCLE9BQU8sVUFBbUQsZUFBZTtBQUVoRyxRQUFJLG1CQUFtQixlQUFlO0FBQ3BDLHFCQUFlLElBQUk7QUFBQSxJQUNyQjtBQUVBLFVBQU0sNEJBQTRCLENBQUMsVUFBaUI7QUFDbEQsWUFBTSxjQUFjO0FBQ3BCLGtCQUFZLGVBQWU7QUFDM0IsNEJBQXNCLFdBQVc7QUFBQSxJQUNuQztBQUVBLFVBQU0scUJBQXFCLE1BQU07QUFDL0IscUJBQWUsSUFBSTtBQUNuQiw0QkFBc0IsSUFBSTtBQUMxQix1QkFBaUI7QUFBQSxJQUNuQjtBQUVBLFdBQU8saUJBQWlCLHVCQUF1Qix5QkFBeUI7QUFDeEUsV0FBTyxpQkFBaUIsZ0JBQWdCLGtCQUFrQjtBQUUxRCxXQUFPLE1BQU07QUFDWCxhQUFPLG9CQUFvQix1QkFBdUIseUJBQXlCO0FBQzNFLGFBQU8sb0JBQW9CLGdCQUFnQixrQkFBa0I7QUFBQSxJQUMvRDtBQUFBLEVBQ0YsR0FBRyxDQUFDLGNBQWMsQ0FBQztBQUVuQixRQUFNLGFBQWEsWUFBb0M7QUFDckQsUUFBSSxDQUFDLG9CQUFvQjtBQUN2QixhQUFPO0FBQUEsSUFDVDtBQUVBLFFBQUk7QUFDRixZQUFNLG1CQUFtQixPQUFPO0FBQ2hDLFlBQU0sU0FBUyxNQUFNLG1CQUFtQjtBQUN4QyxZQUFNLFdBQVcsT0FBTyxZQUFZO0FBQ3BDLFVBQUksVUFBVTtBQUNaLHVCQUFlLElBQUk7QUFDbkIsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPO0FBQUEsSUFDVCxTQUFTLE9BQU87QUFDZCxnQkFBVSxPQUFPLEVBQUUsV0FBVyxjQUFjLENBQUM7QUFDN0MsYUFBTztBQUFBLElBQ1QsVUFBRTtBQUNBLDRCQUFzQixJQUFJO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBRUEsUUFBTSxrQkFBa0IsWUFBa0M7QUFDeEQsUUFBSSxPQUFPLFdBQVcsZUFBZSxPQUFPLGNBQWMsYUFBYTtBQUNyRSxhQUFPLEVBQUUsUUFBUSxhQUFhLFNBQVMsVUFBVTtBQUFBLElBQ25EO0FBRUEsVUFBTSxhQUFhLE9BQU8sU0FBUztBQUVuQyxRQUFJLE9BQU8sVUFBVSxVQUFVLFlBQVk7QUFDekMsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNO0FBQUEsVUFDcEIsT0FBTztBQUFBLFVBQ1AsTUFBTTtBQUFBLFVBQ04sS0FBSztBQUFBLFFBQ1AsQ0FBQztBQUNELGVBQU8sRUFBRSxRQUFRLGFBQWEsU0FBUyxVQUFVO0FBQUEsTUFDbkQsU0FBUyxPQUFPO0FBQ2QsWUFBSSxpQkFBaUIsZ0JBQWdCLE1BQU0sU0FBUyxjQUFjO0FBQ2hFLGlCQUFPLEVBQUUsUUFBUSxhQUFhLFNBQVMsV0FBVztBQUFBLFFBQ3BEO0FBRUEsa0JBQVUsT0FBTztBQUFBLFVBQ2YsV0FBVztBQUFBLFFBQ2IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBRUEsVUFBTSxTQUFTLE1BQU0sb0JBQW9CLFVBQVU7QUFDbkQsUUFBSSxRQUFRO0FBQ1YsYUFBTyxFQUFFLFFBQVEsYUFBYSxTQUFTLFVBQVU7QUFBQSxJQUNuRDtBQUVBLFdBQU8sRUFBRSxRQUFRLGFBQWEsU0FBUyxVQUFVO0FBQUEsRUFDbkQ7QUFFQSxTQUFPO0FBQUEsSUFDTCxZQUFZLFFBQVEsa0JBQWtCLEtBQUssQ0FBQztBQUFBLElBQzVDO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7IiwibmFtZXMiOltdfQ==