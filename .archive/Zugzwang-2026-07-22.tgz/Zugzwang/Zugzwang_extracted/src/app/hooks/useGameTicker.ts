import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=5db2b99c"; const useEffect = __vite__cjsImport0_react["useEffect"];
export function useGameTicker(options) {
  const { phase, isPaused, timeoutSide, tickActiveClock } = options;
  useEffect(() => {
    if (phase !== "started" || isPaused || timeoutSide) return;
    let frameId = 0;
    let lastTimestamp = null;
    const tick = (timestamp) => {
      if (lastTimestamp === null) {
        lastTimestamp = timestamp;
        frameId = requestAnimationFrame(tick);
        return;
      }
      const elapsed = timestamp - lastTimestamp;
      lastTimestamp = timestamp;
      tickActiveClock(elapsed);
      frameId = requestAnimationFrame(tick);
    };
    frameId = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(frameId);
    };
  }, [isPaused, phase, tickActiveClock, timeoutSide]);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUdhbWVUaWNrZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5cbnR5cGUgVXNlR2FtZVRpY2tlck9wdGlvbnMgPSB7XG4gIHBoYXNlOiAnc2V0dXAnIHwgJ3N0YXJ0ZWQnXG4gIGlzUGF1c2VkOiBib29sZWFuXG4gIHRpbWVvdXRTaWRlOiAnV2hpdGUnIHwgJ0JsYWNrJyB8IG51bGxcbiAgdGlja0FjdGl2ZUNsb2NrOiAoZWxhcHNlZE1zOiBudW1iZXIpID0+IHZvaWRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUdhbWVUaWNrZXIob3B0aW9uczogVXNlR2FtZVRpY2tlck9wdGlvbnMpIHtcbiAgY29uc3QgeyBwaGFzZSwgaXNQYXVzZWQsIHRpbWVvdXRTaWRlLCB0aWNrQWN0aXZlQ2xvY2sgfSA9IG9wdGlvbnNcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwaGFzZSAhPT0gJ3N0YXJ0ZWQnIHx8IGlzUGF1c2VkIHx8IHRpbWVvdXRTaWRlKSByZXR1cm5cblxuICAgIGxldCBmcmFtZUlkID0gMFxuICAgIGxldCBsYXN0VGltZXN0YW1wOiBudW1iZXIgfCBudWxsID0gbnVsbFxuXG4gICAgY29uc3QgdGljayA9ICh0aW1lc3RhbXA6IG51bWJlcikgPT4ge1xuICAgICAgaWYgKGxhc3RUaW1lc3RhbXAgPT09IG51bGwpIHtcbiAgICAgICAgbGFzdFRpbWVzdGFtcCA9IHRpbWVzdGFtcFxuICAgICAgICBmcmFtZUlkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHRpY2spXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCBlbGFwc2VkID0gdGltZXN0YW1wIC0gbGFzdFRpbWVzdGFtcFxuICAgICAgbGFzdFRpbWVzdGFtcCA9IHRpbWVzdGFtcFxuICAgICAgdGlja0FjdGl2ZUNsb2NrKGVsYXBzZWQpXG4gICAgICBmcmFtZUlkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHRpY2spXG4gICAgfVxuXG4gICAgZnJhbWVJZCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh0aWNrKVxuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNhbmNlbEFuaW1hdGlvbkZyYW1lKGZyYW1lSWQpXG4gICAgfVxuICB9LCBbaXNQYXVzZWQsIHBoYXNlLCB0aWNrQWN0aXZlQ2xvY2ssIHRpbWVvdXRTaWRlXSlcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFTbkIsZ0JBQVMsY0FBYyxTQUErQjtBQUMzRCxRQUFNLEVBQUUsT0FBTyxVQUFVLGFBQWEsZ0JBQWdCLElBQUk7QUFFMUQsWUFBVSxNQUFNO0FBQ2QsUUFBSSxVQUFVLGFBQWEsWUFBWSxZQUFhO0FBRXBELFFBQUksVUFBVTtBQUNkLFFBQUksZ0JBQStCO0FBRW5DLFVBQU0sT0FBTyxDQUFDLGNBQXNCO0FBQ2xDLFVBQUksa0JBQWtCLE1BQU07QUFDMUIsd0JBQWdCO0FBQ2hCLGtCQUFVLHNCQUFzQixJQUFJO0FBQ3BDO0FBQUEsTUFDRjtBQUVBLFlBQU0sVUFBVSxZQUFZO0FBQzVCLHNCQUFnQjtBQUNoQixzQkFBZ0IsT0FBTztBQUN2QixnQkFBVSxzQkFBc0IsSUFBSTtBQUFBLElBQ3RDO0FBRUEsY0FBVSxzQkFBc0IsSUFBSTtBQUVwQyxXQUFPLE1BQU07QUFDWCwyQkFBcUIsT0FBTztBQUFBLElBQzlCO0FBQUEsRUFDRixHQUFHLENBQUMsVUFBVSxPQUFPLGlCQUFpQixXQUFXLENBQUM7QUFDcEQ7IiwibmFtZXMiOltdfQ==