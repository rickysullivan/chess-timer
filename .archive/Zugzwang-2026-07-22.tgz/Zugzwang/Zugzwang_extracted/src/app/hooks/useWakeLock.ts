import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=5db2b99c"; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];
export function useWakeLock(options) {
  const { enabled, onError } = options;
  const sentinelRef = useRef(null);
  useEffect(() => {
    if (typeof document === "undefined" || typeof navigator === "undefined") return;
    const wakeLock = navigator.wakeLock;
    if (!wakeLock) return;
    let cancelled = false;
    const releaseWakeLock = async () => {
      const sentinel = sentinelRef.current;
      if (!sentinel) return;
      sentinelRef.current = null;
      try {
        await sentinel.release();
      } catch (error) {
        onError?.(error, {
          operation: "wake_lock_release",
          keep_screen_awake: enabled
        });
      }
    };
    const requestWakeLock = async () => {
      if (!enabled || document.visibilityState !== "visible") {
        await releaseWakeLock();
        return;
      }
      if (sentinelRef.current) return;
      try {
        const sentinel = await wakeLock.request("screen");
        if (cancelled) {
          await sentinel.release();
          return;
        }
        sentinelRef.current = sentinel;
        sentinel.addEventListener?.("release", () => {
          if (sentinelRef.current === sentinel) {
            sentinelRef.current = null;
          }
        });
      } catch (error) {
        onError?.(error, {
          operation: "wake_lock_request",
          keep_screen_awake: enabled
        });
        sentinelRef.current = null;
      }
    };
    void requestWakeLock();
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        void requestWakeLock();
      } else {
        void releaseWakeLock();
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      cancelled = true;
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      void releaseWakeLock();
    };
  }, [enabled, onError]);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZVdha2VMb2NrLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5cbnR5cGUgV2FrZUxvY2tTZW50aW5lbExpa2UgPSB7XG4gIHJlbGVhc2U6ICgpID0+IFByb21pc2U8dm9pZD5cbiAgYWRkRXZlbnRMaXN0ZW5lcj86ICh0eXBlOiAncmVsZWFzZScsIGxpc3RlbmVyOiAoKSA9PiB2b2lkKSA9PiB2b2lkXG59XG5cbnR5cGUgV2FrZUxvY2tMaWtlID0ge1xuICByZXF1ZXN0OiAodHlwZTogJ3NjcmVlbicpID0+IFByb21pc2U8V2FrZUxvY2tTZW50aW5lbExpa2U+XG59XG5cbnR5cGUgVXNlV2FrZUxvY2tPcHRpb25zID0ge1xuICBlbmFibGVkOiBib29sZWFuXG4gIG9uRXJyb3I/OiAoZXJyb3I6IHVua25vd24sIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KSA9PiB2b2lkXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VXYWtlTG9jayhvcHRpb25zOiBVc2VXYWtlTG9ja09wdGlvbnMpIHtcbiAgY29uc3QgeyBlbmFibGVkLCBvbkVycm9yIH0gPSBvcHRpb25zXG4gIGNvbnN0IHNlbnRpbmVsUmVmID0gdXNlUmVmPFdha2VMb2NrU2VudGluZWxMaWtlIHwgbnVsbD4obnVsbClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICh0eXBlb2YgZG9jdW1lbnQgPT09ICd1bmRlZmluZWQnIHx8IHR5cGVvZiBuYXZpZ2F0b3IgPT09ICd1bmRlZmluZWQnKSByZXR1cm5cblxuICAgIGNvbnN0IHdha2VMb2NrID0gKG5hdmlnYXRvciBhcyBOYXZpZ2F0b3IgJiB7IHdha2VMb2NrPzogV2FrZUxvY2tMaWtlIH0pLndha2VMb2NrXG4gICAgaWYgKCF3YWtlTG9jaykgcmV0dXJuXG5cbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2VcblxuICAgIGNvbnN0IHJlbGVhc2VXYWtlTG9jayA9IGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IHNlbnRpbmVsID0gc2VudGluZWxSZWYuY3VycmVudFxuICAgICAgaWYgKCFzZW50aW5lbCkgcmV0dXJuXG4gICAgICBzZW50aW5lbFJlZi5jdXJyZW50ID0gbnVsbFxuXG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBzZW50aW5lbC5yZWxlYXNlKClcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIG9uRXJyb3I/LihlcnJvciwge1xuICAgICAgICAgIG9wZXJhdGlvbjogJ3dha2VfbG9ja19yZWxlYXNlJyxcbiAgICAgICAgICBrZWVwX3NjcmVlbl9hd2FrZTogZW5hYmxlZCxcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCByZXF1ZXN0V2FrZUxvY2sgPSBhc3luYyAoKSA9PiB7XG4gICAgICBpZiAoIWVuYWJsZWQgfHwgZG9jdW1lbnQudmlzaWJpbGl0eVN0YXRlICE9PSAndmlzaWJsZScpIHtcbiAgICAgICAgYXdhaXQgcmVsZWFzZVdha2VMb2NrKClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGlmIChzZW50aW5lbFJlZi5jdXJyZW50KSByZXR1cm5cblxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3Qgc2VudGluZWwgPSBhd2FpdCB3YWtlTG9jay5yZXF1ZXN0KCdzY3JlZW4nKVxuICAgICAgICBpZiAoY2FuY2VsbGVkKSB7XG4gICAgICAgICAgYXdhaXQgc2VudGluZWwucmVsZWFzZSgpXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cblxuICAgICAgICBzZW50aW5lbFJlZi5jdXJyZW50ID0gc2VudGluZWxcbiAgICAgICAgc2VudGluZWwuYWRkRXZlbnRMaXN0ZW5lcj8uKCdyZWxlYXNlJywgKCkgPT4ge1xuICAgICAgICAgIGlmIChzZW50aW5lbFJlZi5jdXJyZW50ID09PSBzZW50aW5lbCkge1xuICAgICAgICAgICAgc2VudGluZWxSZWYuY3VycmVudCA9IG51bGxcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBvbkVycm9yPy4oZXJyb3IsIHtcbiAgICAgICAgICBvcGVyYXRpb246ICd3YWtlX2xvY2tfcmVxdWVzdCcsXG4gICAgICAgICAga2VlcF9zY3JlZW5fYXdha2U6IGVuYWJsZWQsXG4gICAgICAgIH0pXG4gICAgICAgIHNlbnRpbmVsUmVmLmN1cnJlbnQgPSBudWxsXG4gICAgICB9XG4gICAgfVxuXG4gICAgdm9pZCByZXF1ZXN0V2FrZUxvY2soKVxuXG4gICAgY29uc3QgaGFuZGxlVmlzaWJpbGl0eUNoYW5nZSA9ICgpID0+IHtcbiAgICAgIGlmIChkb2N1bWVudC52aXNpYmlsaXR5U3RhdGUgPT09ICd2aXNpYmxlJykge1xuICAgICAgICB2b2lkIHJlcXVlc3RXYWtlTG9jaygpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2b2lkIHJlbGVhc2VXYWtlTG9jaygpXG4gICAgICB9XG4gICAgfVxuXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIGhhbmRsZVZpc2liaWxpdHlDaGFuZ2UpXG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgY2FuY2VsbGVkID0gdHJ1ZVxuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIGhhbmRsZVZpc2liaWxpdHlDaGFuZ2UpXG4gICAgICB2b2lkIHJlbGVhc2VXYWtlTG9jaygpXG4gICAgfVxuICB9LCBbZW5hYmxlZCwgb25FcnJvcl0pXG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsV0FBVyxjQUFjO0FBZ0IzQixnQkFBUyxZQUFZLFNBQTZCO0FBQ3ZELFFBQU0sRUFBRSxTQUFTLFFBQVEsSUFBSTtBQUM3QixRQUFNLGNBQWMsT0FBb0MsSUFBSTtBQUU1RCxZQUFVLE1BQU07QUFDZCxRQUFJLE9BQU8sYUFBYSxlQUFlLE9BQU8sY0FBYyxZQUFhO0FBRXpFLFVBQU0sV0FBWSxVQUFzRDtBQUN4RSxRQUFJLENBQUMsU0FBVTtBQUVmLFFBQUksWUFBWTtBQUVoQixVQUFNLGtCQUFrQixZQUFZO0FBQ2xDLFlBQU0sV0FBVyxZQUFZO0FBQzdCLFVBQUksQ0FBQyxTQUFVO0FBQ2Ysa0JBQVksVUFBVTtBQUV0QixVQUFJO0FBQ0YsY0FBTSxTQUFTLFFBQVE7QUFBQSxNQUN6QixTQUFTLE9BQU87QUFDZCxrQkFBVSxPQUFPO0FBQUEsVUFDZixXQUFXO0FBQUEsVUFDWCxtQkFBbUI7QUFBQSxRQUNyQixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFFQSxVQUFNLGtCQUFrQixZQUFZO0FBQ2xDLFVBQUksQ0FBQyxXQUFXLFNBQVMsb0JBQW9CLFdBQVc7QUFDdEQsY0FBTSxnQkFBZ0I7QUFDdEI7QUFBQSxNQUNGO0FBRUEsVUFBSSxZQUFZLFFBQVM7QUFFekIsVUFBSTtBQUNGLGNBQU0sV0FBVyxNQUFNLFNBQVMsUUFBUSxRQUFRO0FBQ2hELFlBQUksV0FBVztBQUNiLGdCQUFNLFNBQVMsUUFBUTtBQUN2QjtBQUFBLFFBQ0Y7QUFFQSxvQkFBWSxVQUFVO0FBQ3RCLGlCQUFTLG1CQUFtQixXQUFXLE1BQU07QUFDM0MsY0FBSSxZQUFZLFlBQVksVUFBVTtBQUNwQyx3QkFBWSxVQUFVO0FBQUEsVUFDeEI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNILFNBQVMsT0FBTztBQUNkLGtCQUFVLE9BQU87QUFBQSxVQUNmLFdBQVc7QUFBQSxVQUNYLG1CQUFtQjtBQUFBLFFBQ3JCLENBQUM7QUFDRCxvQkFBWSxVQUFVO0FBQUEsTUFDeEI7QUFBQSxJQUNGO0FBRUEsU0FBSyxnQkFBZ0I7QUFFckIsVUFBTSx5QkFBeUIsTUFBTTtBQUNuQyxVQUFJLFNBQVMsb0JBQW9CLFdBQVc7QUFDMUMsYUFBSyxnQkFBZ0I7QUFBQSxNQUN2QixPQUFPO0FBQ0wsYUFBSyxnQkFBZ0I7QUFBQSxNQUN2QjtBQUFBLElBQ0Y7QUFFQSxhQUFTLGlCQUFpQixvQkFBb0Isc0JBQXNCO0FBRXBFLFdBQU8sTUFBTTtBQUNYLGtCQUFZO0FBQ1osZUFBUyxvQkFBb0Isb0JBQW9CLHNCQUFzQjtBQUN2RSxXQUFLLGdCQUFnQjtBQUFBLElBQ3ZCO0FBQUEsRUFDRixHQUFHLENBQUMsU0FBUyxPQUFPLENBQUM7QUFDdkI7IiwibmFtZXMiOltdfQ==