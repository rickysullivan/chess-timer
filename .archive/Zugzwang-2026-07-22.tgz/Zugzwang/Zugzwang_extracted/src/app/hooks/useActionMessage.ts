import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=5db2b99c"; const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];
export function useActionMessage() {
  const [actionMessage, setActionMessage] = useState(null);
  const timeoutRef = useRef(null);
  const showActionMessage = useCallback((tone, text) => {
    setActionMessage({ tone, text });
  }, []);
  useEffect(() => {
    if (!actionMessage || typeof window === "undefined") return;
    if (timeoutRef.current) {
      window.clearTimeout(timeoutRef.current);
    }
    timeoutRef.current = window.setTimeout(() => {
      setActionMessage(null);
      timeoutRef.current = null;
    }, 2800);
    return () => {
      if (timeoutRef.current) {
        window.clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    };
  }, [actionMessage]);
  return { actionMessage, showActionMessage };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUFjdGlvbk1lc3NhZ2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHR5cGUgeyBBY3Rpb25NZXNzYWdlVG9uZSB9IGZyb20gJ0AvYXBwL3R5cGVzJ1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlQWN0aW9uTWVzc2FnZSgpIHtcbiAgY29uc3QgW2FjdGlvbk1lc3NhZ2UsIHNldEFjdGlvbk1lc3NhZ2VdID0gdXNlU3RhdGU8eyB0b25lOiBBY3Rpb25NZXNzYWdlVG9uZTsgdGV4dDogc3RyaW5nIH0gfCBudWxsPihudWxsKVxuICBjb25zdCB0aW1lb3V0UmVmID0gdXNlUmVmPG51bWJlciB8IG51bGw+KG51bGwpXG5cbiAgY29uc3Qgc2hvd0FjdGlvbk1lc3NhZ2UgPSB1c2VDYWxsYmFjaygodG9uZTogQWN0aW9uTWVzc2FnZVRvbmUsIHRleHQ6IHN0cmluZykgPT4ge1xuICAgIHNldEFjdGlvbk1lc3NhZ2UoeyB0b25lLCB0ZXh0IH0pXG4gIH0sIFtdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFhY3Rpb25NZXNzYWdlIHx8IHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnKSByZXR1cm5cblxuICAgIGlmICh0aW1lb3V0UmVmLmN1cnJlbnQpIHtcbiAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQodGltZW91dFJlZi5jdXJyZW50KVxuICAgIH1cblxuICAgIHRpbWVvdXRSZWYuY3VycmVudCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldEFjdGlvbk1lc3NhZ2UobnVsbClcbiAgICAgIHRpbWVvdXRSZWYuY3VycmVudCA9IG51bGxcbiAgICB9LCAyODAwKVxuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmICh0aW1lb3V0UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgd2luZG93LmNsZWFyVGltZW91dCh0aW1lb3V0UmVmLmN1cnJlbnQpXG4gICAgICAgIHRpbWVvdXRSZWYuY3VycmVudCA9IG51bGxcbiAgICAgIH1cbiAgICB9XG4gIH0sIFthY3Rpb25NZXNzYWdlXSlcblxuICByZXR1cm4geyBhY3Rpb25NZXNzYWdlLCBzaG93QWN0aW9uTWVzc2FnZSB9XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsYUFBYSxXQUFXLFFBQVEsZ0JBQWdCO0FBR2xELGdCQUFTLG1CQUFtQjtBQUNqQyxRQUFNLENBQUMsZUFBZSxnQkFBZ0IsSUFBSSxTQUEyRCxJQUFJO0FBQ3pHLFFBQU0sYUFBYSxPQUFzQixJQUFJO0FBRTdDLFFBQU0sb0JBQW9CLFlBQVksQ0FBQyxNQUF5QixTQUFpQjtBQUMvRSxxQkFBaUIsRUFBRSxNQUFNLEtBQUssQ0FBQztBQUFBLEVBQ2pDLEdBQUcsQ0FBQyxDQUFDO0FBRUwsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDLGlCQUFpQixPQUFPLFdBQVcsWUFBYTtBQUVyRCxRQUFJLFdBQVcsU0FBUztBQUN0QixhQUFPLGFBQWEsV0FBVyxPQUFPO0FBQUEsSUFDeEM7QUFFQSxlQUFXLFVBQVUsT0FBTyxXQUFXLE1BQU07QUFDM0MsdUJBQWlCLElBQUk7QUFDckIsaUJBQVcsVUFBVTtBQUFBLElBQ3ZCLEdBQUcsSUFBSTtBQUVQLFdBQU8sTUFBTTtBQUNYLFVBQUksV0FBVyxTQUFTO0FBQ3RCLGVBQU8sYUFBYSxXQUFXLE9BQU87QUFDdEMsbUJBQVcsVUFBVTtBQUFBLE1BQ3ZCO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDLGFBQWEsQ0FBQztBQUVsQixTQUFPLEVBQUUsZUFBZSxrQkFBa0I7QUFDNUM7IiwibmFtZXMiOltdfQ==