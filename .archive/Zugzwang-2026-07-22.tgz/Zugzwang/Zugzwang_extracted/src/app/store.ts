import { create } from "/node_modules/.vite/deps/zustand.js?v=5db2b99c";
import {
  DEFAULT_LAST_USED_CONTROL,
  DEFAULT_SETTINGS,
  PRESETS,
  STORAGE_KEYS
} from "/src/app/types.ts";
const GAME_STATE_MAX_AGE_MS = 30 * 60 * 1e3;
const readStorageItem = (key) => {
  if (typeof window === "undefined") return null;
  try {
    const rawValue = window.localStorage.getItem(key);
    if (!rawValue) return null;
    return JSON.parse(rawValue);
  } catch {
    return null;
  }
};
const getPersistedSettings = () => {
  const persisted = readStorageItem(STORAGE_KEYS.settings);
  if (!persisted) return DEFAULT_SETTINGS;
  return {
    sound: persisted.sound ?? DEFAULT_SETTINGS.sound,
    vibration: persisted.vibration ?? DEFAULT_SETTINGS.vibration,
    keepScreenAwake: persisted.keepScreenAwake ?? DEFAULT_SETTINGS.keepScreenAwake,
    layoutMode: persisted.layoutMode === "classic" ? "classic" : "adaptive",
    highContrastMode: persisted.highContrastMode ?? DEFAULT_SETTINGS.highContrastMode,
    largeDigitsMode: persisted.largeDigitsMode ?? DEFAULT_SETTINGS.largeDigitsMode
  };
};
const getPersistedLastUsedControl = () => {
  const persisted = readStorageItem(STORAGE_KEYS.lastUsedControl);
  if (!persisted) return DEFAULT_LAST_USED_CONTROL;
  const fallbackPresetId = PRESETS[0].id;
  const persistedPresetId = persisted.presetId ?? fallbackPresetId;
  const hasPreset = PRESETS.some((preset) => preset.id === persistedPresetId);
  return {
    source: persisted.source === "custom" ? "custom" : "preset",
    presetId: hasPreset ? persistedPresetId : fallbackPresetId,
    customBaseMinutes: persisted.customBaseMinutes ?? DEFAULT_LAST_USED_CONTROL.customBaseMinutes,
    customIncrementSeconds: persisted.customIncrementSeconds ?? DEFAULT_LAST_USED_CONTROL.customIncrementSeconds,
    customDelaySeconds: persisted.customDelaySeconds ?? DEFAULT_LAST_USED_CONTROL.customDelaySeconds
  };
};
const getPersistedOnboardingSeen = () => {
  const persisted = readStorageItem(STORAGE_KEYS.onboardingSeen);
  return persisted === true;
};
const isTimeControl = (value) => {
  if (!value || typeof value !== "object") return false;
  const candidate = value;
  return typeof candidate.label === "string" && typeof candidate.baseMinutes === "number" && Number.isFinite(candidate.baseMinutes) && candidate.baseMinutes > 0 && typeof candidate.incrementSeconds === "number" && Number.isFinite(candidate.incrementSeconds) && candidate.incrementSeconds >= 0 && typeof candidate.delaySeconds === "number" && Number.isFinite(candidate.delaySeconds) && candidate.delaySeconds >= 0 && (candidate.source === "preset" || candidate.source === "custom");
};
const asPersistedGameState = (value) => {
  if (!value || typeof value !== "object") return null;
  const candidate = value;
  if (candidate.phase !== "started") return null;
  if (candidate.activeSide !== "White" && candidate.activeSide !== "Black") return null;
  if (!candidate.remainingMs || typeof candidate.remainingMs !== "object") return null;
  if (typeof candidate.remainingMs.White !== "number" || typeof candidate.remainingMs.Black !== "number") return null;
  if (typeof candidate.isPaused !== "boolean") return null;
  if (candidate.timeoutSide !== null && candidate.timeoutSide !== "White" && candidate.timeoutSide !== "Black") return null;
  if (typeof candidate.activeDelayRemainingMs !== "number") return null;
  if (!isTimeControl(candidate.startedControl)) return null;
  if (candidate.layoutMode !== "adaptive" && candidate.layoutMode !== "classic") return null;
  if (typeof candidate.last_updated !== "number" || !Number.isFinite(candidate.last_updated)) return null;
  return {
    phase: "started",
    activeSide: candidate.activeSide,
    remainingMs: {
      White: sanitizeMs(candidate.remainingMs.White),
      Black: sanitizeMs(candidate.remainingMs.Black)
    },
    isPaused: candidate.isPaused,
    timeoutSide: candidate.timeoutSide,
    activeDelayRemainingMs: sanitizeMs(candidate.activeDelayRemainingMs),
    startedControl: candidate.startedControl,
    layoutMode: candidate.layoutMode,
    last_updated: sanitizeMs(candidate.last_updated)
  };
};
const otherSide = (side) => side === "White" ? "Black" : "White";
const sanitizeMs = (value) => Math.max(0, Math.round(value));
const getDelayMs = (control) => {
  if (!control) return 0;
  return sanitizeMs(control.delaySeconds * 1e3);
};
const getIncrementMs = (control) => {
  if (!control) return 0;
  return sanitizeMs(control.incrementSeconds * 1e3);
};
export const useAppStore = create((set, get) => {
  const persistedControl = getPersistedLastUsedControl();
  return {
    phase: "setup",
    controlSource: persistedControl.source,
    selectedPreset: persistedControl.presetId,
    customBaseMinutes: persistedControl.customBaseMinutes,
    customIncrementSeconds: persistedControl.customIncrementSeconds,
    customDelaySeconds: persistedControl.customDelaySeconds,
    touched: { base: false, increment: false, delay: false },
    attemptedStart: false,
    startedControl: null,
    activeSide: "White",
    remainingMs: { White: 0, Black: 0 },
    activeDelayRemainingMs: 0,
    isPaused: false,
    timeoutSide: null,
    undoHistory: [],
    settings: getPersistedSettings(),
    onboardingSeen: getPersistedOnboardingSeen(),
    setControlSource: (source) => set({ controlSource: source }),
    setSelectedPreset: (presetId) => set({ selectedPreset: presetId }),
    setCustomBaseMinutes: (value) => set({ customBaseMinutes: value }),
    setCustomIncrementSeconds: (value) => set({ customIncrementSeconds: value }),
    setCustomDelaySeconds: (value) => set({ customDelaySeconds: value }),
    setTouched: (next) => set((state) => ({ touched: { ...state.touched, ...next } })),
    setAttemptedStart: (value) => set({ attemptedStart: value }),
    startGame: (control) => {
      const baseMs = sanitizeMs(control.baseMinutes * 60 * 1e3);
      const delayMs = getDelayMs(control);
      set({
        phase: "started",
        startedControl: control,
        activeSide: "White",
        remainingMs: { White: baseMs, Black: baseMs },
        activeDelayRemainingMs: delayMs,
        undoHistory: [],
        timeoutSide: null,
        isPaused: false
      });
    },
    tickActiveClock: (elapsedMs) => {
      set((state) => {
        if (state.phase !== "started" || state.isPaused || state.timeoutSide || elapsedMs <= 0) {
          return state;
        }
        const elapsed = sanitizeMs(elapsedMs);
        if (elapsed <= 0) return state;
        const side = state.activeSide;
        let remainingDelayMs = state.activeDelayRemainingMs;
        let consumeFromClockMs = elapsed;
        if (remainingDelayMs > 0) {
          const delayConsumed = Math.min(remainingDelayMs, consumeFromClockMs);
          remainingDelayMs -= delayConsumed;
          consumeFromClockMs -= delayConsumed;
        }
        const currentRemainingMs = state.remainingMs[side];
        const nextRemainingMs = Math.max(0, currentRemainingMs - consumeFromClockMs);
        const didClockChange = nextRemainingMs !== currentRemainingMs;
        const didDelayChange = remainingDelayMs !== state.activeDelayRemainingMs;
        if (!didClockChange && !didDelayChange) {
          return state;
        }
        const nextState = {
          activeDelayRemainingMs: remainingDelayMs,
          remainingMs: didClockChange ? { ...state.remainingMs, [side]: nextRemainingMs } : state.remainingMs
        };
        if (nextRemainingMs <= 0 && remainingDelayMs <= 0) {
          nextState.timeoutSide = side;
          nextState.isPaused = true;
        }
        return nextState;
      });
    },
    passTurn: () => {
      const state = get();
      if (state.phase !== "started" || state.isPaused || state.timeoutSide) return null;
      const fromSide = state.activeSide;
      const toSide = otherSide(fromSide);
      const snapshot = {
        activeSide: state.activeSide,
        remainingMs: {
          White: state.remainingMs.White,
          Black: state.remainingMs.Black
        },
        activeDelayRemainingMs: state.activeDelayRemainingMs,
        isPaused: state.isPaused,
        timeoutSide: state.timeoutSide
      };
      const incrementMs = getIncrementMs(state.startedControl);
      const nextRemainingMs = {
        ...state.remainingMs,
        [fromSide]: state.remainingMs[fromSide] + incrementMs
      };
      set({
        undoHistory: [...state.undoHistory, snapshot],
        activeSide: toSide,
        remainingMs: nextRemainingMs,
        activeDelayRemainingMs: getDelayMs(state.startedControl)
      });
      return { fromSide, toSide };
    },
    pauseGame: () => set({ isPaused: true }),
    resumeGame: () => {
      const state = get();
      if (state.timeoutSide) return;
      set({ isPaused: false });
    },
    togglePause: () => {
      const state = get();
      if (state.timeoutSide) return;
      set({ isPaused: !state.isPaused });
    },
    undoTurn: () => {
      const state = get();
      if (state.undoHistory.length === 0) return false;
      const snapshot = state.undoHistory[state.undoHistory.length - 1];
      if (!snapshot) return false;
      set({
        undoHistory: state.undoHistory.slice(0, -1),
        activeSide: snapshot.activeSide,
        remainingMs: snapshot.remainingMs,
        activeDelayRemainingMs: snapshot.activeDelayRemainingMs,
        isPaused: snapshot.isPaused,
        timeoutSide: snapshot.timeoutSide
      });
      return true;
    },
    resetGame: () => {
      const state = get();
      if (!state.startedControl) return;
      const baseMs = sanitizeMs(state.startedControl.baseMinutes * 60 * 1e3);
      set({
        remainingMs: { White: baseMs, Black: baseMs },
        activeSide: "White",
        activeDelayRemainingMs: getDelayMs(state.startedControl),
        undoHistory: [],
        timeoutSide: null,
        isPaused: false
      });
    },
    backToSetup: () => set({ phase: "setup", attemptedStart: false, isPaused: false }),
    updateSetting: (key, value) => set((state) => ({ settings: { ...state.settings, [key]: value } })),
    setOnboardingSeen: (value) => set({ onboardingSeen: value }),
    persistGameState: () => {
      if (typeof window === "undefined") return;
      try {
        const state = get();
        if (state.phase !== "started" || !state.startedControl) {
          window.localStorage.removeItem(STORAGE_KEYS.gameState);
          return;
        }
        const payload = {
          phase: "started",
          activeSide: state.activeSide,
          remainingMs: {
            White: sanitizeMs(state.remainingMs.White),
            Black: sanitizeMs(state.remainingMs.Black)
          },
          isPaused: state.isPaused,
          timeoutSide: state.timeoutSide,
          activeDelayRemainingMs: sanitizeMs(state.activeDelayRemainingMs),
          startedControl: state.startedControl,
          layoutMode: state.settings.layoutMode,
          last_updated: Date.now()
        };
        window.localStorage.setItem(STORAGE_KEYS.gameState, JSON.stringify(payload));
      } catch {
      }
    },
    restorePersistedGameState: () => {
      if (typeof window === "undefined") return "missing";
      const rawPersisted = readStorageItem(STORAGE_KEYS.gameState);
      if (!rawPersisted) return "missing";
      const persisted = asPersistedGameState(rawPersisted);
      if (!persisted) {
        window.localStorage.removeItem(STORAGE_KEYS.gameState);
        return "invalid";
      }
      if (Date.now() - persisted.last_updated > GAME_STATE_MAX_AGE_MS) {
        window.localStorage.removeItem(STORAGE_KEYS.gameState);
        return "expired";
      }
      set((state) => ({
        phase: "started",
        attemptedStart: false,
        startedControl: persisted.startedControl,
        activeSide: persisted.activeSide,
        remainingMs: persisted.remainingMs,
        activeDelayRemainingMs: persisted.activeDelayRemainingMs,
        isPaused: persisted.isPaused,
        timeoutSide: persisted.timeoutSide,
        undoHistory: [],
        settings: {
          ...state.settings,
          layoutMode: persisted.layoutMode
        }
      }));
      return "restored";
    }
  };
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0b3JlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZSB9IGZyb20gJ3p1c3RhbmQnXG5pbXBvcnQge1xuICBERUZBVUxUX0xBU1RfVVNFRF9DT05UUk9MLFxuICBERUZBVUxUX1NFVFRJTkdTLFxuICBQUkVTRVRTLFxuICBTVE9SQUdFX0tFWVMsXG4gIHR5cGUgQXBwU2V0dGluZ3MsXG4gIHR5cGUgQ29udHJvbFNvdXJjZSxcbiAgdHlwZSBMYXN0VXNlZENvbnRyb2wsXG4gIHR5cGUgU2lkZSxcbiAgdHlwZSBUaW1lQ29udHJvbCxcbiAgdHlwZSBUdXJuU25hcHNob3QsXG59IGZyb20gJ0AvYXBwL3R5cGVzJ1xuXG50eXBlIFNldHVwVG91Y2hlZCA9IHtcbiAgYmFzZTogYm9vbGVhblxuICBpbmNyZW1lbnQ6IGJvb2xlYW5cbiAgZGVsYXk6IGJvb2xlYW5cbn1cblxudHlwZSBBcHBTdG9yZSA9IHtcbiAgcGhhc2U6ICdzZXR1cCcgfCAnc3RhcnRlZCdcbiAgY29udHJvbFNvdXJjZTogQ29udHJvbFNvdXJjZVxuICBzZWxlY3RlZFByZXNldDogc3RyaW5nXG4gIGN1c3RvbUJhc2VNaW51dGVzOiBzdHJpbmdcbiAgY3VzdG9tSW5jcmVtZW50U2Vjb25kczogc3RyaW5nXG4gIGN1c3RvbURlbGF5U2Vjb25kczogc3RyaW5nXG4gIHRvdWNoZWQ6IFNldHVwVG91Y2hlZFxuICBhdHRlbXB0ZWRTdGFydDogYm9vbGVhblxuICBzdGFydGVkQ29udHJvbDogVGltZUNvbnRyb2wgfCBudWxsXG4gIGFjdGl2ZVNpZGU6IFNpZGVcbiAgcmVtYWluaW5nTXM6IFJlY29yZDxTaWRlLCBudW1iZXI+XG4gIGFjdGl2ZURlbGF5UmVtYWluaW5nTXM6IG51bWJlclxuICBpc1BhdXNlZDogYm9vbGVhblxuICB0aW1lb3V0U2lkZTogU2lkZSB8IG51bGxcbiAgdW5kb0hpc3Rvcnk6IFR1cm5TbmFwc2hvdFtdXG4gIHNldHRpbmdzOiBBcHBTZXR0aW5nc1xuICBvbmJvYXJkaW5nU2VlbjogYm9vbGVhblxuICBzZXRDb250cm9sU291cmNlOiAoc291cmNlOiBDb250cm9sU291cmNlKSA9PiB2b2lkXG4gIHNldFNlbGVjdGVkUHJlc2V0OiAocHJlc2V0SWQ6IHN0cmluZykgPT4gdm9pZFxuICBzZXRDdXN0b21CYXNlTWludXRlczogKHZhbHVlOiBzdHJpbmcpID0+IHZvaWRcbiAgc2V0Q3VzdG9tSW5jcmVtZW50U2Vjb25kczogKHZhbHVlOiBzdHJpbmcpID0+IHZvaWRcbiAgc2V0Q3VzdG9tRGVsYXlTZWNvbmRzOiAodmFsdWU6IHN0cmluZykgPT4gdm9pZFxuICBzZXRUb3VjaGVkOiAobmV4dDogUGFydGlhbDxTZXR1cFRvdWNoZWQ+KSA9PiB2b2lkXG4gIHNldEF0dGVtcHRlZFN0YXJ0OiAodmFsdWU6IGJvb2xlYW4pID0+IHZvaWRcbiAgc3RhcnRHYW1lOiAoY29udHJvbDogVGltZUNvbnRyb2wpID0+IHZvaWRcbiAgdGlja0FjdGl2ZUNsb2NrOiAoZWxhcHNlZE1zOiBudW1iZXIpID0+IHZvaWRcbiAgcGFzc1R1cm46ICgpID0+IHsgZnJvbVNpZGU6IFNpZGU7IHRvU2lkZTogU2lkZSB9IHwgbnVsbFxuICBwYXVzZUdhbWU6ICgpID0+IHZvaWRcbiAgcmVzdW1lR2FtZTogKCkgPT4gdm9pZFxuICB0b2dnbGVQYXVzZTogKCkgPT4gdm9pZFxuICB1bmRvVHVybjogKCkgPT4gYm9vbGVhblxuICByZXNldEdhbWU6ICgpID0+IHZvaWRcbiAgYmFja1RvU2V0dXA6ICgpID0+IHZvaWRcbiAgdXBkYXRlU2V0dGluZzogPEsgZXh0ZW5kcyBrZXlvZiBBcHBTZXR0aW5ncz4oa2V5OiBLLCB2YWx1ZTogQXBwU2V0dGluZ3NbS10pID0+IHZvaWRcbiAgc2V0T25ib2FyZGluZ1NlZW46ICh2YWx1ZTogYm9vbGVhbikgPT4gdm9pZFxuICBwZXJzaXN0R2FtZVN0YXRlOiAoKSA9PiB2b2lkXG4gIHJlc3RvcmVQZXJzaXN0ZWRHYW1lU3RhdGU6ICgpID0+ICdyZXN0b3JlZCcgfCAnZXhwaXJlZCcgfCAnbWlzc2luZycgfCAnaW52YWxpZCdcbn1cblxudHlwZSBQZXJzaXN0ZWRHYW1lU3RhdGUgPSB7XG4gIHBoYXNlOiAnc3RhcnRlZCdcbiAgYWN0aXZlU2lkZTogU2lkZVxuICByZW1haW5pbmdNczogUmVjb3JkPFNpZGUsIG51bWJlcj5cbiAgaXNQYXVzZWQ6IGJvb2xlYW5cbiAgdGltZW91dFNpZGU6IFNpZGUgfCBudWxsXG4gIGFjdGl2ZURlbGF5UmVtYWluaW5nTXM6IG51bWJlclxuICBzdGFydGVkQ29udHJvbDogVGltZUNvbnRyb2xcbiAgbGF5b3V0TW9kZTogQXBwU2V0dGluZ3NbJ2xheW91dE1vZGUnXVxuICBsYXN0X3VwZGF0ZWQ6IG51bWJlclxufVxuXG5jb25zdCBHQU1FX1NUQVRFX01BWF9BR0VfTVMgPSAzMCAqIDYwICogMTAwMFxuXG5jb25zdCByZWFkU3RvcmFnZUl0ZW0gPSA8VCw+KGtleTogc3RyaW5nKTogVCB8IG51bGwgPT4ge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybiBudWxsXG5cbiAgdHJ5IHtcbiAgICBjb25zdCByYXdWYWx1ZSA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpXG4gICAgaWYgKCFyYXdWYWx1ZSkgcmV0dXJuIG51bGxcbiAgICByZXR1cm4gSlNPTi5wYXJzZShyYXdWYWx1ZSkgYXMgVFxuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG59XG5cbmNvbnN0IGdldFBlcnNpc3RlZFNldHRpbmdzID0gKCk6IEFwcFNldHRpbmdzID0+IHtcbiAgY29uc3QgcGVyc2lzdGVkID0gcmVhZFN0b3JhZ2VJdGVtPFBhcnRpYWw8QXBwU2V0dGluZ3M+PihTVE9SQUdFX0tFWVMuc2V0dGluZ3MpXG4gIGlmICghcGVyc2lzdGVkKSByZXR1cm4gREVGQVVMVF9TRVRUSU5HU1xuXG4gIHJldHVybiB7XG4gICAgc291bmQ6IHBlcnNpc3RlZC5zb3VuZCA/PyBERUZBVUxUX1NFVFRJTkdTLnNvdW5kLFxuICAgIHZpYnJhdGlvbjogcGVyc2lzdGVkLnZpYnJhdGlvbiA/PyBERUZBVUxUX1NFVFRJTkdTLnZpYnJhdGlvbixcbiAgICBrZWVwU2NyZWVuQXdha2U6IHBlcnNpc3RlZC5rZWVwU2NyZWVuQXdha2UgPz8gREVGQVVMVF9TRVRUSU5HUy5rZWVwU2NyZWVuQXdha2UsXG4gICAgbGF5b3V0TW9kZTogcGVyc2lzdGVkLmxheW91dE1vZGUgPT09ICdjbGFzc2ljJyA/ICdjbGFzc2ljJyA6ICdhZGFwdGl2ZScsXG4gICAgaGlnaENvbnRyYXN0TW9kZTogcGVyc2lzdGVkLmhpZ2hDb250cmFzdE1vZGUgPz8gREVGQVVMVF9TRVRUSU5HUy5oaWdoQ29udHJhc3RNb2RlLFxuICAgIGxhcmdlRGlnaXRzTW9kZTogcGVyc2lzdGVkLmxhcmdlRGlnaXRzTW9kZSA/PyBERUZBVUxUX1NFVFRJTkdTLmxhcmdlRGlnaXRzTW9kZSxcbiAgfVxufVxuXG5jb25zdCBnZXRQZXJzaXN0ZWRMYXN0VXNlZENvbnRyb2wgPSAoKTogTGFzdFVzZWRDb250cm9sID0+IHtcbiAgY29uc3QgcGVyc2lzdGVkID0gcmVhZFN0b3JhZ2VJdGVtPFBhcnRpYWw8TGFzdFVzZWRDb250cm9sPj4oU1RPUkFHRV9LRVlTLmxhc3RVc2VkQ29udHJvbClcbiAgaWYgKCFwZXJzaXN0ZWQpIHJldHVybiBERUZBVUxUX0xBU1RfVVNFRF9DT05UUk9MXG5cbiAgY29uc3QgZmFsbGJhY2tQcmVzZXRJZCA9IFBSRVNFVFNbMF0uaWRcbiAgY29uc3QgcGVyc2lzdGVkUHJlc2V0SWQgPSBwZXJzaXN0ZWQucHJlc2V0SWQgPz8gZmFsbGJhY2tQcmVzZXRJZFxuICBjb25zdCBoYXNQcmVzZXQgPSBQUkVTRVRTLnNvbWUoKHByZXNldCkgPT4gcHJlc2V0LmlkID09PSBwZXJzaXN0ZWRQcmVzZXRJZClcblxuICByZXR1cm4ge1xuICAgIHNvdXJjZTogcGVyc2lzdGVkLnNvdXJjZSA9PT0gJ2N1c3RvbScgPyAnY3VzdG9tJyA6ICdwcmVzZXQnLFxuICAgIHByZXNldElkOiBoYXNQcmVzZXQgPyBwZXJzaXN0ZWRQcmVzZXRJZCA6IGZhbGxiYWNrUHJlc2V0SWQsXG4gICAgY3VzdG9tQmFzZU1pbnV0ZXM6IHBlcnNpc3RlZC5jdXN0b21CYXNlTWludXRlcyA/PyBERUZBVUxUX0xBU1RfVVNFRF9DT05UUk9MLmN1c3RvbUJhc2VNaW51dGVzLFxuICAgIGN1c3RvbUluY3JlbWVudFNlY29uZHM6IHBlcnNpc3RlZC5jdXN0b21JbmNyZW1lbnRTZWNvbmRzID8/IERFRkFVTFRfTEFTVF9VU0VEX0NPTlRST0wuY3VzdG9tSW5jcmVtZW50U2Vjb25kcyxcbiAgICBjdXN0b21EZWxheVNlY29uZHM6IHBlcnNpc3RlZC5jdXN0b21EZWxheVNlY29uZHMgPz8gREVGQVVMVF9MQVNUX1VTRURfQ09OVFJPTC5jdXN0b21EZWxheVNlY29uZHMsXG4gIH1cbn1cblxuY29uc3QgZ2V0UGVyc2lzdGVkT25ib2FyZGluZ1NlZW4gPSAoKTogYm9vbGVhbiA9PiB7XG4gIGNvbnN0IHBlcnNpc3RlZCA9IHJlYWRTdG9yYWdlSXRlbTxib29sZWFuPihTVE9SQUdFX0tFWVMub25ib2FyZGluZ1NlZW4pXG4gIHJldHVybiBwZXJzaXN0ZWQgPT09IHRydWVcbn1cblxuY29uc3QgaXNUaW1lQ29udHJvbCA9ICh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIFRpbWVDb250cm9sID0+IHtcbiAgaWYgKCF2YWx1ZSB8fCB0eXBlb2YgdmFsdWUgIT09ICdvYmplY3QnKSByZXR1cm4gZmFsc2VcblxuICBjb25zdCBjYW5kaWRhdGUgPSB2YWx1ZSBhcyBQYXJ0aWFsPFRpbWVDb250cm9sPlxuICByZXR1cm4gKFxuICAgIHR5cGVvZiBjYW5kaWRhdGUubGFiZWwgPT09ICdzdHJpbmcnICYmXG4gICAgdHlwZW9mIGNhbmRpZGF0ZS5iYXNlTWludXRlcyA9PT0gJ251bWJlcicgJiZcbiAgICBOdW1iZXIuaXNGaW5pdGUoY2FuZGlkYXRlLmJhc2VNaW51dGVzKSAmJlxuICAgIGNhbmRpZGF0ZS5iYXNlTWludXRlcyA+IDAgJiZcbiAgICB0eXBlb2YgY2FuZGlkYXRlLmluY3JlbWVudFNlY29uZHMgPT09ICdudW1iZXInICYmXG4gICAgTnVtYmVyLmlzRmluaXRlKGNhbmRpZGF0ZS5pbmNyZW1lbnRTZWNvbmRzKSAmJlxuICAgIGNhbmRpZGF0ZS5pbmNyZW1lbnRTZWNvbmRzID49IDAgJiZcbiAgICB0eXBlb2YgY2FuZGlkYXRlLmRlbGF5U2Vjb25kcyA9PT0gJ251bWJlcicgJiZcbiAgICBOdW1iZXIuaXNGaW5pdGUoY2FuZGlkYXRlLmRlbGF5U2Vjb25kcykgJiZcbiAgICBjYW5kaWRhdGUuZGVsYXlTZWNvbmRzID49IDAgJiZcbiAgICAoY2FuZGlkYXRlLnNvdXJjZSA9PT0gJ3ByZXNldCcgfHwgY2FuZGlkYXRlLnNvdXJjZSA9PT0gJ2N1c3RvbScpXG4gIClcbn1cblxuY29uc3QgYXNQZXJzaXN0ZWRHYW1lU3RhdGUgPSAodmFsdWU6IHVua25vd24pOiBQZXJzaXN0ZWRHYW1lU3RhdGUgfCBudWxsID0+IHtcbiAgaWYgKCF2YWx1ZSB8fCB0eXBlb2YgdmFsdWUgIT09ICdvYmplY3QnKSByZXR1cm4gbnVsbFxuXG4gIGNvbnN0IGNhbmRpZGF0ZSA9IHZhbHVlIGFzIFBhcnRpYWw8UGVyc2lzdGVkR2FtZVN0YXRlPlxuICBpZiAoY2FuZGlkYXRlLnBoYXNlICE9PSAnc3RhcnRlZCcpIHJldHVybiBudWxsXG4gIGlmIChjYW5kaWRhdGUuYWN0aXZlU2lkZSAhPT0gJ1doaXRlJyAmJiBjYW5kaWRhdGUuYWN0aXZlU2lkZSAhPT0gJ0JsYWNrJykgcmV0dXJuIG51bGxcbiAgaWYgKCFjYW5kaWRhdGUucmVtYWluaW5nTXMgfHwgdHlwZW9mIGNhbmRpZGF0ZS5yZW1haW5pbmdNcyAhPT0gJ29iamVjdCcpIHJldHVybiBudWxsXG4gIGlmICh0eXBlb2YgY2FuZGlkYXRlLnJlbWFpbmluZ01zLldoaXRlICE9PSAnbnVtYmVyJyB8fCB0eXBlb2YgY2FuZGlkYXRlLnJlbWFpbmluZ01zLkJsYWNrICE9PSAnbnVtYmVyJykgcmV0dXJuIG51bGxcbiAgaWYgKHR5cGVvZiBjYW5kaWRhdGUuaXNQYXVzZWQgIT09ICdib29sZWFuJykgcmV0dXJuIG51bGxcbiAgaWYgKGNhbmRpZGF0ZS50aW1lb3V0U2lkZSAhPT0gbnVsbCAmJiBjYW5kaWRhdGUudGltZW91dFNpZGUgIT09ICdXaGl0ZScgJiYgY2FuZGlkYXRlLnRpbWVvdXRTaWRlICE9PSAnQmxhY2snKSByZXR1cm4gbnVsbFxuICBpZiAodHlwZW9mIGNhbmRpZGF0ZS5hY3RpdmVEZWxheVJlbWFpbmluZ01zICE9PSAnbnVtYmVyJykgcmV0dXJuIG51bGxcbiAgaWYgKCFpc1RpbWVDb250cm9sKGNhbmRpZGF0ZS5zdGFydGVkQ29udHJvbCkpIHJldHVybiBudWxsXG4gIGlmIChjYW5kaWRhdGUubGF5b3V0TW9kZSAhPT0gJ2FkYXB0aXZlJyAmJiBjYW5kaWRhdGUubGF5b3V0TW9kZSAhPT0gJ2NsYXNzaWMnKSByZXR1cm4gbnVsbFxuICBpZiAodHlwZW9mIGNhbmRpZGF0ZS5sYXN0X3VwZGF0ZWQgIT09ICdudW1iZXInIHx8ICFOdW1iZXIuaXNGaW5pdGUoY2FuZGlkYXRlLmxhc3RfdXBkYXRlZCkpIHJldHVybiBudWxsXG5cbiAgcmV0dXJuIHtcbiAgICBwaGFzZTogJ3N0YXJ0ZWQnLFxuICAgIGFjdGl2ZVNpZGU6IGNhbmRpZGF0ZS5hY3RpdmVTaWRlLFxuICAgIHJlbWFpbmluZ01zOiB7XG4gICAgICBXaGl0ZTogc2FuaXRpemVNcyhjYW5kaWRhdGUucmVtYWluaW5nTXMuV2hpdGUpLFxuICAgICAgQmxhY2s6IHNhbml0aXplTXMoY2FuZGlkYXRlLnJlbWFpbmluZ01zLkJsYWNrKSxcbiAgICB9LFxuICAgIGlzUGF1c2VkOiBjYW5kaWRhdGUuaXNQYXVzZWQsXG4gICAgdGltZW91dFNpZGU6IGNhbmRpZGF0ZS50aW1lb3V0U2lkZSxcbiAgICBhY3RpdmVEZWxheVJlbWFpbmluZ01zOiBzYW5pdGl6ZU1zKGNhbmRpZGF0ZS5hY3RpdmVEZWxheVJlbWFpbmluZ01zKSxcbiAgICBzdGFydGVkQ29udHJvbDogY2FuZGlkYXRlLnN0YXJ0ZWRDb250cm9sLFxuICAgIGxheW91dE1vZGU6IGNhbmRpZGF0ZS5sYXlvdXRNb2RlLFxuICAgIGxhc3RfdXBkYXRlZDogc2FuaXRpemVNcyhjYW5kaWRhdGUubGFzdF91cGRhdGVkKSxcbiAgfVxufVxuXG5jb25zdCBvdGhlclNpZGUgPSAoc2lkZTogU2lkZSk6IFNpZGUgPT4gKHNpZGUgPT09ICdXaGl0ZScgPyAnQmxhY2snIDogJ1doaXRlJylcblxuY29uc3Qgc2FuaXRpemVNcyA9ICh2YWx1ZTogbnVtYmVyKSA9PiBNYXRoLm1heCgwLCBNYXRoLnJvdW5kKHZhbHVlKSlcblxuY29uc3QgZ2V0RGVsYXlNcyA9IChjb250cm9sOiBUaW1lQ29udHJvbCB8IG51bGwpID0+IHtcbiAgaWYgKCFjb250cm9sKSByZXR1cm4gMFxuICByZXR1cm4gc2FuaXRpemVNcyhjb250cm9sLmRlbGF5U2Vjb25kcyAqIDEwMDApXG59XG5cbmNvbnN0IGdldEluY3JlbWVudE1zID0gKGNvbnRyb2w6IFRpbWVDb250cm9sIHwgbnVsbCkgPT4ge1xuICBpZiAoIWNvbnRyb2wpIHJldHVybiAwXG4gIHJldHVybiBzYW5pdGl6ZU1zKGNvbnRyb2wuaW5jcmVtZW50U2Vjb25kcyAqIDEwMDApXG59XG5cbmV4cG9ydCBjb25zdCB1c2VBcHBTdG9yZSA9IGNyZWF0ZTxBcHBTdG9yZT4oKHNldCwgZ2V0KSA9PiB7XG4gIGNvbnN0IHBlcnNpc3RlZENvbnRyb2wgPSBnZXRQZXJzaXN0ZWRMYXN0VXNlZENvbnRyb2woKVxuXG4gIHJldHVybiB7XG4gICAgcGhhc2U6ICdzZXR1cCcsXG4gICAgY29udHJvbFNvdXJjZTogcGVyc2lzdGVkQ29udHJvbC5zb3VyY2UsXG4gICAgc2VsZWN0ZWRQcmVzZXQ6IHBlcnNpc3RlZENvbnRyb2wucHJlc2V0SWQsXG4gICAgY3VzdG9tQmFzZU1pbnV0ZXM6IHBlcnNpc3RlZENvbnRyb2wuY3VzdG9tQmFzZU1pbnV0ZXMsXG4gICAgY3VzdG9tSW5jcmVtZW50U2Vjb25kczogcGVyc2lzdGVkQ29udHJvbC5jdXN0b21JbmNyZW1lbnRTZWNvbmRzLFxuICAgIGN1c3RvbURlbGF5U2Vjb25kczogcGVyc2lzdGVkQ29udHJvbC5jdXN0b21EZWxheVNlY29uZHMsXG4gICAgdG91Y2hlZDogeyBiYXNlOiBmYWxzZSwgaW5jcmVtZW50OiBmYWxzZSwgZGVsYXk6IGZhbHNlIH0sXG4gICAgYXR0ZW1wdGVkU3RhcnQ6IGZhbHNlLFxuICAgIHN0YXJ0ZWRDb250cm9sOiBudWxsLFxuICAgIGFjdGl2ZVNpZGU6ICdXaGl0ZScsXG4gICAgcmVtYWluaW5nTXM6IHsgV2hpdGU6IDAsIEJsYWNrOiAwIH0sXG4gICAgYWN0aXZlRGVsYXlSZW1haW5pbmdNczogMCxcbiAgICBpc1BhdXNlZDogZmFsc2UsXG4gICAgdGltZW91dFNpZGU6IG51bGwsXG4gICAgdW5kb0hpc3Rvcnk6IFtdLFxuICAgIHNldHRpbmdzOiBnZXRQZXJzaXN0ZWRTZXR0aW5ncygpLFxuICAgIG9uYm9hcmRpbmdTZWVuOiBnZXRQZXJzaXN0ZWRPbmJvYXJkaW5nU2VlbigpLFxuICAgIHNldENvbnRyb2xTb3VyY2U6IChzb3VyY2UpID0+IHNldCh7IGNvbnRyb2xTb3VyY2U6IHNvdXJjZSB9KSxcbiAgICBzZXRTZWxlY3RlZFByZXNldDogKHByZXNldElkKSA9PiBzZXQoeyBzZWxlY3RlZFByZXNldDogcHJlc2V0SWQgfSksXG4gICAgc2V0Q3VzdG9tQmFzZU1pbnV0ZXM6ICh2YWx1ZSkgPT4gc2V0KHsgY3VzdG9tQmFzZU1pbnV0ZXM6IHZhbHVlIH0pLFxuICAgIHNldEN1c3RvbUluY3JlbWVudFNlY29uZHM6ICh2YWx1ZSkgPT4gc2V0KHsgY3VzdG9tSW5jcmVtZW50U2Vjb25kczogdmFsdWUgfSksXG4gICAgc2V0Q3VzdG9tRGVsYXlTZWNvbmRzOiAodmFsdWUpID0+IHNldCh7IGN1c3RvbURlbGF5U2Vjb25kczogdmFsdWUgfSksXG4gICAgc2V0VG91Y2hlZDogKG5leHQpID0+IHNldCgoc3RhdGUpID0+ICh7IHRvdWNoZWQ6IHsgLi4uc3RhdGUudG91Y2hlZCwgLi4ubmV4dCB9IH0pKSxcbiAgICBzZXRBdHRlbXB0ZWRTdGFydDogKHZhbHVlKSA9PiBzZXQoeyBhdHRlbXB0ZWRTdGFydDogdmFsdWUgfSksXG4gICAgc3RhcnRHYW1lOiAoY29udHJvbCkgPT4ge1xuICAgICAgY29uc3QgYmFzZU1zID0gc2FuaXRpemVNcyhjb250cm9sLmJhc2VNaW51dGVzICogNjAgKiAxMDAwKVxuICAgICAgY29uc3QgZGVsYXlNcyA9IGdldERlbGF5TXMoY29udHJvbClcbiAgICAgIHNldCh7XG4gICAgICAgIHBoYXNlOiAnc3RhcnRlZCcsXG4gICAgICAgIHN0YXJ0ZWRDb250cm9sOiBjb250cm9sLFxuICAgICAgICBhY3RpdmVTaWRlOiAnV2hpdGUnLFxuICAgICAgICByZW1haW5pbmdNczogeyBXaGl0ZTogYmFzZU1zLCBCbGFjazogYmFzZU1zIH0sXG4gICAgICAgIGFjdGl2ZURlbGF5UmVtYWluaW5nTXM6IGRlbGF5TXMsXG4gICAgICAgIHVuZG9IaXN0b3J5OiBbXSxcbiAgICAgICAgdGltZW91dFNpZGU6IG51bGwsXG4gICAgICAgIGlzUGF1c2VkOiBmYWxzZSxcbiAgICAgIH0pXG4gICAgfSxcbiAgICB0aWNrQWN0aXZlQ2xvY2s6IChlbGFwc2VkTXMpID0+IHtcbiAgICAgIHNldCgoc3RhdGUpID0+IHtcbiAgICAgICAgaWYgKHN0YXRlLnBoYXNlICE9PSAnc3RhcnRlZCcgfHwgc3RhdGUuaXNQYXVzZWQgfHwgc3RhdGUudGltZW91dFNpZGUgfHwgZWxhcHNlZE1zIDw9IDApIHtcbiAgICAgICAgICByZXR1cm4gc3RhdGVcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGVsYXBzZWQgPSBzYW5pdGl6ZU1zKGVsYXBzZWRNcylcbiAgICAgICAgaWYgKGVsYXBzZWQgPD0gMCkgcmV0dXJuIHN0YXRlXG5cbiAgICAgICAgY29uc3Qgc2lkZSA9IHN0YXRlLmFjdGl2ZVNpZGVcbiAgICAgICAgbGV0IHJlbWFpbmluZ0RlbGF5TXMgPSBzdGF0ZS5hY3RpdmVEZWxheVJlbWFpbmluZ01zXG4gICAgICAgIGxldCBjb25zdW1lRnJvbUNsb2NrTXMgPSBlbGFwc2VkXG5cbiAgICAgICAgaWYgKHJlbWFpbmluZ0RlbGF5TXMgPiAwKSB7XG4gICAgICAgICAgY29uc3QgZGVsYXlDb25zdW1lZCA9IE1hdGgubWluKHJlbWFpbmluZ0RlbGF5TXMsIGNvbnN1bWVGcm9tQ2xvY2tNcylcbiAgICAgICAgICByZW1haW5pbmdEZWxheU1zIC09IGRlbGF5Q29uc3VtZWRcbiAgICAgICAgICBjb25zdW1lRnJvbUNsb2NrTXMgLT0gZGVsYXlDb25zdW1lZFxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgY3VycmVudFJlbWFpbmluZ01zID0gc3RhdGUucmVtYWluaW5nTXNbc2lkZV1cbiAgICAgICAgY29uc3QgbmV4dFJlbWFpbmluZ01zID0gTWF0aC5tYXgoMCwgY3VycmVudFJlbWFpbmluZ01zIC0gY29uc3VtZUZyb21DbG9ja01zKVxuICAgICAgICBjb25zdCBkaWRDbG9ja0NoYW5nZSA9IG5leHRSZW1haW5pbmdNcyAhPT0gY3VycmVudFJlbWFpbmluZ01zXG4gICAgICAgIGNvbnN0IGRpZERlbGF5Q2hhbmdlID0gcmVtYWluaW5nRGVsYXlNcyAhPT0gc3RhdGUuYWN0aXZlRGVsYXlSZW1haW5pbmdNc1xuXG4gICAgICAgIGlmICghZGlkQ2xvY2tDaGFuZ2UgJiYgIWRpZERlbGF5Q2hhbmdlKSB7XG4gICAgICAgICAgcmV0dXJuIHN0YXRlXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBuZXh0U3RhdGU6IFBhcnRpYWw8QXBwU3RvcmU+ID0ge1xuICAgICAgICAgIGFjdGl2ZURlbGF5UmVtYWluaW5nTXM6IHJlbWFpbmluZ0RlbGF5TXMsXG4gICAgICAgICAgcmVtYWluaW5nTXM6IGRpZENsb2NrQ2hhbmdlID8geyAuLi5zdGF0ZS5yZW1haW5pbmdNcywgW3NpZGVdOiBuZXh0UmVtYWluaW5nTXMgfSA6IHN0YXRlLnJlbWFpbmluZ01zLFxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKG5leHRSZW1haW5pbmdNcyA8PSAwICYmIHJlbWFpbmluZ0RlbGF5TXMgPD0gMCkge1xuICAgICAgICAgIG5leHRTdGF0ZS50aW1lb3V0U2lkZSA9IHNpZGVcbiAgICAgICAgICBuZXh0U3RhdGUuaXNQYXVzZWQgPSB0cnVlXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gbmV4dFN0YXRlIGFzIEFwcFN0b3JlXG4gICAgICB9KVxuICAgIH0sXG4gICAgcGFzc1R1cm46ICgpID0+IHtcbiAgICAgIGNvbnN0IHN0YXRlID0gZ2V0KClcbiAgICAgIGlmIChzdGF0ZS5waGFzZSAhPT0gJ3N0YXJ0ZWQnIHx8IHN0YXRlLmlzUGF1c2VkIHx8IHN0YXRlLnRpbWVvdXRTaWRlKSByZXR1cm4gbnVsbFxuXG4gICAgICBjb25zdCBmcm9tU2lkZSA9IHN0YXRlLmFjdGl2ZVNpZGVcbiAgICAgIGNvbnN0IHRvU2lkZSA9IG90aGVyU2lkZShmcm9tU2lkZSlcbiAgICAgIGNvbnN0IHNuYXBzaG90OiBUdXJuU25hcHNob3QgPSB7XG4gICAgICAgIGFjdGl2ZVNpZGU6IHN0YXRlLmFjdGl2ZVNpZGUsXG4gICAgICAgIHJlbWFpbmluZ01zOiB7XG4gICAgICAgICAgV2hpdGU6IHN0YXRlLnJlbWFpbmluZ01zLldoaXRlLFxuICAgICAgICAgIEJsYWNrOiBzdGF0ZS5yZW1haW5pbmdNcy5CbGFjayxcbiAgICAgICAgfSxcbiAgICAgICAgYWN0aXZlRGVsYXlSZW1haW5pbmdNczogc3RhdGUuYWN0aXZlRGVsYXlSZW1haW5pbmdNcyxcbiAgICAgICAgaXNQYXVzZWQ6IHN0YXRlLmlzUGF1c2VkLFxuICAgICAgICB0aW1lb3V0U2lkZTogc3RhdGUudGltZW91dFNpZGUsXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGluY3JlbWVudE1zID0gZ2V0SW5jcmVtZW50TXMoc3RhdGUuc3RhcnRlZENvbnRyb2wpXG4gICAgICBjb25zdCBuZXh0UmVtYWluaW5nTXMgPSB7XG4gICAgICAgIC4uLnN0YXRlLnJlbWFpbmluZ01zLFxuICAgICAgICBbZnJvbVNpZGVdOiBzdGF0ZS5yZW1haW5pbmdNc1tmcm9tU2lkZV0gKyBpbmNyZW1lbnRNcyxcbiAgICAgIH1cblxuICAgICAgc2V0KHtcbiAgICAgICAgdW5kb0hpc3Rvcnk6IFsuLi5zdGF0ZS51bmRvSGlzdG9yeSwgc25hcHNob3RdLFxuICAgICAgICBhY3RpdmVTaWRlOiB0b1NpZGUsXG4gICAgICAgIHJlbWFpbmluZ01zOiBuZXh0UmVtYWluaW5nTXMsXG4gICAgICAgIGFjdGl2ZURlbGF5UmVtYWluaW5nTXM6IGdldERlbGF5TXMoc3RhdGUuc3RhcnRlZENvbnRyb2wpLFxuICAgICAgfSlcblxuICAgICAgcmV0dXJuIHsgZnJvbVNpZGUsIHRvU2lkZSB9XG4gICAgfSxcbiAgICBwYXVzZUdhbWU6ICgpID0+IHNldCh7IGlzUGF1c2VkOiB0cnVlIH0pLFxuICAgIHJlc3VtZUdhbWU6ICgpID0+IHtcbiAgICAgIGNvbnN0IHN0YXRlID0gZ2V0KClcbiAgICAgIGlmIChzdGF0ZS50aW1lb3V0U2lkZSkgcmV0dXJuXG4gICAgICBzZXQoeyBpc1BhdXNlZDogZmFsc2UgfSlcbiAgICB9LFxuICAgIHRvZ2dsZVBhdXNlOiAoKSA9PiB7XG4gICAgICBjb25zdCBzdGF0ZSA9IGdldCgpXG4gICAgICBpZiAoc3RhdGUudGltZW91dFNpZGUpIHJldHVyblxuICAgICAgc2V0KHsgaXNQYXVzZWQ6ICFzdGF0ZS5pc1BhdXNlZCB9KVxuICAgIH0sXG4gICAgdW5kb1R1cm46ICgpID0+IHtcbiAgICAgIGNvbnN0IHN0YXRlID0gZ2V0KClcbiAgICAgIGlmIChzdGF0ZS51bmRvSGlzdG9yeS5sZW5ndGggPT09IDApIHJldHVybiBmYWxzZVxuXG4gICAgICBjb25zdCBzbmFwc2hvdCA9IHN0YXRlLnVuZG9IaXN0b3J5W3N0YXRlLnVuZG9IaXN0b3J5Lmxlbmd0aCAtIDFdXG4gICAgICBpZiAoIXNuYXBzaG90KSByZXR1cm4gZmFsc2VcblxuICAgICAgc2V0KHtcbiAgICAgICAgdW5kb0hpc3Rvcnk6IHN0YXRlLnVuZG9IaXN0b3J5LnNsaWNlKDAsIC0xKSxcbiAgICAgICAgYWN0aXZlU2lkZTogc25hcHNob3QuYWN0aXZlU2lkZSxcbiAgICAgICAgcmVtYWluaW5nTXM6IHNuYXBzaG90LnJlbWFpbmluZ01zLFxuICAgICAgICBhY3RpdmVEZWxheVJlbWFpbmluZ01zOiBzbmFwc2hvdC5hY3RpdmVEZWxheVJlbWFpbmluZ01zLFxuICAgICAgICBpc1BhdXNlZDogc25hcHNob3QuaXNQYXVzZWQsXG4gICAgICAgIHRpbWVvdXRTaWRlOiBzbmFwc2hvdC50aW1lb3V0U2lkZSxcbiAgICAgIH0pXG5cbiAgICAgIHJldHVybiB0cnVlXG4gICAgfSxcbiAgICByZXNldEdhbWU6ICgpID0+IHtcbiAgICAgIGNvbnN0IHN0YXRlID0gZ2V0KClcbiAgICAgIGlmICghc3RhdGUuc3RhcnRlZENvbnRyb2wpIHJldHVyblxuXG4gICAgICBjb25zdCBiYXNlTXMgPSBzYW5pdGl6ZU1zKHN0YXRlLnN0YXJ0ZWRDb250cm9sLmJhc2VNaW51dGVzICogNjAgKiAxMDAwKVxuICAgICAgc2V0KHtcbiAgICAgICAgcmVtYWluaW5nTXM6IHsgV2hpdGU6IGJhc2VNcywgQmxhY2s6IGJhc2VNcyB9LFxuICAgICAgICBhY3RpdmVTaWRlOiAnV2hpdGUnLFxuICAgICAgICBhY3RpdmVEZWxheVJlbWFpbmluZ01zOiBnZXREZWxheU1zKHN0YXRlLnN0YXJ0ZWRDb250cm9sKSxcbiAgICAgICAgdW5kb0hpc3Rvcnk6IFtdLFxuICAgICAgICB0aW1lb3V0U2lkZTogbnVsbCxcbiAgICAgICAgaXNQYXVzZWQ6IGZhbHNlLFxuICAgICAgfSlcbiAgICB9LFxuICAgIGJhY2tUb1NldHVwOiAoKSA9PiBzZXQoeyBwaGFzZTogJ3NldHVwJywgYXR0ZW1wdGVkU3RhcnQ6IGZhbHNlLCBpc1BhdXNlZDogZmFsc2UgfSksXG4gICAgdXBkYXRlU2V0dGluZzogKGtleSwgdmFsdWUpID0+IHNldCgoc3RhdGUpID0+ICh7IHNldHRpbmdzOiB7IC4uLnN0YXRlLnNldHRpbmdzLCBba2V5XTogdmFsdWUgfSB9KSksXG4gICAgc2V0T25ib2FyZGluZ1NlZW46ICh2YWx1ZSkgPT4gc2V0KHsgb25ib2FyZGluZ1NlZW46IHZhbHVlIH0pLFxuICAgIHBlcnNpc3RHYW1lU3RhdGU6ICgpID0+IHtcbiAgICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykgcmV0dXJuXG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0gZ2V0KClcbiAgICAgICAgaWYgKHN0YXRlLnBoYXNlICE9PSAnc3RhcnRlZCcgfHwgIXN0YXRlLnN0YXJ0ZWRDb250cm9sKSB7XG4gICAgICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFNUT1JBR0VfS0VZUy5nYW1lU3RhdGUpXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBwYXlsb2FkOiBQZXJzaXN0ZWRHYW1lU3RhdGUgPSB7XG4gICAgICAgICAgcGhhc2U6ICdzdGFydGVkJyxcbiAgICAgICAgICBhY3RpdmVTaWRlOiBzdGF0ZS5hY3RpdmVTaWRlLFxuICAgICAgICAgIHJlbWFpbmluZ01zOiB7XG4gICAgICAgICAgICBXaGl0ZTogc2FuaXRpemVNcyhzdGF0ZS5yZW1haW5pbmdNcy5XaGl0ZSksXG4gICAgICAgICAgICBCbGFjazogc2FuaXRpemVNcyhzdGF0ZS5yZW1haW5pbmdNcy5CbGFjayksXG4gICAgICAgICAgfSxcbiAgICAgICAgICBpc1BhdXNlZDogc3RhdGUuaXNQYXVzZWQsXG4gICAgICAgICAgdGltZW91dFNpZGU6IHN0YXRlLnRpbWVvdXRTaWRlLFxuICAgICAgICAgIGFjdGl2ZURlbGF5UmVtYWluaW5nTXM6IHNhbml0aXplTXMoc3RhdGUuYWN0aXZlRGVsYXlSZW1haW5pbmdNcyksXG4gICAgICAgICAgc3RhcnRlZENvbnRyb2w6IHN0YXRlLnN0YXJ0ZWRDb250cm9sLFxuICAgICAgICAgIGxheW91dE1vZGU6IHN0YXRlLnNldHRpbmdzLmxheW91dE1vZGUsXG4gICAgICAgICAgbGFzdF91cGRhdGVkOiBEYXRlLm5vdygpLFxuICAgICAgICB9XG5cbiAgICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFNUT1JBR0VfS0VZUy5nYW1lU3RhdGUsIEpTT04uc3RyaW5naWZ5KHBheWxvYWQpKVxuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8vIG5vb3BcbiAgICAgIH1cbiAgICB9LFxuICAgIHJlc3RvcmVQZXJzaXN0ZWRHYW1lU3RhdGU6ICgpID0+IHtcbiAgICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykgcmV0dXJuICdtaXNzaW5nJ1xuXG4gICAgICBjb25zdCByYXdQZXJzaXN0ZWQgPSByZWFkU3RvcmFnZUl0ZW08dW5rbm93bj4oU1RPUkFHRV9LRVlTLmdhbWVTdGF0ZSlcbiAgICAgIGlmICghcmF3UGVyc2lzdGVkKSByZXR1cm4gJ21pc3NpbmcnXG5cbiAgICAgIGNvbnN0IHBlcnNpc3RlZCA9IGFzUGVyc2lzdGVkR2FtZVN0YXRlKHJhd1BlcnNpc3RlZClcbiAgICAgIGlmICghcGVyc2lzdGVkKSB7XG4gICAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShTVE9SQUdFX0tFWVMuZ2FtZVN0YXRlKVxuICAgICAgICByZXR1cm4gJ2ludmFsaWQnXG4gICAgICB9XG5cbiAgICAgIGlmIChEYXRlLm5vdygpIC0gcGVyc2lzdGVkLmxhc3RfdXBkYXRlZCA+IEdBTUVfU1RBVEVfTUFYX0FHRV9NUykge1xuICAgICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oU1RPUkFHRV9LRVlTLmdhbWVTdGF0ZSlcbiAgICAgICAgcmV0dXJuICdleHBpcmVkJ1xuICAgICAgfVxuXG4gICAgICBzZXQoKHN0YXRlKSA9PiAoe1xuICAgICAgICBwaGFzZTogJ3N0YXJ0ZWQnLFxuICAgICAgICBhdHRlbXB0ZWRTdGFydDogZmFsc2UsXG4gICAgICAgIHN0YXJ0ZWRDb250cm9sOiBwZXJzaXN0ZWQuc3RhcnRlZENvbnRyb2wsXG4gICAgICAgIGFjdGl2ZVNpZGU6IHBlcnNpc3RlZC5hY3RpdmVTaWRlLFxuICAgICAgICByZW1haW5pbmdNczogcGVyc2lzdGVkLnJlbWFpbmluZ01zLFxuICAgICAgICBhY3RpdmVEZWxheVJlbWFpbmluZ01zOiBwZXJzaXN0ZWQuYWN0aXZlRGVsYXlSZW1haW5pbmdNcyxcbiAgICAgICAgaXNQYXVzZWQ6IHBlcnNpc3RlZC5pc1BhdXNlZCxcbiAgICAgICAgdGltZW91dFNpZGU6IHBlcnNpc3RlZC50aW1lb3V0U2lkZSxcbiAgICAgICAgdW5kb0hpc3Rvcnk6IFtdLFxuICAgICAgICBzZXR0aW5nczoge1xuICAgICAgICAgIC4uLnN0YXRlLnNldHRpbmdzLFxuICAgICAgICAgIGxheW91dE1vZGU6IHBlcnNpc3RlZC5sYXlvdXRNb2RlLFxuICAgICAgICB9LFxuICAgICAgfSkpXG5cbiAgICAgIHJldHVybiAncmVzdG9yZWQnXG4gICAgfSxcbiAgfVxufSlcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BT0s7QUE0RFAsTUFBTSx3QkFBd0IsS0FBSyxLQUFLO0FBRXhDLE1BQU0sa0JBQWtCLENBQUssUUFBMEI7QUFDckQsTUFBSSxPQUFPLFdBQVcsWUFBYSxRQUFPO0FBRTFDLE1BQUk7QUFDRixVQUFNLFdBQVcsT0FBTyxhQUFhLFFBQVEsR0FBRztBQUNoRCxRQUFJLENBQUMsU0FBVSxRQUFPO0FBQ3RCLFdBQU8sS0FBSyxNQUFNLFFBQVE7QUFBQSxFQUM1QixRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLE1BQU0sdUJBQXVCLE1BQW1CO0FBQzlDLFFBQU0sWUFBWSxnQkFBc0MsYUFBYSxRQUFRO0FBQzdFLE1BQUksQ0FBQyxVQUFXLFFBQU87QUFFdkIsU0FBTztBQUFBLElBQ0wsT0FBTyxVQUFVLFNBQVMsaUJBQWlCO0FBQUEsSUFDM0MsV0FBVyxVQUFVLGFBQWEsaUJBQWlCO0FBQUEsSUFDbkQsaUJBQWlCLFVBQVUsbUJBQW1CLGlCQUFpQjtBQUFBLElBQy9ELFlBQVksVUFBVSxlQUFlLFlBQVksWUFBWTtBQUFBLElBQzdELGtCQUFrQixVQUFVLG9CQUFvQixpQkFBaUI7QUFBQSxJQUNqRSxpQkFBaUIsVUFBVSxtQkFBbUIsaUJBQWlCO0FBQUEsRUFDakU7QUFDRjtBQUVBLE1BQU0sOEJBQThCLE1BQXVCO0FBQ3pELFFBQU0sWUFBWSxnQkFBMEMsYUFBYSxlQUFlO0FBQ3hGLE1BQUksQ0FBQyxVQUFXLFFBQU87QUFFdkIsUUFBTSxtQkFBbUIsUUFBUSxDQUFDLEVBQUU7QUFDcEMsUUFBTSxvQkFBb0IsVUFBVSxZQUFZO0FBQ2hELFFBQU0sWUFBWSxRQUFRLEtBQUssQ0FBQyxXQUFXLE9BQU8sT0FBTyxpQkFBaUI7QUFFMUUsU0FBTztBQUFBLElBQ0wsUUFBUSxVQUFVLFdBQVcsV0FBVyxXQUFXO0FBQUEsSUFDbkQsVUFBVSxZQUFZLG9CQUFvQjtBQUFBLElBQzFDLG1CQUFtQixVQUFVLHFCQUFxQiwwQkFBMEI7QUFBQSxJQUM1RSx3QkFBd0IsVUFBVSwwQkFBMEIsMEJBQTBCO0FBQUEsSUFDdEYsb0JBQW9CLFVBQVUsc0JBQXNCLDBCQUEwQjtBQUFBLEVBQ2hGO0FBQ0Y7QUFFQSxNQUFNLDZCQUE2QixNQUFlO0FBQ2hELFFBQU0sWUFBWSxnQkFBeUIsYUFBYSxjQUFjO0FBQ3RFLFNBQU8sY0FBYztBQUN2QjtBQUVBLE1BQU0sZ0JBQWdCLENBQUMsVUFBeUM7QUFDOUQsTUFBSSxDQUFDLFNBQVMsT0FBTyxVQUFVLFNBQVUsUUFBTztBQUVoRCxRQUFNLFlBQVk7QUFDbEIsU0FDRSxPQUFPLFVBQVUsVUFBVSxZQUMzQixPQUFPLFVBQVUsZ0JBQWdCLFlBQ2pDLE9BQU8sU0FBUyxVQUFVLFdBQVcsS0FDckMsVUFBVSxjQUFjLEtBQ3hCLE9BQU8sVUFBVSxxQkFBcUIsWUFDdEMsT0FBTyxTQUFTLFVBQVUsZ0JBQWdCLEtBQzFDLFVBQVUsb0JBQW9CLEtBQzlCLE9BQU8sVUFBVSxpQkFBaUIsWUFDbEMsT0FBTyxTQUFTLFVBQVUsWUFBWSxLQUN0QyxVQUFVLGdCQUFnQixNQUN6QixVQUFVLFdBQVcsWUFBWSxVQUFVLFdBQVc7QUFFM0Q7QUFFQSxNQUFNLHVCQUF1QixDQUFDLFVBQThDO0FBQzFFLE1BQUksQ0FBQyxTQUFTLE9BQU8sVUFBVSxTQUFVLFFBQU87QUFFaEQsUUFBTSxZQUFZO0FBQ2xCLE1BQUksVUFBVSxVQUFVLFVBQVcsUUFBTztBQUMxQyxNQUFJLFVBQVUsZUFBZSxXQUFXLFVBQVUsZUFBZSxRQUFTLFFBQU87QUFDakYsTUFBSSxDQUFDLFVBQVUsZUFBZSxPQUFPLFVBQVUsZ0JBQWdCLFNBQVUsUUFBTztBQUNoRixNQUFJLE9BQU8sVUFBVSxZQUFZLFVBQVUsWUFBWSxPQUFPLFVBQVUsWUFBWSxVQUFVLFNBQVUsUUFBTztBQUMvRyxNQUFJLE9BQU8sVUFBVSxhQUFhLFVBQVcsUUFBTztBQUNwRCxNQUFJLFVBQVUsZ0JBQWdCLFFBQVEsVUFBVSxnQkFBZ0IsV0FBVyxVQUFVLGdCQUFnQixRQUFTLFFBQU87QUFDckgsTUFBSSxPQUFPLFVBQVUsMkJBQTJCLFNBQVUsUUFBTztBQUNqRSxNQUFJLENBQUMsY0FBYyxVQUFVLGNBQWMsRUFBRyxRQUFPO0FBQ3JELE1BQUksVUFBVSxlQUFlLGNBQWMsVUFBVSxlQUFlLFVBQVcsUUFBTztBQUN0RixNQUFJLE9BQU8sVUFBVSxpQkFBaUIsWUFBWSxDQUFDLE9BQU8sU0FBUyxVQUFVLFlBQVksRUFBRyxRQUFPO0FBRW5HLFNBQU87QUFBQSxJQUNMLE9BQU87QUFBQSxJQUNQLFlBQVksVUFBVTtBQUFBLElBQ3RCLGFBQWE7QUFBQSxNQUNYLE9BQU8sV0FBVyxVQUFVLFlBQVksS0FBSztBQUFBLE1BQzdDLE9BQU8sV0FBVyxVQUFVLFlBQVksS0FBSztBQUFBLElBQy9DO0FBQUEsSUFDQSxVQUFVLFVBQVU7QUFBQSxJQUNwQixhQUFhLFVBQVU7QUFBQSxJQUN2Qix3QkFBd0IsV0FBVyxVQUFVLHNCQUFzQjtBQUFBLElBQ25FLGdCQUFnQixVQUFVO0FBQUEsSUFDMUIsWUFBWSxVQUFVO0FBQUEsSUFDdEIsY0FBYyxXQUFXLFVBQVUsWUFBWTtBQUFBLEVBQ2pEO0FBQ0Y7QUFFQSxNQUFNLFlBQVksQ0FBQyxTQUFzQixTQUFTLFVBQVUsVUFBVTtBQUV0RSxNQUFNLGFBQWEsQ0FBQyxVQUFrQixLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sS0FBSyxDQUFDO0FBRW5FLE1BQU0sYUFBYSxDQUFDLFlBQWdDO0FBQ2xELE1BQUksQ0FBQyxRQUFTLFFBQU87QUFDckIsU0FBTyxXQUFXLFFBQVEsZUFBZSxHQUFJO0FBQy9DO0FBRUEsTUFBTSxpQkFBaUIsQ0FBQyxZQUFnQztBQUN0RCxNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLFNBQU8sV0FBVyxRQUFRLG1CQUFtQixHQUFJO0FBQ25EO0FBRU8sYUFBTSxjQUFjLE9BQWlCLENBQUMsS0FBSyxRQUFRO0FBQ3hELFFBQU0sbUJBQW1CLDRCQUE0QjtBQUVyRCxTQUFPO0FBQUEsSUFDTCxPQUFPO0FBQUEsSUFDUCxlQUFlLGlCQUFpQjtBQUFBLElBQ2hDLGdCQUFnQixpQkFBaUI7QUFBQSxJQUNqQyxtQkFBbUIsaUJBQWlCO0FBQUEsSUFDcEMsd0JBQXdCLGlCQUFpQjtBQUFBLElBQ3pDLG9CQUFvQixpQkFBaUI7QUFBQSxJQUNyQyxTQUFTLEVBQUUsTUFBTSxPQUFPLFdBQVcsT0FBTyxPQUFPLE1BQU07QUFBQSxJQUN2RCxnQkFBZ0I7QUFBQSxJQUNoQixnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixhQUFhLEVBQUUsT0FBTyxHQUFHLE9BQU8sRUFBRTtBQUFBLElBQ2xDLHdCQUF3QjtBQUFBLElBQ3hCLFVBQVU7QUFBQSxJQUNWLGFBQWE7QUFBQSxJQUNiLGFBQWEsQ0FBQztBQUFBLElBQ2QsVUFBVSxxQkFBcUI7QUFBQSxJQUMvQixnQkFBZ0IsMkJBQTJCO0FBQUEsSUFDM0Msa0JBQWtCLENBQUMsV0FBVyxJQUFJLEVBQUUsZUFBZSxPQUFPLENBQUM7QUFBQSxJQUMzRCxtQkFBbUIsQ0FBQyxhQUFhLElBQUksRUFBRSxnQkFBZ0IsU0FBUyxDQUFDO0FBQUEsSUFDakUsc0JBQXNCLENBQUMsVUFBVSxJQUFJLEVBQUUsbUJBQW1CLE1BQU0sQ0FBQztBQUFBLElBQ2pFLDJCQUEyQixDQUFDLFVBQVUsSUFBSSxFQUFFLHdCQUF3QixNQUFNLENBQUM7QUFBQSxJQUMzRSx1QkFBdUIsQ0FBQyxVQUFVLElBQUksRUFBRSxvQkFBb0IsTUFBTSxDQUFDO0FBQUEsSUFDbkUsWUFBWSxDQUFDLFNBQVMsSUFBSSxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUUsR0FBRyxNQUFNLFNBQVMsR0FBRyxLQUFLLEVBQUUsRUFBRTtBQUFBLElBQ2pGLG1CQUFtQixDQUFDLFVBQVUsSUFBSSxFQUFFLGdCQUFnQixNQUFNLENBQUM7QUFBQSxJQUMzRCxXQUFXLENBQUMsWUFBWTtBQUN0QixZQUFNLFNBQVMsV0FBVyxRQUFRLGNBQWMsS0FBSyxHQUFJO0FBQ3pELFlBQU0sVUFBVSxXQUFXLE9BQU87QUFDbEMsVUFBSTtBQUFBLFFBQ0YsT0FBTztBQUFBLFFBQ1AsZ0JBQWdCO0FBQUEsUUFDaEIsWUFBWTtBQUFBLFFBQ1osYUFBYSxFQUFFLE9BQU8sUUFBUSxPQUFPLE9BQU87QUFBQSxRQUM1Qyx3QkFBd0I7QUFBQSxRQUN4QixhQUFhLENBQUM7QUFBQSxRQUNkLGFBQWE7QUFBQSxRQUNiLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNIO0FBQUEsSUFDQSxpQkFBaUIsQ0FBQyxjQUFjO0FBQzlCLFVBQUksQ0FBQyxVQUFVO0FBQ2IsWUFBSSxNQUFNLFVBQVUsYUFBYSxNQUFNLFlBQVksTUFBTSxlQUFlLGFBQWEsR0FBRztBQUN0RixpQkFBTztBQUFBLFFBQ1Q7QUFFQSxjQUFNLFVBQVUsV0FBVyxTQUFTO0FBQ3BDLFlBQUksV0FBVyxFQUFHLFFBQU87QUFFekIsY0FBTSxPQUFPLE1BQU07QUFDbkIsWUFBSSxtQkFBbUIsTUFBTTtBQUM3QixZQUFJLHFCQUFxQjtBQUV6QixZQUFJLG1CQUFtQixHQUFHO0FBQ3hCLGdCQUFNLGdCQUFnQixLQUFLLElBQUksa0JBQWtCLGtCQUFrQjtBQUNuRSw4QkFBb0I7QUFDcEIsZ0NBQXNCO0FBQUEsUUFDeEI7QUFFQSxjQUFNLHFCQUFxQixNQUFNLFlBQVksSUFBSTtBQUNqRCxjQUFNLGtCQUFrQixLQUFLLElBQUksR0FBRyxxQkFBcUIsa0JBQWtCO0FBQzNFLGNBQU0saUJBQWlCLG9CQUFvQjtBQUMzQyxjQUFNLGlCQUFpQixxQkFBcUIsTUFBTTtBQUVsRCxZQUFJLENBQUMsa0JBQWtCLENBQUMsZ0JBQWdCO0FBQ3RDLGlCQUFPO0FBQUEsUUFDVDtBQUVBLGNBQU0sWUFBK0I7QUFBQSxVQUNuQyx3QkFBd0I7QUFBQSxVQUN4QixhQUFhLGlCQUFpQixFQUFFLEdBQUcsTUFBTSxhQUFhLENBQUMsSUFBSSxHQUFHLGdCQUFnQixJQUFJLE1BQU07QUFBQSxRQUMxRjtBQUVBLFlBQUksbUJBQW1CLEtBQUssb0JBQW9CLEdBQUc7QUFDakQsb0JBQVUsY0FBYztBQUN4QixvQkFBVSxXQUFXO0FBQUEsUUFDdkI7QUFFQSxlQUFPO0FBQUEsTUFDVCxDQUFDO0FBQUEsSUFDSDtBQUFBLElBQ0EsVUFBVSxNQUFNO0FBQ2QsWUFBTSxRQUFRLElBQUk7QUFDbEIsVUFBSSxNQUFNLFVBQVUsYUFBYSxNQUFNLFlBQVksTUFBTSxZQUFhLFFBQU87QUFFN0UsWUFBTSxXQUFXLE1BQU07QUFDdkIsWUFBTSxTQUFTLFVBQVUsUUFBUTtBQUNqQyxZQUFNLFdBQXlCO0FBQUEsUUFDN0IsWUFBWSxNQUFNO0FBQUEsUUFDbEIsYUFBYTtBQUFBLFVBQ1gsT0FBTyxNQUFNLFlBQVk7QUFBQSxVQUN6QixPQUFPLE1BQU0sWUFBWTtBQUFBLFFBQzNCO0FBQUEsUUFDQSx3QkFBd0IsTUFBTTtBQUFBLFFBQzlCLFVBQVUsTUFBTTtBQUFBLFFBQ2hCLGFBQWEsTUFBTTtBQUFBLE1BQ3JCO0FBRUEsWUFBTSxjQUFjLGVBQWUsTUFBTSxjQUFjO0FBQ3ZELFlBQU0sa0JBQWtCO0FBQUEsUUFDdEIsR0FBRyxNQUFNO0FBQUEsUUFDVCxDQUFDLFFBQVEsR0FBRyxNQUFNLFlBQVksUUFBUSxJQUFJO0FBQUEsTUFDNUM7QUFFQSxVQUFJO0FBQUEsUUFDRixhQUFhLENBQUMsR0FBRyxNQUFNLGFBQWEsUUFBUTtBQUFBLFFBQzVDLFlBQVk7QUFBQSxRQUNaLGFBQWE7QUFBQSxRQUNiLHdCQUF3QixXQUFXLE1BQU0sY0FBYztBQUFBLE1BQ3pELENBQUM7QUFFRCxhQUFPLEVBQUUsVUFBVSxPQUFPO0FBQUEsSUFDNUI7QUFBQSxJQUNBLFdBQVcsTUFBTSxJQUFJLEVBQUUsVUFBVSxLQUFLLENBQUM7QUFBQSxJQUN2QyxZQUFZLE1BQU07QUFDaEIsWUFBTSxRQUFRLElBQUk7QUFDbEIsVUFBSSxNQUFNLFlBQWE7QUFDdkIsVUFBSSxFQUFFLFVBQVUsTUFBTSxDQUFDO0FBQUEsSUFDekI7QUFBQSxJQUNBLGFBQWEsTUFBTTtBQUNqQixZQUFNLFFBQVEsSUFBSTtBQUNsQixVQUFJLE1BQU0sWUFBYTtBQUN2QixVQUFJLEVBQUUsVUFBVSxDQUFDLE1BQU0sU0FBUyxDQUFDO0FBQUEsSUFDbkM7QUFBQSxJQUNBLFVBQVUsTUFBTTtBQUNkLFlBQU0sUUFBUSxJQUFJO0FBQ2xCLFVBQUksTUFBTSxZQUFZLFdBQVcsRUFBRyxRQUFPO0FBRTNDLFlBQU0sV0FBVyxNQUFNLFlBQVksTUFBTSxZQUFZLFNBQVMsQ0FBQztBQUMvRCxVQUFJLENBQUMsU0FBVSxRQUFPO0FBRXRCLFVBQUk7QUFBQSxRQUNGLGFBQWEsTUFBTSxZQUFZLE1BQU0sR0FBRyxFQUFFO0FBQUEsUUFDMUMsWUFBWSxTQUFTO0FBQUEsUUFDckIsYUFBYSxTQUFTO0FBQUEsUUFDdEIsd0JBQXdCLFNBQVM7QUFBQSxRQUNqQyxVQUFVLFNBQVM7QUFBQSxRQUNuQixhQUFhLFNBQVM7QUFBQSxNQUN4QixDQUFDO0FBRUQsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLFdBQVcsTUFBTTtBQUNmLFlBQU0sUUFBUSxJQUFJO0FBQ2xCLFVBQUksQ0FBQyxNQUFNLGVBQWdCO0FBRTNCLFlBQU0sU0FBUyxXQUFXLE1BQU0sZUFBZSxjQUFjLEtBQUssR0FBSTtBQUN0RSxVQUFJO0FBQUEsUUFDRixhQUFhLEVBQUUsT0FBTyxRQUFRLE9BQU8sT0FBTztBQUFBLFFBQzVDLFlBQVk7QUFBQSxRQUNaLHdCQUF3QixXQUFXLE1BQU0sY0FBYztBQUFBLFFBQ3ZELGFBQWEsQ0FBQztBQUFBLFFBQ2QsYUFBYTtBQUFBLFFBQ2IsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFBQSxJQUNBLGFBQWEsTUFBTSxJQUFJLEVBQUUsT0FBTyxTQUFTLGdCQUFnQixPQUFPLFVBQVUsTUFBTSxDQUFDO0FBQUEsSUFDakYsZUFBZSxDQUFDLEtBQUssVUFBVSxJQUFJLENBQUMsV0FBVyxFQUFFLFVBQVUsRUFBRSxHQUFHLE1BQU0sVUFBVSxDQUFDLEdBQUcsR0FBRyxNQUFNLEVBQUUsRUFBRTtBQUFBLElBQ2pHLG1CQUFtQixDQUFDLFVBQVUsSUFBSSxFQUFFLGdCQUFnQixNQUFNLENBQUM7QUFBQSxJQUMzRCxrQkFBa0IsTUFBTTtBQUN0QixVQUFJLE9BQU8sV0FBVyxZQUFhO0FBRW5DLFVBQUk7QUFDRixjQUFNLFFBQVEsSUFBSTtBQUNsQixZQUFJLE1BQU0sVUFBVSxhQUFhLENBQUMsTUFBTSxnQkFBZ0I7QUFDdEQsaUJBQU8sYUFBYSxXQUFXLGFBQWEsU0FBUztBQUNyRDtBQUFBLFFBQ0Y7QUFFQSxjQUFNLFVBQThCO0FBQUEsVUFDbEMsT0FBTztBQUFBLFVBQ1AsWUFBWSxNQUFNO0FBQUEsVUFDbEIsYUFBYTtBQUFBLFlBQ1gsT0FBTyxXQUFXLE1BQU0sWUFBWSxLQUFLO0FBQUEsWUFDekMsT0FBTyxXQUFXLE1BQU0sWUFBWSxLQUFLO0FBQUEsVUFDM0M7QUFBQSxVQUNBLFVBQVUsTUFBTTtBQUFBLFVBQ2hCLGFBQWEsTUFBTTtBQUFBLFVBQ25CLHdCQUF3QixXQUFXLE1BQU0sc0JBQXNCO0FBQUEsVUFDL0QsZ0JBQWdCLE1BQU07QUFBQSxVQUN0QixZQUFZLE1BQU0sU0FBUztBQUFBLFVBQzNCLGNBQWMsS0FBSyxJQUFJO0FBQUEsUUFDekI7QUFFQSxlQUFPLGFBQWEsUUFBUSxhQUFhLFdBQVcsS0FBSyxVQUFVLE9BQU8sQ0FBQztBQUFBLE1BQzdFLFFBQVE7QUFBQSxNQUVSO0FBQUEsSUFDRjtBQUFBLElBQ0EsMkJBQTJCLE1BQU07QUFDL0IsVUFBSSxPQUFPLFdBQVcsWUFBYSxRQUFPO0FBRTFDLFlBQU0sZUFBZSxnQkFBeUIsYUFBYSxTQUFTO0FBQ3BFLFVBQUksQ0FBQyxhQUFjLFFBQU87QUFFMUIsWUFBTSxZQUFZLHFCQUFxQixZQUFZO0FBQ25ELFVBQUksQ0FBQyxXQUFXO0FBQ2QsZUFBTyxhQUFhLFdBQVcsYUFBYSxTQUFTO0FBQ3JELGVBQU87QUFBQSxNQUNUO0FBRUEsVUFBSSxLQUFLLElBQUksSUFBSSxVQUFVLGVBQWUsdUJBQXVCO0FBQy9ELGVBQU8sYUFBYSxXQUFXLGFBQWEsU0FBUztBQUNyRCxlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksQ0FBQyxXQUFXO0FBQUEsUUFDZCxPQUFPO0FBQUEsUUFDUCxnQkFBZ0I7QUFBQSxRQUNoQixnQkFBZ0IsVUFBVTtBQUFBLFFBQzFCLFlBQVksVUFBVTtBQUFBLFFBQ3RCLGFBQWEsVUFBVTtBQUFBLFFBQ3ZCLHdCQUF3QixVQUFVO0FBQUEsUUFDbEMsVUFBVSxVQUFVO0FBQUEsUUFDcEIsYUFBYSxVQUFVO0FBQUEsUUFDdkIsYUFBYSxDQUFDO0FBQUEsUUFDZCxVQUFVO0FBQUEsVUFDUixHQUFHLE1BQU07QUFBQSxVQUNULFlBQVksVUFBVTtBQUFBLFFBQ3hCO0FBQUEsTUFDRixFQUFFO0FBRUYsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0YsQ0FBQzsiLCJuYW1lcyI6W119