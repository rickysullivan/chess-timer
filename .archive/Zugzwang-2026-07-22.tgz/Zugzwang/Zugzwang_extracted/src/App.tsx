import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5db2b99c"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Download, Settings2, Share2 } from "/node_modules/.vite/deps/lucide-react.js?v=5db2b99c";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=5db2b99c"; const useCallback = __vite__cjsImport2_react["useCallback"]; const useMemo = __vite__cjsImport2_react["useMemo"]; const useState = __vite__cjsImport2_react["useState"];
import { useActionMessage } from "/src/app/hooks/useActionMessage.ts";
import { useGameTicker } from "/src/app/hooks/useGameTicker.ts";
import { useAppStore } from "/src/app/store.ts";
import { useInstallShare } from "/src/app/hooks/useInstallShare.ts";
import { useLiveAnnouncements } from "/src/app/hooks/useLiveAnnouncements.ts";
import { usePersistenceLifecycle } from "/src/app/hooks/usePersistenceLifecycle.ts";
import { useTelemetryAppLifecycle } from "/src/app/hooks/useTelemetryAppLifecycle.ts";
import { useWakeLock } from "/src/app/hooks/useWakeLock.ts";
import {
  PRESETS,
  parseNumber
} from "/src/app/types.ts";
import { GameScreen } from "/src/features/gameplay/components/GameScreen.tsx";
import { SettingsDrawer } from "/src/features/settings/components/SettingsDrawer.tsx";
import { SetupScreen } from "/src/features/setup/components/SetupScreen.tsx";
import { captureError, captureEvent } from "/src/lib/telemetry.ts";
const getControlEventProperties = (control) => {
  if (!control) return {};
  return {
    base_minutes: control.baseMinutes,
    increment_seconds: control.incrementSeconds,
    delay_seconds: control.delaySeconds
  };
};
function App() {
  _s();
  const phase = useAppStore((state) => state.phase);
  const controlSource = useAppStore((state) => state.controlSource);
  const selectedPreset = useAppStore((state) => state.selectedPreset);
  const customBaseMinutes = useAppStore((state) => state.customBaseMinutes);
  const customIncrementSeconds = useAppStore((state) => state.customIncrementSeconds);
  const customDelaySeconds = useAppStore((state) => state.customDelaySeconds);
  const touched = useAppStore((state) => state.touched);
  const attemptedStart = useAppStore((state) => state.attemptedStart);
  const startedControl = useAppStore((state) => state.startedControl);
  const activeSide = useAppStore((state) => state.activeSide);
  const remainingMs = useAppStore((state) => state.remainingMs);
  const activeDelayRemainingMs = useAppStore((state) => state.activeDelayRemainingMs);
  const isPaused = useAppStore((state) => state.isPaused);
  const timeoutSide = useAppStore((state) => state.timeoutSide);
  const undoHistory = useAppStore((state) => state.undoHistory);
  const settings = useAppStore((state) => state.settings);
  const onboardingSeen = useAppStore((state) => state.onboardingSeen);
  const setControlSource = useAppStore((state) => state.setControlSource);
  const setSelectedPreset = useAppStore((state) => state.setSelectedPreset);
  const setCustomBaseMinutes = useAppStore((state) => state.setCustomBaseMinutes);
  const setCustomIncrementSeconds = useAppStore((state) => state.setCustomIncrementSeconds);
  const setCustomDelaySeconds = useAppStore((state) => state.setCustomDelaySeconds);
  const setTouched = useAppStore((state) => state.setTouched);
  const setAttemptedStart = useAppStore((state) => state.setAttemptedStart);
  const startGame = useAppStore((state) => state.startGame);
  const tickActiveClock = useAppStore((state) => state.tickActiveClock);
  const passTurn = useAppStore((state) => state.passTurn);
  const pauseGame = useAppStore((state) => state.pauseGame);
  const togglePause = useAppStore((state) => state.togglePause);
  const undoTurn = useAppStore((state) => state.undoTurn);
  const resetGame = useAppStore((state) => state.resetGame);
  const backToSetup = useAppStore((state) => state.backToSetup);
  const updateSetting = useAppStore((state) => state.updateSetting);
  const setOnboardingSeen = useAppStore((state) => state.setOnboardingSeen);
  const persistGameState = useAppStore((state) => state.persistGameState);
  const restorePersistedGameState = useAppStore((state) => state.restorePersistedGameState);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [restoreOutcome, setRestoreOutcome] = useState(null);
  const { actionMessage, showActionMessage } = useActionMessage();
  const selectedPresetControl = useMemo(() => PRESETS.find((preset) => preset.id === selectedPreset), [selectedPreset]);
  const customBaseError = useMemo(() => {
    const value = customBaseMinutes.trim();
    if (!value) return "Base minutes is required.";
    const parsed = parseNumber(value);
    if (Number.isNaN(parsed) || parsed <= 0) return "Base minutes must be greater than 0.";
    return null;
  }, [customBaseMinutes]);
  const customIncrementError = useMemo(() => {
    const value = customIncrementSeconds.trim();
    if (!value) return "Increment seconds is required.";
    const parsed = parseNumber(value);
    if (Number.isNaN(parsed) || parsed < 0) return "Increment seconds must be 0 or greater.";
    return null;
  }, [customIncrementSeconds]);
  const customDelayError = useMemo(() => {
    const value = customDelaySeconds.trim();
    if (!value) return "Delay seconds is required.";
    const parsed = parseNumber(value);
    if (Number.isNaN(parsed) || parsed < 0) return "Delay seconds must be 0 or greater.";
    return null;
  }, [customDelaySeconds]);
  const customControl = useMemo(() => {
    if (customBaseError || customIncrementError || customDelayError) return null;
    return {
      label: `${customBaseMinutes}+${customIncrementSeconds}`,
      baseMinutes: parseNumber(customBaseMinutes),
      incrementSeconds: parseNumber(customIncrementSeconds),
      delaySeconds: parseNumber(customDelaySeconds),
      source: "custom"
    };
  }, [customBaseError, customBaseMinutes, customDelayError, customDelaySeconds, customIncrementError, customIncrementSeconds]);
  const selectedControl = useMemo(() => {
    if (controlSource === "preset") {
      if (!selectedPresetControl) return null;
      return {
        label: selectedPresetControl.label,
        baseMinutes: selectedPresetControl.baseMinutes,
        incrementSeconds: selectedPresetControl.incrementSeconds,
        delaySeconds: selectedPresetControl.delaySeconds,
        source: "preset"
      };
    }
    return customControl;
  }, [controlSource, customControl, selectedPresetControl]);
  const startError = useMemo(() => {
    if (controlSource === "preset" && !selectedPresetControl) {
      return "Pick a preset to start.";
    }
    if (controlSource === "custom" && !customControl) {
      return "Enter valid custom values before starting.";
    }
    return null;
  }, [controlSource, customControl, selectedPresetControl]);
  const canStart = selectedControl !== null;
  const canUndo = undoHistory.length > 0;
  const controlSelection = useMemo(
    () => ({
      source: controlSource,
      presetId: selectedPreset,
      customBaseMinutes,
      customIncrementSeconds,
      customDelaySeconds
    }),
    [controlSource, customBaseMinutes, customDelaySeconds, customIncrementSeconds, selectedPreset]
  );
  const gameStateSnapshot = useMemo(
    () => ({
      phase,
      activeSide,
      remainingMs,
      activeDelayRemainingMs,
      isPaused,
      timeoutSide,
      startedControl,
      layoutMode: settings.layoutMode
    }),
    [activeDelayRemainingMs, activeSide, isPaused, phase, remainingMs, settings.layoutMode, startedControl, timeoutSide]
  );
  const degradedModeWarning = useMemo(() => {
    if (typeof navigator === "undefined") return null;
    const missingFeatures = [];
    if (!("serviceWorker" in navigator)) {
      missingFeatures.push("offline support");
    }
    if (!("wakeLock" in navigator)) {
      missingFeatures.push("keep-screen-awake");
    }
    if (missingFeatures.length === 0) return null;
    const featuresLabel = missingFeatures.length === 1 ? missingFeatures[0] : `${missingFeatures.slice(0, -1).join(", ")} and ${missingFeatures[missingFeatures.length - 1]}`;
    return `Heads up: your browser does not support ${featuresLabel}. The timer still works in degraded mode.`;
  }, []);
  usePersistenceLifecycle({
    settings,
    onboardingSeen,
    controlSelection,
    gameStateSnapshot,
    persistGameState,
    restorePersistedGameState,
    onRestoreOutcome: setRestoreOutcome
  });
  useTelemetryAppLifecycle({
    layoutMode: settings.layoutMode,
    restoreOutcome
  });
  useWakeLock({
    enabled: settings.keepScreenAwake,
    onError: captureError
  });
  useGameTicker({
    phase,
    isPaused,
    timeoutSide,
    tickActiveClock
  });
  const handleAppInstalled = useCallback(() => {
    showActionMessage("success", "App installed. You can launch it from your home screen.");
  }, [showActionMessage]);
  const { canInstall, installApp, shareCurrentUrl } = useInstallShare({
    onError: captureError,
    onAppInstalled: handleAppInstalled
  });
  const liveAnnouncement = useLiveAnnouncements({
    phase,
    isPaused,
    timeoutSide,
    restoreOutcome
  });
  const playInteractionFeedback = useCallback(
    (kind) => {
      if (settings.vibration && typeof navigator !== "undefined" && "vibrate" in navigator) {
        try {
          navigator.vibrate(kind === "turn_switch" ? 20 : 12);
        } catch (error) {
          captureError(error, { source: "haptics", kind });
        }
      }
      if (!settings.sound || typeof window === "undefined") return;
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        const context = new AudioCtx();
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        oscillator.type = "sine";
        oscillator.frequency.value = kind === "turn_switch" ? 900 : 640;
        gain.gain.value = 0.04;
        oscillator.connect(gain);
        gain.connect(context.destination);
        oscillator.start();
        oscillator.stop(context.currentTime + 0.05);
        oscillator.onended = () => {
          context.close().catch(() => void 0);
        };
      } catch (error) {
        captureError(error, { source: "sound_feedback", kind });
      }
    },
    [settings.sound, settings.vibration]
  );
  const getElapsedSeconds = useCallback(
    (control) => {
      if (!control) return void 0;
      const baseMs = Math.max(0, Math.round(control.baseMinutes * 60 * 1e3));
      const elapsedMs = Math.max(0, baseMs - remainingMs.White) + Math.max(0, baseMs - remainingMs.Black);
      return Math.round(elapsedMs / 1e3);
    },
    [remainingMs.Black, remainingMs.White]
  );
  const buildCoreEventProperties = useCallback(
    (options) => {
      const control = options?.control ?? startedControl;
      const properties = {
        layout_mode: settings.layoutMode,
        ...getControlEventProperties(control ?? null),
        ...options?.extra ?? {}
      };
      if (options?.includeElapsedSeconds) {
        const elapsedSeconds = getElapsedSeconds(control ?? null);
        if (typeof elapsedSeconds === "number") {
          properties.elapsed_seconds = elapsedSeconds;
        }
      }
      return properties;
    },
    [getElapsedSeconds, settings.layoutMode, startedControl]
  );
  const handleInstall = async () => {
    const result = await installApp();
    const accepted = result === "accepted";
    captureEvent(
      "pwa_install",
      buildCoreEventProperties({
        extra: { accepted }
      })
    );
    if (result === "accepted") {
      showActionMessage("success", "Install accepted.");
    } else if (result === "dismissed") {
      showActionMessage("info", "Install dismissed.");
    } else {
      showActionMessage("error", "Install prompt was unavailable. Try again later.");
    }
  };
  const handleShare = async () => {
    const result = await shareCurrentUrl();
    captureEvent(
      "share_action",
      buildCoreEventProperties({
        extra: {
          method: result.method,
          outcome: result.outcome === "canceled" ? "failure" : result.outcome
        }
      })
    );
    if (result.outcome === "success") {
      showActionMessage("success", result.method === "web_share" ? "Shared successfully." : "Link copied to clipboard.");
      return;
    }
    if (result.outcome === "canceled") {
      showActionMessage("info", "Share canceled.");
      return;
    }
    showActionMessage("error", "Unable to share this link on this browser.");
  };
  const handleStart = () => {
    setAttemptedStart(true);
    if (!selectedControl) return;
    const controlProperties = buildCoreEventProperties({
      control: selectedControl,
      extra: selectedControl.source === "preset" ? { preset_id: selectedPreset } : void 0
    });
    captureEvent("game_start", controlProperties);
    if (selectedControl.source === "custom") {
      captureEvent("custom_control_saved", controlProperties);
    }
    startGame(selectedControl);
  };
  const handleSideTap = (side) => {
    if (timeoutSide || isPaused) return;
    if (side === activeSide) {
      const turnSwitch = passTurn();
      if (!turnSwitch) return;
      captureEvent(
        "turn_switch",
        buildCoreEventProperties({
          includeElapsedSeconds: true,
          extra: {
            from_side: turnSwitch.fromSide,
            to_side: turnSwitch.toSide
          }
        })
      );
      playInteractionFeedback("turn_switch");
      return;
    }
    captureEvent("pause", buildCoreEventProperties({ includeElapsedSeconds: true }));
    pauseGame();
    playInteractionFeedback("pause");
  };
  const handlePauseResume = () => {
    if (timeoutSide) return;
    const nextPaused = !isPaused;
    captureEvent(nextPaused ? "pause" : "resume", buildCoreEventProperties({ includeElapsedSeconds: true }));
    togglePause();
    playInteractionFeedback(nextPaused ? "pause" : "resume");
  };
  const handleUndo = () => {
    if (!undoTurn()) return;
    captureEvent("undo", buildCoreEventProperties({ includeElapsedSeconds: true }));
  };
  const handleReset = () => {
    if (!startedControl) return;
    captureEvent("reset", buildCoreEventProperties({ includeElapsedSeconds: true }));
    resetGame();
  };
  const handlePresetSelect = (presetId) => {
    setControlSource("preset");
    setSelectedPreset(presetId);
    const selected = PRESETS.find((preset) => preset.id === presetId);
    if (!selected) return;
    captureEvent(
      "preset_selected",
      buildCoreEventProperties({
        control: {
          label: selected.label,
          baseMinutes: selected.baseMinutes,
          incrementSeconds: selected.incrementSeconds,
          delaySeconds: selected.delaySeconds,
          source: "preset"
        },
        extra: {
          preset_id: selected.id
        }
      })
    );
  };
  const dismissOnboardingCue = useCallback(() => {
    setOnboardingSeen(true);
  }, [setOnboardingSeen]);
  const warningBanner = degradedModeWarning ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900", role: "status", children: degradedModeWarning }, void 0, false, {
    fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
    lineNumber: 446,
    columnNumber: 3
  }, this) : null;
  const headerActions = /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 sm:gap-2", children: [
    canInstall ? /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => void handleInstall(),
        "aria-label": "Install app",
        className: "inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 py-1.5 text-sm font-medium text-slate-700 shadow-sm transition hover:bg-slate-50",
        children: [
          /* @__PURE__ */ jsxDEV(Download, { className: "size-4" }, void 0, false, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
            lineNumber: 460,
            columnNumber: 11
          }, this),
          "Install"
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
        lineNumber: 454,
        columnNumber: 5
      },
      this
    ) : null,
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => void handleShare(),
        "aria-label": "Share app link",
        className: "inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 py-1.5 text-sm font-medium text-slate-700 shadow-sm transition hover:bg-slate-50",
        children: [
          /* @__PURE__ */ jsxDEV(Share2, { className: "size-4" }, void 0, false, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
            lineNumber: 470,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: "Share" }, void 0, false, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
            lineNumber: 471,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
        lineNumber: 464,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => setIsSettingsOpen(true),
        "aria-label": "Open settings",
        "aria-haspopup": "dialog",
        "aria-expanded": isSettingsOpen,
        className: "inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 py-1.5 text-sm font-medium text-slate-700 shadow-sm transition hover:bg-slate-50",
        children: [
          /* @__PURE__ */ jsxDEV(Settings2, { className: "size-4" }, void 0, false, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
            lineNumber: 481,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: "Settings" }, void 0, false, {
            fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
            lineNumber: 482,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
        lineNumber: 473,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
    lineNumber: 452,
    columnNumber: 3
  }, this);
  const settingsDrawer = /* @__PURE__ */ jsxDEV(
    SettingsDrawer,
    {
      isOpen: isSettingsOpen,
      settings,
      onClose: () => setIsSettingsOpen(false),
      onUpdateSetting: updateSetting
    },
    void 0,
    false,
    {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
      lineNumber: 488,
      columnNumber: 3
    },
    this
  );
  const showCustomBaseError = controlSource === "custom" && (attemptedStart || touched.base) && customBaseError;
  const showCustomIncrementError = controlSource === "custom" && (attemptedStart || touched.increment) && customIncrementError;
  const showCustomDelayError = controlSource === "custom" && (attemptedStart || touched.delay) && customDelayError;
  if (phase === "started" && startedControl) {
    return /* @__PURE__ */ jsxDEV(
      GameScreen,
      {
        headerActions,
        warningBanner,
        settingsDrawer,
        actionMessage,
        liveAnnouncement,
        settings,
        startedControl,
        activeSide,
        remainingMs,
        activeDelayRemainingMs,
        timeoutSide,
        isPaused,
        canUndo,
        onboardingSeen,
        onDismissOnboarding: dismissOnboardingCue,
        onSideTap: handleSideTap,
        onPauseResume: handlePauseResume,
        onUndo: handleUndo,
        onReset: handleReset,
        onBackToSetup: backToSetup
      },
      void 0,
      false,
      {
        fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
        lineNumber: 503,
        columnNumber: 7
      },
      this
    );
  }
  return /* @__PURE__ */ jsxDEV(
    SetupScreen,
    {
      headerActions,
      warningBanner,
      settingsDrawer,
      actionMessage,
      liveAnnouncement,
      controlSource,
      selectedPreset,
      customBaseMinutes,
      customIncrementSeconds,
      customDelaySeconds,
      showCustomBaseError,
      showCustomIncrementError,
      showCustomDelayError,
      selectedControl,
      startError,
      attemptedStart,
      canStart,
      onControlSourceChange: (source) => setControlSource(source),
      onPresetSelect: handlePresetSelect,
      onCustomBaseMinutesChange: setCustomBaseMinutes,
      onCustomIncrementSecondsChange: setCustomIncrementSeconds,
      onCustomDelaySecondsChange: setCustomDelaySeconds,
      onCustomBaseBlur: () => setTouched({ base: true }),
      onCustomIncrementBlur: () => setTouched({ increment: true }),
      onCustomDelayBlur: () => setTouched({ delay: true }),
      onStart: handleStart
    },
    void 0,
    false,
    {
      fileName: "/Users/rickysullivan/Projects/chess-timer/src/App.tsx",
      lineNumber: 529,
      columnNumber: 5
    },
    this
  );
}
_s(App, "8058RRH7CGJBZUNzgX+XwyM0ICw=", false, function() {
  return [useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useAppStore, useActionMessage, usePersistenceLifecycle, useTelemetryAppLifecycle, useWakeLock, useGameTicker, useInstallShare, useLiveAnnouncements];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rickysullivan/Projects/chess-timer/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rickysullivan/Projects/chess-timer/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/rickysullivan/Projects/chess-timer/src/App.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNmJJOztBQTdiSixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLFNBQVNDLGFBQWFDLFNBQVNDLGdCQUFnQjtBQUMvQyxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsNEJBQTRCO0FBQ3JDLFNBQVNDLCtCQUErQjtBQUN4QyxTQUFTQyxnQ0FBZ0M7QUFDekMsU0FBU0MsbUJBQW1CO0FBQzVCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FHSztBQUNQLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGNBQWNDLG9CQUFvQjtBQUUzQyxNQUFNQyw0QkFBNEJBLENBQUNDLFlBQWdDO0FBQ2pFLE1BQUksQ0FBQ0EsUUFBUyxRQUFPLENBQUM7QUFFdEIsU0FBTztBQUFBLElBQ0xDLGNBQWNELFFBQVFFO0FBQUFBLElBQ3RCQyxtQkFBbUJILFFBQVFJO0FBQUFBLElBQzNCQyxlQUFlTCxRQUFRTTtBQUFBQSxFQUN6QjtBQUNGO0FBRUEsU0FBU0MsTUFBTTtBQUFBQyxLQUFBO0FBQ2IsUUFBTUMsUUFBUXZCLFlBQVksQ0FBQ3dCLFVBQVVBLE1BQU1ELEtBQUs7QUFDaEQsUUFBTUUsZ0JBQWdCekIsWUFBWSxDQUFDd0IsVUFBVUEsTUFBTUMsYUFBYTtBQUNoRSxRQUFNQyxpQkFBaUIxQixZQUFZLENBQUN3QixVQUFVQSxNQUFNRSxjQUFjO0FBQ2xFLFFBQU1DLG9CQUFvQjNCLFlBQVksQ0FBQ3dCLFVBQVVBLE1BQU1HLGlCQUFpQjtBQUN4RSxRQUFNQyx5QkFBeUI1QixZQUFZLENBQUN3QixVQUFVQSxNQUFNSSxzQkFBc0I7QUFDbEYsUUFBTUMscUJBQXFCN0IsWUFBWSxDQUFDd0IsVUFBVUEsTUFBTUssa0JBQWtCO0FBQzFFLFFBQU1DLFVBQVU5QixZQUFZLENBQUN3QixVQUFVQSxNQUFNTSxPQUFPO0FBQ3BELFFBQU1DLGlCQUFpQi9CLFlBQVksQ0FBQ3dCLFVBQVVBLE1BQU1PLGNBQWM7QUFDbEUsUUFBTUMsaUJBQWlCaEMsWUFBWSxDQUFDd0IsVUFBVUEsTUFBTVEsY0FBYztBQUNsRSxRQUFNQyxhQUFhakMsWUFBWSxDQUFDd0IsVUFBVUEsTUFBTVMsVUFBVTtBQUMxRCxRQUFNQyxjQUFjbEMsWUFBWSxDQUFDd0IsVUFBVUEsTUFBTVUsV0FBVztBQUM1RCxRQUFNQyx5QkFBeUJuQyxZQUFZLENBQUN3QixVQUFVQSxNQUFNVyxzQkFBc0I7QUFDbEYsUUFBTUMsV0FBV3BDLFlBQVksQ0FBQ3dCLFVBQVVBLE1BQU1ZLFFBQVE7QUFDdEQsUUFBTUMsY0FBY3JDLFlBQVksQ0FBQ3dCLFVBQVVBLE1BQU1hLFdBQVc7QUFDNUQsUUFBTUMsY0FBY3RDLFlBQVksQ0FBQ3dCLFVBQVVBLE1BQU1jLFdBQVc7QUFDNUQsUUFBTUMsV0FBV3ZDLFlBQVksQ0FBQ3dCLFVBQVVBLE1BQU1lLFFBQVE7QUFDdEQsUUFBTUMsaUJBQWlCeEMsWUFBWSxDQUFDd0IsVUFBVUEsTUFBTWdCLGNBQWM7QUFFbEUsUUFBTUMsbUJBQW1CekMsWUFBWSxDQUFDd0IsVUFBVUEsTUFBTWlCLGdCQUFnQjtBQUN0RSxRQUFNQyxvQkFBb0IxQyxZQUFZLENBQUN3QixVQUFVQSxNQUFNa0IsaUJBQWlCO0FBQ3hFLFFBQU1DLHVCQUF1QjNDLFlBQVksQ0FBQ3dCLFVBQVVBLE1BQU1tQixvQkFBb0I7QUFDOUUsUUFBTUMsNEJBQTRCNUMsWUFBWSxDQUFDd0IsVUFBVUEsTUFBTW9CLHlCQUF5QjtBQUN4RixRQUFNQyx3QkFBd0I3QyxZQUFZLENBQUN3QixVQUFVQSxNQUFNcUIscUJBQXFCO0FBQ2hGLFFBQU1DLGFBQWE5QyxZQUFZLENBQUN3QixVQUFVQSxNQUFNc0IsVUFBVTtBQUMxRCxRQUFNQyxvQkFBb0IvQyxZQUFZLENBQUN3QixVQUFVQSxNQUFNdUIsaUJBQWlCO0FBQ3hFLFFBQU1DLFlBQVloRCxZQUFZLENBQUN3QixVQUFVQSxNQUFNd0IsU0FBUztBQUN4RCxRQUFNQyxrQkFBa0JqRCxZQUFZLENBQUN3QixVQUFVQSxNQUFNeUIsZUFBZTtBQUNwRSxRQUFNQyxXQUFXbEQsWUFBWSxDQUFDd0IsVUFBVUEsTUFBTTBCLFFBQVE7QUFDdEQsUUFBTUMsWUFBWW5ELFlBQVksQ0FBQ3dCLFVBQVVBLE1BQU0yQixTQUFTO0FBQ3hELFFBQU1DLGNBQWNwRCxZQUFZLENBQUN3QixVQUFVQSxNQUFNNEIsV0FBVztBQUM1RCxRQUFNQyxXQUFXckQsWUFBWSxDQUFDd0IsVUFBVUEsTUFBTTZCLFFBQVE7QUFDdEQsUUFBTUMsWUFBWXRELFlBQVksQ0FBQ3dCLFVBQVVBLE1BQU04QixTQUFTO0FBQ3hELFFBQU1DLGNBQWN2RCxZQUFZLENBQUN3QixVQUFVQSxNQUFNK0IsV0FBVztBQUM1RCxRQUFNQyxnQkFBZ0J4RCxZQUFZLENBQUN3QixVQUFVQSxNQUFNZ0MsYUFBYTtBQUNoRSxRQUFNQyxvQkFBb0J6RCxZQUFZLENBQUN3QixVQUFVQSxNQUFNaUMsaUJBQWlCO0FBQ3hFLFFBQU1DLG1CQUFtQjFELFlBQVksQ0FBQ3dCLFVBQVVBLE1BQU1rQyxnQkFBZ0I7QUFDdEUsUUFBTUMsNEJBQTRCM0QsWUFBWSxDQUFDd0IsVUFBVUEsTUFBTW1DLHlCQUF5QjtBQUV4RixRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUloRSxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDaUUsZ0JBQWdCQyxpQkFBaUIsSUFBSWxFLFNBQWdFLElBQUk7QUFDaEgsUUFBTSxFQUFFbUUsZUFBZUMsa0JBQWtCLElBQUluRSxpQkFBaUI7QUFFOUQsUUFBTW9FLHdCQUF3QnRFLFFBQVEsTUFBTVUsUUFBUTZELEtBQUssQ0FBQ0MsV0FBV0EsT0FBT0MsT0FBTzNDLGNBQWMsR0FBRyxDQUFDQSxjQUFjLENBQUM7QUFFcEgsUUFBTTRDLGtCQUFrQjFFLFFBQVEsTUFBTTtBQUNwQyxVQUFNMkUsUUFBUTVDLGtCQUFrQjZDLEtBQUs7QUFDckMsUUFBSSxDQUFDRCxNQUFPLFFBQU87QUFDbkIsVUFBTUUsU0FBU2xFLFlBQVlnRSxLQUFLO0FBQ2hDLFFBQUlHLE9BQU9DLE1BQU1GLE1BQU0sS0FBS0EsVUFBVSxFQUFHLFFBQU87QUFDaEQsV0FBTztBQUFBLEVBQ1QsR0FBRyxDQUFDOUMsaUJBQWlCLENBQUM7QUFFdEIsUUFBTWlELHVCQUF1QmhGLFFBQVEsTUFBTTtBQUN6QyxVQUFNMkUsUUFBUTNDLHVCQUF1QjRDLEtBQUs7QUFDMUMsUUFBSSxDQUFDRCxNQUFPLFFBQU87QUFDbkIsVUFBTUUsU0FBU2xFLFlBQVlnRSxLQUFLO0FBQ2hDLFFBQUlHLE9BQU9DLE1BQU1GLE1BQU0sS0FBS0EsU0FBUyxFQUFHLFFBQU87QUFDL0MsV0FBTztBQUFBLEVBQ1QsR0FBRyxDQUFDN0Msc0JBQXNCLENBQUM7QUFFM0IsUUFBTWlELG1CQUFtQmpGLFFBQVEsTUFBTTtBQUNyQyxVQUFNMkUsUUFBUTFDLG1CQUFtQjJDLEtBQUs7QUFDdEMsUUFBSSxDQUFDRCxNQUFPLFFBQU87QUFDbkIsVUFBTUUsU0FBU2xFLFlBQVlnRSxLQUFLO0FBQ2hDLFFBQUlHLE9BQU9DLE1BQU1GLE1BQU0sS0FBS0EsU0FBUyxFQUFHLFFBQU87QUFDL0MsV0FBTztBQUFBLEVBQ1QsR0FBRyxDQUFDNUMsa0JBQWtCLENBQUM7QUFFdkIsUUFBTWlELGdCQUFnQmxGLFFBQTRCLE1BQU07QUFDdEQsUUFBSTBFLG1CQUFtQk0sd0JBQXdCQyxpQkFBa0IsUUFBTztBQUV4RSxXQUFPO0FBQUEsTUFDTEUsT0FBTyxHQUFHcEQsaUJBQWlCLElBQUlDLHNCQUFzQjtBQUFBLE1BQ3JEWixhQUFhVCxZQUFZb0IsaUJBQWlCO0FBQUEsTUFDMUNULGtCQUFrQlgsWUFBWXFCLHNCQUFzQjtBQUFBLE1BQ3BEUixjQUFjYixZQUFZc0Isa0JBQWtCO0FBQUEsTUFDNUNtRCxRQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0YsR0FBRyxDQUFDVixpQkFBaUIzQyxtQkFBbUJrRCxrQkFBa0JoRCxvQkFBb0IrQyxzQkFBc0JoRCxzQkFBc0IsQ0FBQztBQUUzSCxRQUFNcUQsa0JBQWtCckYsUUFBNEIsTUFBTTtBQUN4RCxRQUFJNkIsa0JBQWtCLFVBQVU7QUFDOUIsVUFBSSxDQUFDeUMsc0JBQXVCLFFBQU87QUFFbkMsYUFBTztBQUFBLFFBQ0xhLE9BQU9iLHNCQUFzQmE7QUFBQUEsUUFDN0IvRCxhQUFha0Qsc0JBQXNCbEQ7QUFBQUEsUUFDbkNFLGtCQUFrQmdELHNCQUFzQmhEO0FBQUFBLFFBQ3hDRSxjQUFjOEMsc0JBQXNCOUM7QUFBQUEsUUFDcEM0RCxRQUFRO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFFQSxXQUFPRjtBQUFBQSxFQUNULEdBQUcsQ0FBQ3JELGVBQWVxRCxlQUFlWixxQkFBcUIsQ0FBQztBQUV4RCxRQUFNZ0IsYUFBYXRGLFFBQVEsTUFBTTtBQUMvQixRQUFJNkIsa0JBQWtCLFlBQVksQ0FBQ3lDLHVCQUF1QjtBQUN4RCxhQUFPO0FBQUEsSUFDVDtBQUVBLFFBQUl6QyxrQkFBa0IsWUFBWSxDQUFDcUQsZUFBZTtBQUNoRCxhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU87QUFBQSxFQUNULEdBQUcsQ0FBQ3JELGVBQWVxRCxlQUFlWixxQkFBcUIsQ0FBQztBQUV4RCxRQUFNaUIsV0FBV0Ysb0JBQW9CO0FBQ3JDLFFBQU1HLFVBQVU5QyxZQUFZK0MsU0FBUztBQUVyQyxRQUFNQyxtQkFBbUIxRjtBQUFBQSxJQUN2QixPQUFPO0FBQUEsTUFDTG9GLFFBQVF2RDtBQUFBQSxNQUNSOEQsVUFBVTdEO0FBQUFBLE1BQ1ZDO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FDO0FBQUFBLElBQ0Y7QUFBQSxJQUNBLENBQUNKLGVBQWVFLG1CQUFtQkUsb0JBQW9CRCx3QkFBd0JGLGNBQWM7QUFBQSxFQUMvRjtBQUVBLFFBQU04RCxvQkFBb0I1RjtBQUFBQSxJQUN4QixPQUFPO0FBQUEsTUFDTDJCO0FBQUFBLE1BQ0FVO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FMO0FBQUFBLE1BQ0F5RCxZQUFZbEQsU0FBU2tEO0FBQUFBLElBQ3ZCO0FBQUEsSUFDQSxDQUFDdEQsd0JBQXdCRixZQUFZRyxVQUFVYixPQUFPVyxhQUFhSyxTQUFTa0QsWUFBWXpELGdCQUFnQkssV0FBVztBQUFBLEVBQ3JIO0FBRUEsUUFBTXFELHNCQUFzQjlGLFFBQVEsTUFBTTtBQUN4QyxRQUFJLE9BQU8rRixjQUFjLFlBQWEsUUFBTztBQUU3QyxVQUFNQyxrQkFBNEI7QUFDbEMsUUFBSSxFQUFFLG1CQUFtQkQsWUFBWTtBQUNuQ0Msc0JBQWdCQyxLQUFLLGlCQUFpQjtBQUFBLElBQ3hDO0FBQ0EsUUFBSSxFQUFFLGNBQWNGLFlBQVk7QUFDOUJDLHNCQUFnQkMsS0FBSyxtQkFBbUI7QUFBQSxJQUMxQztBQUVBLFFBQUlELGdCQUFnQlAsV0FBVyxFQUFHLFFBQU87QUFFekMsVUFBTVMsZ0JBQ0pGLGdCQUFnQlAsV0FBVyxJQUN2Qk8sZ0JBQWdCLENBQUMsSUFDakIsR0FBR0EsZ0JBQWdCRyxNQUFNLEdBQUcsRUFBRSxFQUFFQyxLQUFLLElBQUksQ0FBQyxRQUFRSixnQkFBZ0JBLGdCQUFnQlAsU0FBUyxDQUFDLENBQUM7QUFFbkcsV0FBTywyQ0FBMkNTLGFBQWE7QUFBQSxFQUNqRSxHQUFHLEVBQUU7QUFFTDNGLDBCQUF3QjtBQUFBLElBQ3RCb0M7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQThDO0FBQUFBLElBQ0FFO0FBQUFBLElBQ0E5QjtBQUFBQSxJQUNBQztBQUFBQSxJQUNBc0Msa0JBQWtCbEM7QUFBQUEsRUFDcEIsQ0FBQztBQUVEM0QsMkJBQXlCO0FBQUEsSUFDdkJxRixZQUFZbEQsU0FBU2tEO0FBQUFBLElBQ3JCM0I7QUFBQUEsRUFDRixDQUFDO0FBRUR6RCxjQUFZO0FBQUEsSUFDVjZGLFNBQVMzRCxTQUFTNEQ7QUFBQUEsSUFDbEJDLFNBQVN6RjtBQUFBQSxFQUNYLENBQUM7QUFFRFosZ0JBQWM7QUFBQSxJQUNad0I7QUFBQUEsSUFDQWE7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQVk7QUFBQUEsRUFDRixDQUFDO0FBRUQsUUFBTW9ELHFCQUFxQjFHLFlBQVksTUFBTTtBQUMzQ3NFLHNCQUFrQixXQUFXLHlEQUF5RDtBQUFBLEVBQ3hGLEdBQUcsQ0FBQ0EsaUJBQWlCLENBQUM7QUFFdEIsUUFBTSxFQUFFcUMsWUFBWUMsWUFBWUMsZ0JBQWdCLElBQUl2RyxnQkFBZ0I7QUFBQSxJQUNsRW1HLFNBQVN6RjtBQUFBQSxJQUNUOEYsZ0JBQWdCSjtBQUFBQSxFQUNsQixDQUFDO0FBRUQsUUFBTUssbUJBQW1CeEcscUJBQXFCO0FBQUEsSUFDNUNxQjtBQUFBQSxJQUNBYTtBQUFBQSxJQUNBQztBQUFBQSxJQUNBeUI7QUFBQUEsRUFDRixDQUFDO0FBRUQsUUFBTTZDLDBCQUEwQmhIO0FBQUFBLElBQzlCLENBQUNpSCxTQUE2QztBQUM1QyxVQUFJckUsU0FBU3NFLGFBQWEsT0FBT2xCLGNBQWMsZUFBZSxhQUFhQSxXQUFXO0FBQ3BGLFlBQUk7QUFDRkEsb0JBQVVtQixRQUFRRixTQUFTLGdCQUFnQixLQUFLLEVBQUU7QUFBQSxRQUNwRCxTQUFTRyxPQUFPO0FBQ2RwRyx1QkFBYW9HLE9BQU8sRUFBRS9CLFFBQVEsV0FBVzRCLEtBQUssQ0FBQztBQUFBLFFBQ2pEO0FBQUEsTUFDRjtBQUVBLFVBQUksQ0FBQ3JFLFNBQVN5RSxTQUFTLE9BQU9DLFdBQVcsWUFBYTtBQUV0RCxVQUFJO0FBQ0YsY0FBTUMsV0FBV0QsT0FBT0UsZ0JBQWlCRixPQUF3RUc7QUFDakgsWUFBSSxDQUFDRixTQUFVO0FBQ2YsY0FBTUcsVUFBVSxJQUFJSCxTQUFTO0FBQzdCLGNBQU1JLGFBQWFELFFBQVFFLGlCQUFpQjtBQUM1QyxjQUFNQyxPQUFPSCxRQUFRSSxXQUFXO0FBRWhDSCxtQkFBV0ksT0FBTztBQUNsQkosbUJBQVdLLFVBQVVwRCxRQUFRcUMsU0FBUyxnQkFBZ0IsTUFBTTtBQUM1RFksYUFBS0EsS0FBS2pELFFBQVE7QUFFbEIrQyxtQkFBV00sUUFBUUosSUFBSTtBQUN2QkEsYUFBS0ksUUFBUVAsUUFBUVEsV0FBVztBQUVoQ1AsbUJBQVdRLE1BQU07QUFDakJSLG1CQUFXUyxLQUFLVixRQUFRVyxjQUFjLElBQUk7QUFFMUNWLG1CQUFXVyxVQUFVLE1BQU07QUFDekJaLGtCQUFRYSxNQUFNLEVBQUVDLE1BQU0sTUFBTUMsTUFBUztBQUFBLFFBQ3ZDO0FBQUEsTUFDRixTQUFTckIsT0FBTztBQUNkcEcscUJBQWFvRyxPQUFPLEVBQUUvQixRQUFRLGtCQUFrQjRCLEtBQUssQ0FBQztBQUFBLE1BQ3hEO0FBQUEsSUFDRjtBQUFBLElBQ0EsQ0FBQ3JFLFNBQVN5RSxPQUFPekUsU0FBU3NFLFNBQVM7QUFBQSxFQUNyQztBQUVBLFFBQU13QixvQkFBb0IxSTtBQUFBQSxJQUN4QixDQUFDbUIsWUFBZ0M7QUFDL0IsVUFBSSxDQUFDQSxRQUFTLFFBQU9zSDtBQUVyQixZQUFNRSxTQUFTQyxLQUFLQyxJQUFJLEdBQUdELEtBQUtFLE1BQU0zSCxRQUFRRSxjQUFjLEtBQUssR0FBSSxDQUFDO0FBQ3RFLFlBQU0wSCxZQUFZSCxLQUFLQyxJQUFJLEdBQUdGLFNBQVNwRyxZQUFZeUcsS0FBSyxJQUFJSixLQUFLQyxJQUFJLEdBQUdGLFNBQVNwRyxZQUFZMEcsS0FBSztBQUNsRyxhQUFPTCxLQUFLRSxNQUFNQyxZQUFZLEdBQUk7QUFBQSxJQUNwQztBQUFBLElBQ0EsQ0FBQ3hHLFlBQVkwRyxPQUFPMUcsWUFBWXlHLEtBQUs7QUFBQSxFQUN2QztBQUVBLFFBQU1FLDJCQUEyQmxKO0FBQUFBLElBQy9CLENBQUNtSixZQUlLO0FBQ0osWUFBTWhJLFVBQVVnSSxTQUFTaEksV0FBV2tCO0FBQ3BDLFlBQU0rRyxhQUFzQztBQUFBLFFBQzFDQyxhQUFhekcsU0FBU2tEO0FBQUFBLFFBQ3RCLEdBQUc1RSwwQkFBMEJDLFdBQVcsSUFBSTtBQUFBLFFBQzVDLEdBQUlnSSxTQUFTRyxTQUFTLENBQUM7QUFBQSxNQUN6QjtBQUVBLFVBQUlILFNBQVNJLHVCQUF1QjtBQUNsQyxjQUFNQyxpQkFBaUJkLGtCQUFrQnZILFdBQVcsSUFBSTtBQUN4RCxZQUFJLE9BQU9xSSxtQkFBbUIsVUFBVTtBQUN0Q0oscUJBQVdLLGtCQUFrQkQ7QUFBQUEsUUFDL0I7QUFBQSxNQUNGO0FBRUEsYUFBT0o7QUFBQUEsSUFDVDtBQUFBLElBQ0EsQ0FBQ1YsbUJBQW1COUYsU0FBU2tELFlBQVl6RCxjQUFjO0FBQUEsRUFDekQ7QUFFQSxRQUFNcUgsZ0JBQWdCLFlBQVk7QUFDaEMsVUFBTUMsU0FBUyxNQUFNL0MsV0FBVztBQUNoQyxVQUFNZ0QsV0FBV0QsV0FBVztBQUU1QjFJO0FBQUFBLE1BQ0U7QUFBQSxNQUNBaUkseUJBQXlCO0FBQUEsUUFDdkJJLE9BQU8sRUFBRU0sU0FBUztBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNIO0FBRUEsUUFBSUQsV0FBVyxZQUFZO0FBQ3pCckYsd0JBQWtCLFdBQVcsbUJBQW1CO0FBQUEsSUFDbEQsV0FBV3FGLFdBQVcsYUFBYTtBQUNqQ3JGLHdCQUFrQixRQUFRLG9CQUFvQjtBQUFBLElBQ2hELE9BQU87QUFDTEEsd0JBQWtCLFNBQVMsa0RBQWtEO0FBQUEsSUFDL0U7QUFBQSxFQUNGO0FBRUEsUUFBTXVGLGNBQWMsWUFBWTtBQUM5QixVQUFNRixTQUFTLE1BQU05QyxnQkFBZ0I7QUFFckM1RjtBQUFBQSxNQUNFO0FBQUEsTUFDQWlJLHlCQUF5QjtBQUFBLFFBQ3ZCSSxPQUFPO0FBQUEsVUFDTFEsUUFBUUgsT0FBT0c7QUFBQUEsVUFDZkMsU0FBU0osT0FBT0ksWUFBWSxhQUFhLFlBQVlKLE9BQU9JO0FBQUFBLFFBQzlEO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUVBLFFBQUlKLE9BQU9JLFlBQVksV0FBVztBQUNoQ3pGLHdCQUFrQixXQUFXcUYsT0FBT0csV0FBVyxjQUFjLHlCQUF5QiwyQkFBMkI7QUFDakg7QUFBQSxJQUNGO0FBRUEsUUFBSUgsT0FBT0ksWUFBWSxZQUFZO0FBQ2pDekYsd0JBQWtCLFFBQVEsaUJBQWlCO0FBQzNDO0FBQUEsSUFDRjtBQUVBQSxzQkFBa0IsU0FBUyw0Q0FBNEM7QUFBQSxFQUN6RTtBQUVBLFFBQU0wRixjQUFjQSxNQUFNO0FBQ3hCNUcsc0JBQWtCLElBQUk7QUFDdEIsUUFBSSxDQUFDa0MsZ0JBQWlCO0FBRXRCLFVBQU0yRSxvQkFBb0JmLHlCQUF5QjtBQUFBLE1BQ2pEL0gsU0FBU21FO0FBQUFBLE1BQ1RnRSxPQUFPaEUsZ0JBQWdCRCxXQUFXLFdBQVcsRUFBRTZFLFdBQVduSSxlQUFlLElBQUkwRztBQUFBQSxJQUMvRSxDQUFDO0FBQ0R4SCxpQkFBYSxjQUFjZ0osaUJBQWlCO0FBRTVDLFFBQUkzRSxnQkFBZ0JELFdBQVcsVUFBVTtBQUN2Q3BFLG1CQUFhLHdCQUF3QmdKLGlCQUFpQjtBQUFBLElBQ3hEO0FBRUE1RyxjQUFVaUMsZUFBZTtBQUFBLEVBQzNCO0FBRUEsUUFBTTZFLGdCQUFnQkEsQ0FBQ0MsU0FBNEI7QUFDakQsUUFBSTFILGVBQWVELFNBQVU7QUFFN0IsUUFBSTJILFNBQVM5SCxZQUFZO0FBQ3ZCLFlBQU0rSCxhQUFhOUcsU0FBUztBQUM1QixVQUFJLENBQUM4RyxXQUFZO0FBRWpCcEo7QUFBQUEsUUFDRTtBQUFBLFFBQ0FpSSx5QkFBeUI7QUFBQSxVQUN2QkssdUJBQXVCO0FBQUEsVUFDdkJELE9BQU87QUFBQSxZQUNMZ0IsV0FBV0QsV0FBV0U7QUFBQUEsWUFDdEJDLFNBQVNILFdBQVdJO0FBQUFBLFVBQ3RCO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSDtBQUNBekQsOEJBQXdCLGFBQWE7QUFDckM7QUFBQSxJQUNGO0FBRUEvRixpQkFBYSxTQUFTaUkseUJBQXlCLEVBQUVLLHVCQUF1QixLQUFLLENBQUMsQ0FBQztBQUMvRS9GLGNBQVU7QUFDVndELDRCQUF3QixPQUFPO0FBQUEsRUFDakM7QUFFQSxRQUFNMEQsb0JBQW9CQSxNQUFNO0FBQzlCLFFBQUloSSxZQUFhO0FBQ2pCLFVBQU1pSSxhQUFhLENBQUNsSTtBQUNwQnhCLGlCQUFhMEosYUFBYSxVQUFVLFVBQVV6Qix5QkFBeUIsRUFBRUssdUJBQXVCLEtBQUssQ0FBQyxDQUFDO0FBQ3ZHOUYsZ0JBQVk7QUFDWnVELDRCQUF3QjJELGFBQWEsVUFBVSxRQUFRO0FBQUEsRUFDekQ7QUFFQSxRQUFNQyxhQUFhQSxNQUFNO0FBQ3ZCLFFBQUksQ0FBQ2xILFNBQVMsRUFBRztBQUNqQnpDLGlCQUFhLFFBQVFpSSx5QkFBeUIsRUFBRUssdUJBQXVCLEtBQUssQ0FBQyxDQUFDO0FBQUEsRUFDaEY7QUFFQSxRQUFNc0IsY0FBY0EsTUFBTTtBQUN4QixRQUFJLENBQUN4SSxlQUFnQjtBQUVyQnBCLGlCQUFhLFNBQVNpSSx5QkFBeUIsRUFBRUssdUJBQXVCLEtBQUssQ0FBQyxDQUFDO0FBQy9FNUYsY0FBVTtBQUFBLEVBQ1o7QUFFQSxRQUFNbUgscUJBQXFCQSxDQUFDbEYsYUFBcUI7QUFDL0M5QyxxQkFBaUIsUUFBUTtBQUN6QkMsc0JBQWtCNkMsUUFBUTtBQUUxQixVQUFNbUYsV0FBV3BLLFFBQVE2RCxLQUFLLENBQUNDLFdBQVdBLE9BQU9DLE9BQU9rQixRQUFRO0FBQ2hFLFFBQUksQ0FBQ21GLFNBQVU7QUFFZjlKO0FBQUFBLE1BQ0U7QUFBQSxNQUNBaUkseUJBQXlCO0FBQUEsUUFDdkIvSCxTQUFTO0FBQUEsVUFDUGlFLE9BQU8yRixTQUFTM0Y7QUFBQUEsVUFDaEIvRCxhQUFhMEosU0FBUzFKO0FBQUFBLFVBQ3RCRSxrQkFBa0J3SixTQUFTeEo7QUFBQUEsVUFDM0JFLGNBQWNzSixTQUFTdEo7QUFBQUEsVUFDdkI0RCxRQUFRO0FBQUEsUUFDVjtBQUFBLFFBQ0FpRSxPQUFPO0FBQUEsVUFDTFksV0FBV2EsU0FBU3JHO0FBQUFBLFFBQ3RCO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0csdUJBQXVCaEwsWUFBWSxNQUFNO0FBQzdDOEQsc0JBQWtCLElBQUk7QUFBQSxFQUN4QixHQUFHLENBQUNBLGlCQUFpQixDQUFDO0FBRXRCLFFBQU1tSCxnQkFBZ0JsRixzQkFDcEIsdUJBQUMsU0FBSSxXQUFVLHdGQUF1RixNQUFLLFVBQ3hHQSxpQ0FESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsSUFDRTtBQUVKLFFBQU1tRixnQkFDSix1QkFBQyxTQUFJLFdBQVUsc0NBQ1p2RTtBQUFBQSxpQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsU0FBUyxNQUFNLEtBQUsrQyxjQUFjO0FBQUEsUUFDbEMsY0FBVztBQUFBLFFBQ1gsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxZQUFTLFdBQVUsWUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU45QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRQSxJQUNFO0FBQUEsSUFDSjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsU0FBUyxNQUFNLEtBQUtHLFlBQVk7QUFBQSxRQUNoQyxjQUFXO0FBQUEsUUFDWCxXQUFVO0FBQUEsUUFFVjtBQUFBLGlDQUFDLFVBQU8sV0FBVSxZQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQjtBQUFBLFVBQzFCLHVCQUFDLFVBQUssV0FBVSxvQkFBbUIscUJBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUE7QUFBQTtBQUFBLE1BUDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsU0FBUyxNQUFNM0Ysa0JBQWtCLElBQUk7QUFBQSxRQUNyQyxjQUFXO0FBQUEsUUFDWCxpQkFBYztBQUFBLFFBQ2QsaUJBQWVEO0FBQUFBLFFBQ2YsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxhQUFVLFdBQVUsWUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkI7QUFBQSxVQUM3Qix1QkFBQyxVQUFLLFdBQVUsb0JBQW1CLHdCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQztBQUFBO0FBQUE7QUFBQSxNQVQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFVQTtBQUFBLE9BL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQ0E7QUFHRixRQUFNa0gsaUJBQ0o7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFFBQVFsSDtBQUFBQSxNQUNSO0FBQUEsTUFDQSxTQUFTLE1BQU1DLGtCQUFrQixLQUFLO0FBQUEsTUFDdEMsaUJBQWlCTDtBQUFBQTtBQUFBQSxJQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJaUM7QUFJbkMsUUFBTXVILHNCQUFzQnRKLGtCQUFrQixhQUFhTSxrQkFBa0JELFFBQVFrSixTQUFTMUc7QUFDOUYsUUFBTTJHLDJCQUNKeEosa0JBQWtCLGFBQWFNLGtCQUFrQkQsUUFBUW9KLGNBQWN0RztBQUN6RSxRQUFNdUcsdUJBQXVCMUosa0JBQWtCLGFBQWFNLGtCQUFrQkQsUUFBUXNKLFVBQVV2RztBQUVoRyxNQUFJdEQsVUFBVSxhQUFhUyxnQkFBZ0I7QUFDekMsV0FDRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxxQkFBcUIySTtBQUFBQSxRQUNyQixXQUFXYjtBQUFBQSxRQUNYLGVBQWVPO0FBQUFBLFFBQ2YsUUFBUUU7QUFBQUEsUUFDUixTQUFTQztBQUFBQSxRQUNULGVBQWVqSDtBQUFBQTtBQUFBQSxNQXBCakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBb0I2QjtBQUFBLEVBR2pDO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSx1QkFBdUIsQ0FBQ3lCLFdBQTBCdkMsaUJBQWlCdUMsTUFBTTtBQUFBLE1BQ3pFLGdCQUFnQnlGO0FBQUFBLE1BQ2hCLDJCQUEyQjlIO0FBQUFBLE1BQzNCLGdDQUFnQ0M7QUFBQUEsTUFDaEMsNEJBQTRCQztBQUFBQSxNQUM1QixrQkFBa0IsTUFBTUMsV0FBVyxFQUFFa0ksTUFBTSxLQUFLLENBQUM7QUFBQSxNQUNqRCx1QkFBdUIsTUFBTWxJLFdBQVcsRUFBRW9JLFdBQVcsS0FBSyxDQUFDO0FBQUEsTUFDM0QsbUJBQW1CLE1BQU1wSSxXQUFXLEVBQUVzSSxPQUFPLEtBQUssQ0FBQztBQUFBLE1BQ25ELFNBQVN6QjtBQUFBQTtBQUFBQSxJQTFCWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUEwQnVCO0FBRzNCO0FBQUNySSxHQTlnQlFELEtBQUc7QUFBQSxVQUNJckIsYUFDUUEsYUFDQ0EsYUFDR0EsYUFDS0EsYUFDSkEsYUFDWEEsYUFDT0EsYUFDQUEsYUFDSkEsYUFDQ0EsYUFDV0EsYUFDZEEsYUFDR0EsYUFDQUEsYUFDSEEsYUFDTUEsYUFFRUEsYUFDQ0EsYUFDR0EsYUFDS0EsYUFDSkEsYUFDWEEsYUFDT0EsYUFDUkEsYUFDTUEsYUFDUEEsYUFDQ0EsYUFDRUEsYUFDSEEsYUFDQ0EsYUFDRUEsYUFDRUEsYUFDSUEsYUFDREEsYUFDU0EsYUFJV0Ysa0JBcUg3Q0sseUJBVUFDLDBCQUtBQyxhQUtBTixlQVdvREUsaUJBSzNCQyxvQkFBb0I7QUFBQTtBQUFBLEtBbE10Q21CO0FBZ2hCVCxlQUFlQTtBQUFHLElBQUFnSztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJEb3dubG9hZCIsIlNldHRpbmdzMiIsIlNoYXJlMiIsInVzZUNhbGxiYWNrIiwidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlQWN0aW9uTWVzc2FnZSIsInVzZUdhbWVUaWNrZXIiLCJ1c2VBcHBTdG9yZSIsInVzZUluc3RhbGxTaGFyZSIsInVzZUxpdmVBbm5vdW5jZW1lbnRzIiwidXNlUGVyc2lzdGVuY2VMaWZlY3ljbGUiLCJ1c2VUZWxlbWV0cnlBcHBMaWZlY3ljbGUiLCJ1c2VXYWtlTG9jayIsIlBSRVNFVFMiLCJwYXJzZU51bWJlciIsIkdhbWVTY3JlZW4iLCJTZXR0aW5nc0RyYXdlciIsIlNldHVwU2NyZWVuIiwiY2FwdHVyZUVycm9yIiwiY2FwdHVyZUV2ZW50IiwiZ2V0Q29udHJvbEV2ZW50UHJvcGVydGllcyIsImNvbnRyb2wiLCJiYXNlX21pbnV0ZXMiLCJiYXNlTWludXRlcyIsImluY3JlbWVudF9zZWNvbmRzIiwiaW5jcmVtZW50U2Vjb25kcyIsImRlbGF5X3NlY29uZHMiLCJkZWxheVNlY29uZHMiLCJBcHAiLCJfcyIsInBoYXNlIiwic3RhdGUiLCJjb250cm9sU291cmNlIiwic2VsZWN0ZWRQcmVzZXQiLCJjdXN0b21CYXNlTWludXRlcyIsImN1c3RvbUluY3JlbWVudFNlY29uZHMiLCJjdXN0b21EZWxheVNlY29uZHMiLCJ0b3VjaGVkIiwiYXR0ZW1wdGVkU3RhcnQiLCJzdGFydGVkQ29udHJvbCIsImFjdGl2ZVNpZGUiLCJyZW1haW5pbmdNcyIsImFjdGl2ZURlbGF5UmVtYWluaW5nTXMiLCJpc1BhdXNlZCIsInRpbWVvdXRTaWRlIiwidW5kb0hpc3RvcnkiLCJzZXR0aW5ncyIsIm9uYm9hcmRpbmdTZWVuIiwic2V0Q29udHJvbFNvdXJjZSIsInNldFNlbGVjdGVkUHJlc2V0Iiwic2V0Q3VzdG9tQmFzZU1pbnV0ZXMiLCJzZXRDdXN0b21JbmNyZW1lbnRTZWNvbmRzIiwic2V0Q3VzdG9tRGVsYXlTZWNvbmRzIiwic2V0VG91Y2hlZCIsInNldEF0dGVtcHRlZFN0YXJ0Iiwic3RhcnRHYW1lIiwidGlja0FjdGl2ZUNsb2NrIiwicGFzc1R1cm4iLCJwYXVzZUdhbWUiLCJ0b2dnbGVQYXVzZSIsInVuZG9UdXJuIiwicmVzZXRHYW1lIiwiYmFja1RvU2V0dXAiLCJ1cGRhdGVTZXR0aW5nIiwic2V0T25ib2FyZGluZ1NlZW4iLCJwZXJzaXN0R2FtZVN0YXRlIiwicmVzdG9yZVBlcnNpc3RlZEdhbWVTdGF0ZSIsImlzU2V0dGluZ3NPcGVuIiwic2V0SXNTZXR0aW5nc09wZW4iLCJyZXN0b3JlT3V0Y29tZSIsInNldFJlc3RvcmVPdXRjb21lIiwiYWN0aW9uTWVzc2FnZSIsInNob3dBY3Rpb25NZXNzYWdlIiwic2VsZWN0ZWRQcmVzZXRDb250cm9sIiwiZmluZCIsInByZXNldCIsImlkIiwiY3VzdG9tQmFzZUVycm9yIiwidmFsdWUiLCJ0cmltIiwicGFyc2VkIiwiTnVtYmVyIiwiaXNOYU4iLCJjdXN0b21JbmNyZW1lbnRFcnJvciIsImN1c3RvbURlbGF5RXJyb3IiLCJjdXN0b21Db250cm9sIiwibGFiZWwiLCJzb3VyY2UiLCJzZWxlY3RlZENvbnRyb2wiLCJzdGFydEVycm9yIiwiY2FuU3RhcnQiLCJjYW5VbmRvIiwibGVuZ3RoIiwiY29udHJvbFNlbGVjdGlvbiIsInByZXNldElkIiwiZ2FtZVN0YXRlU25hcHNob3QiLCJsYXlvdXRNb2RlIiwiZGVncmFkZWRNb2RlV2FybmluZyIsIm5hdmlnYXRvciIsIm1pc3NpbmdGZWF0dXJlcyIsInB1c2giLCJmZWF0dXJlc0xhYmVsIiwic2xpY2UiLCJqb2luIiwib25SZXN0b3JlT3V0Y29tZSIsImVuYWJsZWQiLCJrZWVwU2NyZWVuQXdha2UiLCJvbkVycm9yIiwiaGFuZGxlQXBwSW5zdGFsbGVkIiwiY2FuSW5zdGFsbCIsImluc3RhbGxBcHAiLCJzaGFyZUN1cnJlbnRVcmwiLCJvbkFwcEluc3RhbGxlZCIsImxpdmVBbm5vdW5jZW1lbnQiLCJwbGF5SW50ZXJhY3Rpb25GZWVkYmFjayIsImtpbmQiLCJ2aWJyYXRpb24iLCJ2aWJyYXRlIiwiZXJyb3IiLCJzb3VuZCIsIndpbmRvdyIsIkF1ZGlvQ3R4IiwiQXVkaW9Db250ZXh0Iiwid2Via2l0QXVkaW9Db250ZXh0IiwiY29udGV4dCIsIm9zY2lsbGF0b3IiLCJjcmVhdGVPc2NpbGxhdG9yIiwiZ2FpbiIsImNyZWF0ZUdhaW4iLCJ0eXBlIiwiZnJlcXVlbmN5IiwiY29ubmVjdCIsImRlc3RpbmF0aW9uIiwic3RhcnQiLCJzdG9wIiwiY3VycmVudFRpbWUiLCJvbmVuZGVkIiwiY2xvc2UiLCJjYXRjaCIsInVuZGVmaW5lZCIsImdldEVsYXBzZWRTZWNvbmRzIiwiYmFzZU1zIiwiTWF0aCIsIm1heCIsInJvdW5kIiwiZWxhcHNlZE1zIiwiV2hpdGUiLCJCbGFjayIsImJ1aWxkQ29yZUV2ZW50UHJvcGVydGllcyIsIm9wdGlvbnMiLCJwcm9wZXJ0aWVzIiwibGF5b3V0X21vZGUiLCJleHRyYSIsImluY2x1ZGVFbGFwc2VkU2Vjb25kcyIsImVsYXBzZWRTZWNvbmRzIiwiZWxhcHNlZF9zZWNvbmRzIiwiaGFuZGxlSW5zdGFsbCIsInJlc3VsdCIsImFjY2VwdGVkIiwiaGFuZGxlU2hhcmUiLCJtZXRob2QiLCJvdXRjb21lIiwiaGFuZGxlU3RhcnQiLCJjb250cm9sUHJvcGVydGllcyIsInByZXNldF9pZCIsImhhbmRsZVNpZGVUYXAiLCJzaWRlIiwidHVyblN3aXRjaCIsImZyb21fc2lkZSIsImZyb21TaWRlIiwidG9fc2lkZSIsInRvU2lkZSIsImhhbmRsZVBhdXNlUmVzdW1lIiwibmV4dFBhdXNlZCIsImhhbmRsZVVuZG8iLCJoYW5kbGVSZXNldCIsImhhbmRsZVByZXNldFNlbGVjdCIsInNlbGVjdGVkIiwiZGlzbWlzc09uYm9hcmRpbmdDdWUiLCJ3YXJuaW5nQmFubmVyIiwiaGVhZGVyQWN0aW9ucyIsInNldHRpbmdzRHJhd2VyIiwic2hvd0N1c3RvbUJhc2VFcnJvciIsImJhc2UiLCJzaG93Q3VzdG9tSW5jcmVtZW50RXJyb3IiLCJpbmNyZW1lbnQiLCJzaG93Q3VzdG9tRGVsYXlFcnJvciIsImRlbGF5IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEb3dubG9hZCwgU2V0dGluZ3MyLCBTaGFyZTIgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZUFjdGlvbk1lc3NhZ2UgfSBmcm9tICdAL2FwcC9ob29rcy91c2VBY3Rpb25NZXNzYWdlJ1xuaW1wb3J0IHsgdXNlR2FtZVRpY2tlciB9IGZyb20gJ0AvYXBwL2hvb2tzL3VzZUdhbWVUaWNrZXInXG5pbXBvcnQgeyB1c2VBcHBTdG9yZSB9IGZyb20gJ0AvYXBwL3N0b3JlJ1xuaW1wb3J0IHsgdXNlSW5zdGFsbFNoYXJlIH0gZnJvbSAnQC9hcHAvaG9va3MvdXNlSW5zdGFsbFNoYXJlJ1xuaW1wb3J0IHsgdXNlTGl2ZUFubm91bmNlbWVudHMgfSBmcm9tICdAL2FwcC9ob29rcy91c2VMaXZlQW5ub3VuY2VtZW50cydcbmltcG9ydCB7IHVzZVBlcnNpc3RlbmNlTGlmZWN5Y2xlIH0gZnJvbSAnQC9hcHAvaG9va3MvdXNlUGVyc2lzdGVuY2VMaWZlY3ljbGUnXG5pbXBvcnQgeyB1c2VUZWxlbWV0cnlBcHBMaWZlY3ljbGUgfSBmcm9tICdAL2FwcC9ob29rcy91c2VUZWxlbWV0cnlBcHBMaWZlY3ljbGUnXG5pbXBvcnQgeyB1c2VXYWtlTG9jayB9IGZyb20gJ0AvYXBwL2hvb2tzL3VzZVdha2VMb2NrJ1xuaW1wb3J0IHtcbiAgUFJFU0VUUyxcbiAgcGFyc2VOdW1iZXIsXG4gIHR5cGUgQ29udHJvbFNvdXJjZSxcbiAgdHlwZSBUaW1lQ29udHJvbCxcbn0gZnJvbSAnQC9hcHAvdHlwZXMnXG5pbXBvcnQgeyBHYW1lU2NyZWVuIH0gZnJvbSAnQC9mZWF0dXJlcy9nYW1lcGxheS9jb21wb25lbnRzL0dhbWVTY3JlZW4nXG5pbXBvcnQgeyBTZXR0aW5nc0RyYXdlciB9IGZyb20gJ0AvZmVhdHVyZXMvc2V0dGluZ3MvY29tcG9uZW50cy9TZXR0aW5nc0RyYXdlcidcbmltcG9ydCB7IFNldHVwU2NyZWVuIH0gZnJvbSAnQC9mZWF0dXJlcy9zZXR1cC9jb21wb25lbnRzL1NldHVwU2NyZWVuJ1xuaW1wb3J0IHsgY2FwdHVyZUVycm9yLCBjYXB0dXJlRXZlbnQgfSBmcm9tICdAL2xpYi90ZWxlbWV0cnknXG5cbmNvbnN0IGdldENvbnRyb2xFdmVudFByb3BlcnRpZXMgPSAoY29udHJvbDogVGltZUNvbnRyb2wgfCBudWxsKSA9PiB7XG4gIGlmICghY29udHJvbCkgcmV0dXJuIHt9XG5cbiAgcmV0dXJuIHtcbiAgICBiYXNlX21pbnV0ZXM6IGNvbnRyb2wuYmFzZU1pbnV0ZXMsXG4gICAgaW5jcmVtZW50X3NlY29uZHM6IGNvbnRyb2wuaW5jcmVtZW50U2Vjb25kcyxcbiAgICBkZWxheV9zZWNvbmRzOiBjb250cm9sLmRlbGF5U2Vjb25kcyxcbiAgfVxufVxuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IHBoYXNlID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5waGFzZSlcbiAgY29uc3QgY29udHJvbFNvdXJjZSA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUuY29udHJvbFNvdXJjZSlcbiAgY29uc3Qgc2VsZWN0ZWRQcmVzZXQgPSB1c2VBcHBTdG9yZSgoc3RhdGUpID0+IHN0YXRlLnNlbGVjdGVkUHJlc2V0KVxuICBjb25zdCBjdXN0b21CYXNlTWludXRlcyA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUuY3VzdG9tQmFzZU1pbnV0ZXMpXG4gIGNvbnN0IGN1c3RvbUluY3JlbWVudFNlY29uZHMgPSB1c2VBcHBTdG9yZSgoc3RhdGUpID0+IHN0YXRlLmN1c3RvbUluY3JlbWVudFNlY29uZHMpXG4gIGNvbnN0IGN1c3RvbURlbGF5U2Vjb25kcyA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUuY3VzdG9tRGVsYXlTZWNvbmRzKVxuICBjb25zdCB0b3VjaGVkID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS50b3VjaGVkKVxuICBjb25zdCBhdHRlbXB0ZWRTdGFydCA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUuYXR0ZW1wdGVkU3RhcnQpXG4gIGNvbnN0IHN0YXJ0ZWRDb250cm9sID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5zdGFydGVkQ29udHJvbClcbiAgY29uc3QgYWN0aXZlU2lkZSA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUuYWN0aXZlU2lkZSlcbiAgY29uc3QgcmVtYWluaW5nTXMgPSB1c2VBcHBTdG9yZSgoc3RhdGUpID0+IHN0YXRlLnJlbWFpbmluZ01zKVxuICBjb25zdCBhY3RpdmVEZWxheVJlbWFpbmluZ01zID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5hY3RpdmVEZWxheVJlbWFpbmluZ01zKVxuICBjb25zdCBpc1BhdXNlZCA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUuaXNQYXVzZWQpXG4gIGNvbnN0IHRpbWVvdXRTaWRlID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS50aW1lb3V0U2lkZSlcbiAgY29uc3QgdW5kb0hpc3RvcnkgPSB1c2VBcHBTdG9yZSgoc3RhdGUpID0+IHN0YXRlLnVuZG9IaXN0b3J5KVxuICBjb25zdCBzZXR0aW5ncyA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUuc2V0dGluZ3MpXG4gIGNvbnN0IG9uYm9hcmRpbmdTZWVuID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5vbmJvYXJkaW5nU2VlbilcblxuICBjb25zdCBzZXRDb250cm9sU291cmNlID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5zZXRDb250cm9sU291cmNlKVxuICBjb25zdCBzZXRTZWxlY3RlZFByZXNldCA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUuc2V0U2VsZWN0ZWRQcmVzZXQpXG4gIGNvbnN0IHNldEN1c3RvbUJhc2VNaW51dGVzID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5zZXRDdXN0b21CYXNlTWludXRlcylcbiAgY29uc3Qgc2V0Q3VzdG9tSW5jcmVtZW50U2Vjb25kcyA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUuc2V0Q3VzdG9tSW5jcmVtZW50U2Vjb25kcylcbiAgY29uc3Qgc2V0Q3VzdG9tRGVsYXlTZWNvbmRzID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5zZXRDdXN0b21EZWxheVNlY29uZHMpXG4gIGNvbnN0IHNldFRvdWNoZWQgPSB1c2VBcHBTdG9yZSgoc3RhdGUpID0+IHN0YXRlLnNldFRvdWNoZWQpXG4gIGNvbnN0IHNldEF0dGVtcHRlZFN0YXJ0ID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5zZXRBdHRlbXB0ZWRTdGFydClcbiAgY29uc3Qgc3RhcnRHYW1lID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5zdGFydEdhbWUpXG4gIGNvbnN0IHRpY2tBY3RpdmVDbG9jayA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUudGlja0FjdGl2ZUNsb2NrKVxuICBjb25zdCBwYXNzVHVybiA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUucGFzc1R1cm4pXG4gIGNvbnN0IHBhdXNlR2FtZSA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUucGF1c2VHYW1lKVxuICBjb25zdCB0b2dnbGVQYXVzZSA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUudG9nZ2xlUGF1c2UpXG4gIGNvbnN0IHVuZG9UdXJuID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS51bmRvVHVybilcbiAgY29uc3QgcmVzZXRHYW1lID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5yZXNldEdhbWUpXG4gIGNvbnN0IGJhY2tUb1NldHVwID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5iYWNrVG9TZXR1cClcbiAgY29uc3QgdXBkYXRlU2V0dGluZyA9IHVzZUFwcFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUudXBkYXRlU2V0dGluZylcbiAgY29uc3Qgc2V0T25ib2FyZGluZ1NlZW4gPSB1c2VBcHBTdG9yZSgoc3RhdGUpID0+IHN0YXRlLnNldE9uYm9hcmRpbmdTZWVuKVxuICBjb25zdCBwZXJzaXN0R2FtZVN0YXRlID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5wZXJzaXN0R2FtZVN0YXRlKVxuICBjb25zdCByZXN0b3JlUGVyc2lzdGVkR2FtZVN0YXRlID0gdXNlQXBwU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5yZXN0b3JlUGVyc2lzdGVkR2FtZVN0YXRlKVxuXG4gIGNvbnN0IFtpc1NldHRpbmdzT3Blbiwgc2V0SXNTZXR0aW5nc09wZW5dID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtyZXN0b3JlT3V0Y29tZSwgc2V0UmVzdG9yZU91dGNvbWVdID0gdXNlU3RhdGU8J3Jlc3RvcmVkJyB8ICdleHBpcmVkJyB8ICdtaXNzaW5nJyB8ICdpbnZhbGlkJyB8IG51bGw+KG51bGwpXG4gIGNvbnN0IHsgYWN0aW9uTWVzc2FnZSwgc2hvd0FjdGlvbk1lc3NhZ2UgfSA9IHVzZUFjdGlvbk1lc3NhZ2UoKVxuXG4gIGNvbnN0IHNlbGVjdGVkUHJlc2V0Q29udHJvbCA9IHVzZU1lbW8oKCkgPT4gUFJFU0VUUy5maW5kKChwcmVzZXQpID0+IHByZXNldC5pZCA9PT0gc2VsZWN0ZWRQcmVzZXQpLCBbc2VsZWN0ZWRQcmVzZXRdKVxuXG4gIGNvbnN0IGN1c3RvbUJhc2VFcnJvciA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IHZhbHVlID0gY3VzdG9tQmFzZU1pbnV0ZXMudHJpbSgpXG4gICAgaWYgKCF2YWx1ZSkgcmV0dXJuICdCYXNlIG1pbnV0ZXMgaXMgcmVxdWlyZWQuJ1xuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlTnVtYmVyKHZhbHVlKVxuICAgIGlmIChOdW1iZXIuaXNOYU4ocGFyc2VkKSB8fCBwYXJzZWQgPD0gMCkgcmV0dXJuICdCYXNlIG1pbnV0ZXMgbXVzdCBiZSBncmVhdGVyIHRoYW4gMC4nXG4gICAgcmV0dXJuIG51bGxcbiAgfSwgW2N1c3RvbUJhc2VNaW51dGVzXSlcblxuICBjb25zdCBjdXN0b21JbmNyZW1lbnRFcnJvciA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IHZhbHVlID0gY3VzdG9tSW5jcmVtZW50U2Vjb25kcy50cmltKClcbiAgICBpZiAoIXZhbHVlKSByZXR1cm4gJ0luY3JlbWVudCBzZWNvbmRzIGlzIHJlcXVpcmVkLidcbiAgICBjb25zdCBwYXJzZWQgPSBwYXJzZU51bWJlcih2YWx1ZSlcbiAgICBpZiAoTnVtYmVyLmlzTmFOKHBhcnNlZCkgfHwgcGFyc2VkIDwgMCkgcmV0dXJuICdJbmNyZW1lbnQgc2Vjb25kcyBtdXN0IGJlIDAgb3IgZ3JlYXRlci4nXG4gICAgcmV0dXJuIG51bGxcbiAgfSwgW2N1c3RvbUluY3JlbWVudFNlY29uZHNdKVxuXG4gIGNvbnN0IGN1c3RvbURlbGF5RXJyb3IgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCB2YWx1ZSA9IGN1c3RvbURlbGF5U2Vjb25kcy50cmltKClcbiAgICBpZiAoIXZhbHVlKSByZXR1cm4gJ0RlbGF5IHNlY29uZHMgaXMgcmVxdWlyZWQuJ1xuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlTnVtYmVyKHZhbHVlKVxuICAgIGlmIChOdW1iZXIuaXNOYU4ocGFyc2VkKSB8fCBwYXJzZWQgPCAwKSByZXR1cm4gJ0RlbGF5IHNlY29uZHMgbXVzdCBiZSAwIG9yIGdyZWF0ZXIuJ1xuICAgIHJldHVybiBudWxsXG4gIH0sIFtjdXN0b21EZWxheVNlY29uZHNdKVxuXG4gIGNvbnN0IGN1c3RvbUNvbnRyb2wgPSB1c2VNZW1vPFRpbWVDb250cm9sIHwgbnVsbD4oKCkgPT4ge1xuICAgIGlmIChjdXN0b21CYXNlRXJyb3IgfHwgY3VzdG9tSW5jcmVtZW50RXJyb3IgfHwgY3VzdG9tRGVsYXlFcnJvcikgcmV0dXJuIG51bGxcblxuICAgIHJldHVybiB7XG4gICAgICBsYWJlbDogYCR7Y3VzdG9tQmFzZU1pbnV0ZXN9KyR7Y3VzdG9tSW5jcmVtZW50U2Vjb25kc31gLFxuICAgICAgYmFzZU1pbnV0ZXM6IHBhcnNlTnVtYmVyKGN1c3RvbUJhc2VNaW51dGVzKSxcbiAgICAgIGluY3JlbWVudFNlY29uZHM6IHBhcnNlTnVtYmVyKGN1c3RvbUluY3JlbWVudFNlY29uZHMpLFxuICAgICAgZGVsYXlTZWNvbmRzOiBwYXJzZU51bWJlcihjdXN0b21EZWxheVNlY29uZHMpLFxuICAgICAgc291cmNlOiAnY3VzdG9tJyxcbiAgICB9XG4gIH0sIFtjdXN0b21CYXNlRXJyb3IsIGN1c3RvbUJhc2VNaW51dGVzLCBjdXN0b21EZWxheUVycm9yLCBjdXN0b21EZWxheVNlY29uZHMsIGN1c3RvbUluY3JlbWVudEVycm9yLCBjdXN0b21JbmNyZW1lbnRTZWNvbmRzXSlcblxuICBjb25zdCBzZWxlY3RlZENvbnRyb2wgPSB1c2VNZW1vPFRpbWVDb250cm9sIHwgbnVsbD4oKCkgPT4ge1xuICAgIGlmIChjb250cm9sU291cmNlID09PSAncHJlc2V0Jykge1xuICAgICAgaWYgKCFzZWxlY3RlZFByZXNldENvbnRyb2wpIHJldHVybiBudWxsXG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxhYmVsOiBzZWxlY3RlZFByZXNldENvbnRyb2wubGFiZWwsXG4gICAgICAgIGJhc2VNaW51dGVzOiBzZWxlY3RlZFByZXNldENvbnRyb2wuYmFzZU1pbnV0ZXMsXG4gICAgICAgIGluY3JlbWVudFNlY29uZHM6IHNlbGVjdGVkUHJlc2V0Q29udHJvbC5pbmNyZW1lbnRTZWNvbmRzLFxuICAgICAgICBkZWxheVNlY29uZHM6IHNlbGVjdGVkUHJlc2V0Q29udHJvbC5kZWxheVNlY29uZHMsXG4gICAgICAgIHNvdXJjZTogJ3ByZXNldCcsXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGN1c3RvbUNvbnRyb2xcbiAgfSwgW2NvbnRyb2xTb3VyY2UsIGN1c3RvbUNvbnRyb2wsIHNlbGVjdGVkUHJlc2V0Q29udHJvbF0pXG5cbiAgY29uc3Qgc3RhcnRFcnJvciA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmIChjb250cm9sU291cmNlID09PSAncHJlc2V0JyAmJiAhc2VsZWN0ZWRQcmVzZXRDb250cm9sKSB7XG4gICAgICByZXR1cm4gJ1BpY2sgYSBwcmVzZXQgdG8gc3RhcnQuJ1xuICAgIH1cblxuICAgIGlmIChjb250cm9sU291cmNlID09PSAnY3VzdG9tJyAmJiAhY3VzdG9tQ29udHJvbCkge1xuICAgICAgcmV0dXJuICdFbnRlciB2YWxpZCBjdXN0b20gdmFsdWVzIGJlZm9yZSBzdGFydGluZy4nXG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGxcbiAgfSwgW2NvbnRyb2xTb3VyY2UsIGN1c3RvbUNvbnRyb2wsIHNlbGVjdGVkUHJlc2V0Q29udHJvbF0pXG5cbiAgY29uc3QgY2FuU3RhcnQgPSBzZWxlY3RlZENvbnRyb2wgIT09IG51bGxcbiAgY29uc3QgY2FuVW5kbyA9IHVuZG9IaXN0b3J5Lmxlbmd0aCA+IDBcblxuICBjb25zdCBjb250cm9sU2VsZWN0aW9uID0gdXNlTWVtbyhcbiAgICAoKSA9PiAoe1xuICAgICAgc291cmNlOiBjb250cm9sU291cmNlLFxuICAgICAgcHJlc2V0SWQ6IHNlbGVjdGVkUHJlc2V0LFxuICAgICAgY3VzdG9tQmFzZU1pbnV0ZXMsXG4gICAgICBjdXN0b21JbmNyZW1lbnRTZWNvbmRzLFxuICAgICAgY3VzdG9tRGVsYXlTZWNvbmRzLFxuICAgIH0pLFxuICAgIFtjb250cm9sU291cmNlLCBjdXN0b21CYXNlTWludXRlcywgY3VzdG9tRGVsYXlTZWNvbmRzLCBjdXN0b21JbmNyZW1lbnRTZWNvbmRzLCBzZWxlY3RlZFByZXNldF0sXG4gIClcblxuICBjb25zdCBnYW1lU3RhdGVTbmFwc2hvdCA9IHVzZU1lbW8oXG4gICAgKCkgPT4gKHtcbiAgICAgIHBoYXNlLFxuICAgICAgYWN0aXZlU2lkZSxcbiAgICAgIHJlbWFpbmluZ01zLFxuICAgICAgYWN0aXZlRGVsYXlSZW1haW5pbmdNcyxcbiAgICAgIGlzUGF1c2VkLFxuICAgICAgdGltZW91dFNpZGUsXG4gICAgICBzdGFydGVkQ29udHJvbCxcbiAgICAgIGxheW91dE1vZGU6IHNldHRpbmdzLmxheW91dE1vZGUsXG4gICAgfSksXG4gICAgW2FjdGl2ZURlbGF5UmVtYWluaW5nTXMsIGFjdGl2ZVNpZGUsIGlzUGF1c2VkLCBwaGFzZSwgcmVtYWluaW5nTXMsIHNldHRpbmdzLmxheW91dE1vZGUsIHN0YXJ0ZWRDb250cm9sLCB0aW1lb3V0U2lkZV0sXG4gIClcblxuICBjb25zdCBkZWdyYWRlZE1vZGVXYXJuaW5nID0gdXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiBuYXZpZ2F0b3IgPT09ICd1bmRlZmluZWQnKSByZXR1cm4gbnVsbFxuXG4gICAgY29uc3QgbWlzc2luZ0ZlYXR1cmVzOiBzdHJpbmdbXSA9IFtdXG4gICAgaWYgKCEoJ3NlcnZpY2VXb3JrZXInIGluIG5hdmlnYXRvcikpIHtcbiAgICAgIG1pc3NpbmdGZWF0dXJlcy5wdXNoKCdvZmZsaW5lIHN1cHBvcnQnKVxuICAgIH1cbiAgICBpZiAoISgnd2FrZUxvY2snIGluIG5hdmlnYXRvcikpIHtcbiAgICAgIG1pc3NpbmdGZWF0dXJlcy5wdXNoKCdrZWVwLXNjcmVlbi1hd2FrZScpXG4gICAgfVxuXG4gICAgaWYgKG1pc3NpbmdGZWF0dXJlcy5sZW5ndGggPT09IDApIHJldHVybiBudWxsXG5cbiAgICBjb25zdCBmZWF0dXJlc0xhYmVsID1cbiAgICAgIG1pc3NpbmdGZWF0dXJlcy5sZW5ndGggPT09IDFcbiAgICAgICAgPyBtaXNzaW5nRmVhdHVyZXNbMF1cbiAgICAgICAgOiBgJHttaXNzaW5nRmVhdHVyZXMuc2xpY2UoMCwgLTEpLmpvaW4oJywgJyl9IGFuZCAke21pc3NpbmdGZWF0dXJlc1ttaXNzaW5nRmVhdHVyZXMubGVuZ3RoIC0gMV19YFxuXG4gICAgcmV0dXJuIGBIZWFkcyB1cDogeW91ciBicm93c2VyIGRvZXMgbm90IHN1cHBvcnQgJHtmZWF0dXJlc0xhYmVsfS4gVGhlIHRpbWVyIHN0aWxsIHdvcmtzIGluIGRlZ3JhZGVkIG1vZGUuYFxuICB9LCBbXSlcblxuICB1c2VQZXJzaXN0ZW5jZUxpZmVjeWNsZSh7XG4gICAgc2V0dGluZ3MsXG4gICAgb25ib2FyZGluZ1NlZW4sXG4gICAgY29udHJvbFNlbGVjdGlvbixcbiAgICBnYW1lU3RhdGVTbmFwc2hvdCxcbiAgICBwZXJzaXN0R2FtZVN0YXRlLFxuICAgIHJlc3RvcmVQZXJzaXN0ZWRHYW1lU3RhdGUsXG4gICAgb25SZXN0b3JlT3V0Y29tZTogc2V0UmVzdG9yZU91dGNvbWUsXG4gIH0pXG5cbiAgdXNlVGVsZW1ldHJ5QXBwTGlmZWN5Y2xlKHtcbiAgICBsYXlvdXRNb2RlOiBzZXR0aW5ncy5sYXlvdXRNb2RlLFxuICAgIHJlc3RvcmVPdXRjb21lLFxuICB9KVxuXG4gIHVzZVdha2VMb2NrKHtcbiAgICBlbmFibGVkOiBzZXR0aW5ncy5rZWVwU2NyZWVuQXdha2UsXG4gICAgb25FcnJvcjogY2FwdHVyZUVycm9yLFxuICB9KVxuXG4gIHVzZUdhbWVUaWNrZXIoe1xuICAgIHBoYXNlLFxuICAgIGlzUGF1c2VkLFxuICAgIHRpbWVvdXRTaWRlLFxuICAgIHRpY2tBY3RpdmVDbG9jayxcbiAgfSlcblxuICBjb25zdCBoYW5kbGVBcHBJbnN0YWxsZWQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgc2hvd0FjdGlvbk1lc3NhZ2UoJ3N1Y2Nlc3MnLCAnQXBwIGluc3RhbGxlZC4gWW91IGNhbiBsYXVuY2ggaXQgZnJvbSB5b3VyIGhvbWUgc2NyZWVuLicpXG4gIH0sIFtzaG93QWN0aW9uTWVzc2FnZV0pXG5cbiAgY29uc3QgeyBjYW5JbnN0YWxsLCBpbnN0YWxsQXBwLCBzaGFyZUN1cnJlbnRVcmwgfSA9IHVzZUluc3RhbGxTaGFyZSh7XG4gICAgb25FcnJvcjogY2FwdHVyZUVycm9yLFxuICAgIG9uQXBwSW5zdGFsbGVkOiBoYW5kbGVBcHBJbnN0YWxsZWQsXG4gIH0pXG5cbiAgY29uc3QgbGl2ZUFubm91bmNlbWVudCA9IHVzZUxpdmVBbm5vdW5jZW1lbnRzKHtcbiAgICBwaGFzZSxcbiAgICBpc1BhdXNlZCxcbiAgICB0aW1lb3V0U2lkZSxcbiAgICByZXN0b3JlT3V0Y29tZSxcbiAgfSlcblxuICBjb25zdCBwbGF5SW50ZXJhY3Rpb25GZWVkYmFjayA9IHVzZUNhbGxiYWNrKFxuICAgIChraW5kOiAndHVybl9zd2l0Y2gnIHwgJ3BhdXNlJyB8ICdyZXN1bWUnKSA9PiB7XG4gICAgICBpZiAoc2V0dGluZ3MudmlicmF0aW9uICYmIHR5cGVvZiBuYXZpZ2F0b3IgIT09ICd1bmRlZmluZWQnICYmICd2aWJyYXRlJyBpbiBuYXZpZ2F0b3IpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBuYXZpZ2F0b3IudmlicmF0ZShraW5kID09PSAndHVybl9zd2l0Y2gnID8gMjAgOiAxMilcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBjYXB0dXJlRXJyb3IoZXJyb3IsIHsgc291cmNlOiAnaGFwdGljcycsIGtpbmQgfSlcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoIXNldHRpbmdzLnNvdW5kIHx8IHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnKSByZXR1cm5cblxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgQXVkaW9DdHggPSB3aW5kb3cuQXVkaW9Db250ZXh0IHx8ICh3aW5kb3cgYXMgdHlwZW9mIHdpbmRvdyAmIHsgd2Via2l0QXVkaW9Db250ZXh0PzogdHlwZW9mIEF1ZGlvQ29udGV4dCB9KS53ZWJraXRBdWRpb0NvbnRleHRcbiAgICAgICAgaWYgKCFBdWRpb0N0eCkgcmV0dXJuXG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSBuZXcgQXVkaW9DdHgoKVxuICAgICAgICBjb25zdCBvc2NpbGxhdG9yID0gY29udGV4dC5jcmVhdGVPc2NpbGxhdG9yKClcbiAgICAgICAgY29uc3QgZ2FpbiA9IGNvbnRleHQuY3JlYXRlR2FpbigpXG5cbiAgICAgICAgb3NjaWxsYXRvci50eXBlID0gJ3NpbmUnXG4gICAgICAgIG9zY2lsbGF0b3IuZnJlcXVlbmN5LnZhbHVlID0ga2luZCA9PT0gJ3R1cm5fc3dpdGNoJyA/IDkwMCA6IDY0MFxuICAgICAgICBnYWluLmdhaW4udmFsdWUgPSAwLjA0XG5cbiAgICAgICAgb3NjaWxsYXRvci5jb25uZWN0KGdhaW4pXG4gICAgICAgIGdhaW4uY29ubmVjdChjb250ZXh0LmRlc3RpbmF0aW9uKVxuXG4gICAgICAgIG9zY2lsbGF0b3Iuc3RhcnQoKVxuICAgICAgICBvc2NpbGxhdG9yLnN0b3AoY29udGV4dC5jdXJyZW50VGltZSArIDAuMDUpXG5cbiAgICAgICAgb3NjaWxsYXRvci5vbmVuZGVkID0gKCkgPT4ge1xuICAgICAgICAgIGNvbnRleHQuY2xvc2UoKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpXG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNhcHR1cmVFcnJvcihlcnJvciwgeyBzb3VyY2U6ICdzb3VuZF9mZWVkYmFjaycsIGtpbmQgfSlcbiAgICAgIH1cbiAgICB9LFxuICAgIFtzZXR0aW5ncy5zb3VuZCwgc2V0dGluZ3MudmlicmF0aW9uXSxcbiAgKVxuXG4gIGNvbnN0IGdldEVsYXBzZWRTZWNvbmRzID0gdXNlQ2FsbGJhY2soXG4gICAgKGNvbnRyb2w6IFRpbWVDb250cm9sIHwgbnVsbCkgPT4ge1xuICAgICAgaWYgKCFjb250cm9sKSByZXR1cm4gdW5kZWZpbmVkXG5cbiAgICAgIGNvbnN0IGJhc2VNcyA9IE1hdGgubWF4KDAsIE1hdGgucm91bmQoY29udHJvbC5iYXNlTWludXRlcyAqIDYwICogMTAwMCkpXG4gICAgICBjb25zdCBlbGFwc2VkTXMgPSBNYXRoLm1heCgwLCBiYXNlTXMgLSByZW1haW5pbmdNcy5XaGl0ZSkgKyBNYXRoLm1heCgwLCBiYXNlTXMgLSByZW1haW5pbmdNcy5CbGFjaylcbiAgICAgIHJldHVybiBNYXRoLnJvdW5kKGVsYXBzZWRNcyAvIDEwMDApXG4gICAgfSxcbiAgICBbcmVtYWluaW5nTXMuQmxhY2ssIHJlbWFpbmluZ01zLldoaXRlXSxcbiAgKVxuXG4gIGNvbnN0IGJ1aWxkQ29yZUV2ZW50UHJvcGVydGllcyA9IHVzZUNhbGxiYWNrKFxuICAgIChvcHRpb25zPzoge1xuICAgICAgY29udHJvbD86IFRpbWVDb250cm9sIHwgbnVsbFxuICAgICAgaW5jbHVkZUVsYXBzZWRTZWNvbmRzPzogYm9vbGVhblxuICAgICAgZXh0cmE/OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPlxuICAgIH0pID0+IHtcbiAgICAgIGNvbnN0IGNvbnRyb2wgPSBvcHRpb25zPy5jb250cm9sID8/IHN0YXJ0ZWRDb250cm9sXG4gICAgICBjb25zdCBwcm9wZXJ0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHtcbiAgICAgICAgbGF5b3V0X21vZGU6IHNldHRpbmdzLmxheW91dE1vZGUsXG4gICAgICAgIC4uLmdldENvbnRyb2xFdmVudFByb3BlcnRpZXMoY29udHJvbCA/PyBudWxsKSxcbiAgICAgICAgLi4uKG9wdGlvbnM/LmV4dHJhID8/IHt9KSxcbiAgICAgIH1cblxuICAgICAgaWYgKG9wdGlvbnM/LmluY2x1ZGVFbGFwc2VkU2Vjb25kcykge1xuICAgICAgICBjb25zdCBlbGFwc2VkU2Vjb25kcyA9IGdldEVsYXBzZWRTZWNvbmRzKGNvbnRyb2wgPz8gbnVsbClcbiAgICAgICAgaWYgKHR5cGVvZiBlbGFwc2VkU2Vjb25kcyA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICBwcm9wZXJ0aWVzLmVsYXBzZWRfc2Vjb25kcyA9IGVsYXBzZWRTZWNvbmRzXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHByb3BlcnRpZXNcbiAgICB9LFxuICAgIFtnZXRFbGFwc2VkU2Vjb25kcywgc2V0dGluZ3MubGF5b3V0TW9kZSwgc3RhcnRlZENvbnRyb2xdLFxuICApXG5cbiAgY29uc3QgaGFuZGxlSW5zdGFsbCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBpbnN0YWxsQXBwKClcbiAgICBjb25zdCBhY2NlcHRlZCA9IHJlc3VsdCA9PT0gJ2FjY2VwdGVkJ1xuXG4gICAgY2FwdHVyZUV2ZW50KFxuICAgICAgJ3B3YV9pbnN0YWxsJyxcbiAgICAgIGJ1aWxkQ29yZUV2ZW50UHJvcGVydGllcyh7XG4gICAgICAgIGV4dHJhOiB7IGFjY2VwdGVkIH0sXG4gICAgICB9KSxcbiAgICApXG5cbiAgICBpZiAocmVzdWx0ID09PSAnYWNjZXB0ZWQnKSB7XG4gICAgICBzaG93QWN0aW9uTWVzc2FnZSgnc3VjY2VzcycsICdJbnN0YWxsIGFjY2VwdGVkLicpXG4gICAgfSBlbHNlIGlmIChyZXN1bHQgPT09ICdkaXNtaXNzZWQnKSB7XG4gICAgICBzaG93QWN0aW9uTWVzc2FnZSgnaW5mbycsICdJbnN0YWxsIGRpc21pc3NlZC4nKVxuICAgIH0gZWxzZSB7XG4gICAgICBzaG93QWN0aW9uTWVzc2FnZSgnZXJyb3InLCAnSW5zdGFsbCBwcm9tcHQgd2FzIHVuYXZhaWxhYmxlLiBUcnkgYWdhaW4gbGF0ZXIuJylcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVTaGFyZSA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzaGFyZUN1cnJlbnRVcmwoKVxuXG4gICAgY2FwdHVyZUV2ZW50KFxuICAgICAgJ3NoYXJlX2FjdGlvbicsXG4gICAgICBidWlsZENvcmVFdmVudFByb3BlcnRpZXMoe1xuICAgICAgICBleHRyYToge1xuICAgICAgICAgIG1ldGhvZDogcmVzdWx0Lm1ldGhvZCxcbiAgICAgICAgICBvdXRjb21lOiByZXN1bHQub3V0Y29tZSA9PT0gJ2NhbmNlbGVkJyA/ICdmYWlsdXJlJyA6IHJlc3VsdC5vdXRjb21lLFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgKVxuXG4gICAgaWYgKHJlc3VsdC5vdXRjb21lID09PSAnc3VjY2VzcycpIHtcbiAgICAgIHNob3dBY3Rpb25NZXNzYWdlKCdzdWNjZXNzJywgcmVzdWx0Lm1ldGhvZCA9PT0gJ3dlYl9zaGFyZScgPyAnU2hhcmVkIHN1Y2Nlc3NmdWxseS4nIDogJ0xpbmsgY29waWVkIHRvIGNsaXBib2FyZC4nKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgaWYgKHJlc3VsdC5vdXRjb21lID09PSAnY2FuY2VsZWQnKSB7XG4gICAgICBzaG93QWN0aW9uTWVzc2FnZSgnaW5mbycsICdTaGFyZSBjYW5jZWxlZC4nKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgc2hvd0FjdGlvbk1lc3NhZ2UoJ2Vycm9yJywgJ1VuYWJsZSB0byBzaGFyZSB0aGlzIGxpbmsgb24gdGhpcyBicm93c2VyLicpXG4gIH1cblxuICBjb25zdCBoYW5kbGVTdGFydCA9ICgpID0+IHtcbiAgICBzZXRBdHRlbXB0ZWRTdGFydCh0cnVlKVxuICAgIGlmICghc2VsZWN0ZWRDb250cm9sKSByZXR1cm5cblxuICAgIGNvbnN0IGNvbnRyb2xQcm9wZXJ0aWVzID0gYnVpbGRDb3JlRXZlbnRQcm9wZXJ0aWVzKHtcbiAgICAgIGNvbnRyb2w6IHNlbGVjdGVkQ29udHJvbCxcbiAgICAgIGV4dHJhOiBzZWxlY3RlZENvbnRyb2wuc291cmNlID09PSAncHJlc2V0JyA/IHsgcHJlc2V0X2lkOiBzZWxlY3RlZFByZXNldCB9IDogdW5kZWZpbmVkLFxuICAgIH0pXG4gICAgY2FwdHVyZUV2ZW50KCdnYW1lX3N0YXJ0JywgY29udHJvbFByb3BlcnRpZXMpXG5cbiAgICBpZiAoc2VsZWN0ZWRDb250cm9sLnNvdXJjZSA9PT0gJ2N1c3RvbScpIHtcbiAgICAgIGNhcHR1cmVFdmVudCgnY3VzdG9tX2NvbnRyb2xfc2F2ZWQnLCBjb250cm9sUHJvcGVydGllcylcbiAgICB9XG5cbiAgICBzdGFydEdhbWUoc2VsZWN0ZWRDb250cm9sKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlU2lkZVRhcCA9IChzaWRlOiAnV2hpdGUnIHwgJ0JsYWNrJykgPT4ge1xuICAgIGlmICh0aW1lb3V0U2lkZSB8fCBpc1BhdXNlZCkgcmV0dXJuXG5cbiAgICBpZiAoc2lkZSA9PT0gYWN0aXZlU2lkZSkge1xuICAgICAgY29uc3QgdHVyblN3aXRjaCA9IHBhc3NUdXJuKClcbiAgICAgIGlmICghdHVyblN3aXRjaCkgcmV0dXJuXG5cbiAgICAgIGNhcHR1cmVFdmVudChcbiAgICAgICAgJ3R1cm5fc3dpdGNoJyxcbiAgICAgICAgYnVpbGRDb3JlRXZlbnRQcm9wZXJ0aWVzKHtcbiAgICAgICAgICBpbmNsdWRlRWxhcHNlZFNlY29uZHM6IHRydWUsXG4gICAgICAgICAgZXh0cmE6IHtcbiAgICAgICAgICAgIGZyb21fc2lkZTogdHVyblN3aXRjaC5mcm9tU2lkZSxcbiAgICAgICAgICAgIHRvX3NpZGU6IHR1cm5Td2l0Y2gudG9TaWRlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pLFxuICAgICAgKVxuICAgICAgcGxheUludGVyYWN0aW9uRmVlZGJhY2soJ3R1cm5fc3dpdGNoJylcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGNhcHR1cmVFdmVudCgncGF1c2UnLCBidWlsZENvcmVFdmVudFByb3BlcnRpZXMoeyBpbmNsdWRlRWxhcHNlZFNlY29uZHM6IHRydWUgfSkpXG4gICAgcGF1c2VHYW1lKClcbiAgICBwbGF5SW50ZXJhY3Rpb25GZWVkYmFjaygncGF1c2UnKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlUGF1c2VSZXN1bWUgPSAoKSA9PiB7XG4gICAgaWYgKHRpbWVvdXRTaWRlKSByZXR1cm5cbiAgICBjb25zdCBuZXh0UGF1c2VkID0gIWlzUGF1c2VkXG4gICAgY2FwdHVyZUV2ZW50KG5leHRQYXVzZWQgPyAncGF1c2UnIDogJ3Jlc3VtZScsIGJ1aWxkQ29yZUV2ZW50UHJvcGVydGllcyh7IGluY2x1ZGVFbGFwc2VkU2Vjb25kczogdHJ1ZSB9KSlcbiAgICB0b2dnbGVQYXVzZSgpXG4gICAgcGxheUludGVyYWN0aW9uRmVlZGJhY2sobmV4dFBhdXNlZCA/ICdwYXVzZScgOiAncmVzdW1lJylcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVVuZG8gPSAoKSA9PiB7XG4gICAgaWYgKCF1bmRvVHVybigpKSByZXR1cm5cbiAgICBjYXB0dXJlRXZlbnQoJ3VuZG8nLCBidWlsZENvcmVFdmVudFByb3BlcnRpZXMoeyBpbmNsdWRlRWxhcHNlZFNlY29uZHM6IHRydWUgfSkpXG4gIH1cblxuICBjb25zdCBoYW5kbGVSZXNldCA9ICgpID0+IHtcbiAgICBpZiAoIXN0YXJ0ZWRDb250cm9sKSByZXR1cm5cblxuICAgIGNhcHR1cmVFdmVudCgncmVzZXQnLCBidWlsZENvcmVFdmVudFByb3BlcnRpZXMoeyBpbmNsdWRlRWxhcHNlZFNlY29uZHM6IHRydWUgfSkpXG4gICAgcmVzZXRHYW1lKClcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVByZXNldFNlbGVjdCA9IChwcmVzZXRJZDogc3RyaW5nKSA9PiB7XG4gICAgc2V0Q29udHJvbFNvdXJjZSgncHJlc2V0JylcbiAgICBzZXRTZWxlY3RlZFByZXNldChwcmVzZXRJZClcblxuICAgIGNvbnN0IHNlbGVjdGVkID0gUFJFU0VUUy5maW5kKChwcmVzZXQpID0+IHByZXNldC5pZCA9PT0gcHJlc2V0SWQpXG4gICAgaWYgKCFzZWxlY3RlZCkgcmV0dXJuXG5cbiAgICBjYXB0dXJlRXZlbnQoXG4gICAgICAncHJlc2V0X3NlbGVjdGVkJyxcbiAgICAgIGJ1aWxkQ29yZUV2ZW50UHJvcGVydGllcyh7XG4gICAgICAgIGNvbnRyb2w6IHtcbiAgICAgICAgICBsYWJlbDogc2VsZWN0ZWQubGFiZWwsXG4gICAgICAgICAgYmFzZU1pbnV0ZXM6IHNlbGVjdGVkLmJhc2VNaW51dGVzLFxuICAgICAgICAgIGluY3JlbWVudFNlY29uZHM6IHNlbGVjdGVkLmluY3JlbWVudFNlY29uZHMsXG4gICAgICAgICAgZGVsYXlTZWNvbmRzOiBzZWxlY3RlZC5kZWxheVNlY29uZHMsXG4gICAgICAgICAgc291cmNlOiAncHJlc2V0JyxcbiAgICAgICAgfSxcbiAgICAgICAgZXh0cmE6IHtcbiAgICAgICAgICBwcmVzZXRfaWQ6IHNlbGVjdGVkLmlkLFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgKVxuICB9XG5cbiAgY29uc3QgZGlzbWlzc09uYm9hcmRpbmdDdWUgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgc2V0T25ib2FyZGluZ1NlZW4odHJ1ZSlcbiAgfSwgW3NldE9uYm9hcmRpbmdTZWVuXSlcblxuICBjb25zdCB3YXJuaW5nQmFubmVyID0gZGVncmFkZWRNb2RlV2FybmluZyA/IChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBiZy1hbWJlci01MCBweC00IHB5LTMgdGV4dC1zbSB0ZXh0LWFtYmVyLTkwMFwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgIHtkZWdyYWRlZE1vZGVXYXJuaW5nfVxuICAgIDwvZGl2PlxuICApIDogbnVsbFxuXG4gIGNvbnN0IGhlYWRlckFjdGlvbnMgPSAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHNtOmdhcC0yXCI+XG4gICAgICB7Y2FuSW5zdGFsbCA/IChcbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgaGFuZGxlSW5zdGFsbCgpfVxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJJbnN0YWxsIGFwcFwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHB4LTIuNSBweS0xLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBzaGFkb3ctc20gdHJhbnNpdGlvbiBob3ZlcjpiZy1zbGF0ZS01MFwiXG4gICAgICAgID5cbiAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwic2l6ZS00XCIgLz5cbiAgICAgICAgICBJbnN0YWxsXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKSA6IG51bGx9XG4gICAgICA8YnV0dG9uXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGhhbmRsZVNoYXJlKCl9XG4gICAgICAgIGFyaWEtbGFiZWw9XCJTaGFyZSBhcHAgbGlua1wiXG4gICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSBweC0yLjUgcHktMS41IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgc2hhZG93LXNtIHRyYW5zaXRpb24gaG92ZXI6Ymctc2xhdGUtNTBcIlxuICAgICAgPlxuICAgICAgICA8U2hhcmUyIGNsYXNzTmFtZT1cInNpemUtNFwiIC8+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5TaGFyZTwvc3Bhbj5cbiAgICAgIDwvYnV0dG9uPlxuICAgICAgPGJ1dHRvblxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNTZXR0aW5nc09wZW4odHJ1ZSl9XG4gICAgICAgIGFyaWEtbGFiZWw9XCJPcGVuIHNldHRpbmdzXCJcbiAgICAgICAgYXJpYS1oYXNwb3B1cD1cImRpYWxvZ1wiXG4gICAgICAgIGFyaWEtZXhwYW5kZWQ9e2lzU2V0dGluZ3NPcGVufVxuICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcHgtMi41IHB5LTEuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIHNoYWRvdy1zbSB0cmFuc2l0aW9uIGhvdmVyOmJnLXNsYXRlLTUwXCJcbiAgICAgID5cbiAgICAgICAgPFNldHRpbmdzMiBjbGFzc05hbWU9XCJzaXplLTRcIiAvPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+U2V0dGluZ3M8L3NwYW4+XG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKVxuXG4gIGNvbnN0IHNldHRpbmdzRHJhd2VyID0gKFxuICAgIDxTZXR0aW5nc0RyYXdlclxuICAgICAgaXNPcGVuPXtpc1NldHRpbmdzT3Blbn1cbiAgICAgIHNldHRpbmdzPXtzZXR0aW5nc31cbiAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzU2V0dGluZ3NPcGVuKGZhbHNlKX1cbiAgICAgIG9uVXBkYXRlU2V0dGluZz17dXBkYXRlU2V0dGluZ31cbiAgICAvPlxuICApXG5cbiAgY29uc3Qgc2hvd0N1c3RvbUJhc2VFcnJvciA9IGNvbnRyb2xTb3VyY2UgPT09ICdjdXN0b20nICYmIChhdHRlbXB0ZWRTdGFydCB8fCB0b3VjaGVkLmJhc2UpICYmIGN1c3RvbUJhc2VFcnJvclxuICBjb25zdCBzaG93Q3VzdG9tSW5jcmVtZW50RXJyb3IgPVxuICAgIGNvbnRyb2xTb3VyY2UgPT09ICdjdXN0b20nICYmIChhdHRlbXB0ZWRTdGFydCB8fCB0b3VjaGVkLmluY3JlbWVudCkgJiYgY3VzdG9tSW5jcmVtZW50RXJyb3JcbiAgY29uc3Qgc2hvd0N1c3RvbURlbGF5RXJyb3IgPSBjb250cm9sU291cmNlID09PSAnY3VzdG9tJyAmJiAoYXR0ZW1wdGVkU3RhcnQgfHwgdG91Y2hlZC5kZWxheSkgJiYgY3VzdG9tRGVsYXlFcnJvclxuXG4gIGlmIChwaGFzZSA9PT0gJ3N0YXJ0ZWQnICYmIHN0YXJ0ZWRDb250cm9sKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxHYW1lU2NyZWVuXG4gICAgICAgIGhlYWRlckFjdGlvbnM9e2hlYWRlckFjdGlvbnN9XG4gICAgICAgIHdhcm5pbmdCYW5uZXI9e3dhcm5pbmdCYW5uZXJ9XG4gICAgICAgIHNldHRpbmdzRHJhd2VyPXtzZXR0aW5nc0RyYXdlcn1cbiAgICAgICAgYWN0aW9uTWVzc2FnZT17YWN0aW9uTWVzc2FnZX1cbiAgICAgICAgbGl2ZUFubm91bmNlbWVudD17bGl2ZUFubm91bmNlbWVudH1cbiAgICAgICAgc2V0dGluZ3M9e3NldHRpbmdzfVxuICAgICAgICBzdGFydGVkQ29udHJvbD17c3RhcnRlZENvbnRyb2x9XG4gICAgICAgIGFjdGl2ZVNpZGU9e2FjdGl2ZVNpZGV9XG4gICAgICAgIHJlbWFpbmluZ01zPXtyZW1haW5pbmdNc31cbiAgICAgICAgYWN0aXZlRGVsYXlSZW1haW5pbmdNcz17YWN0aXZlRGVsYXlSZW1haW5pbmdNc31cbiAgICAgICAgdGltZW91dFNpZGU9e3RpbWVvdXRTaWRlfVxuICAgICAgICBpc1BhdXNlZD17aXNQYXVzZWR9XG4gICAgICAgIGNhblVuZG89e2NhblVuZG99XG4gICAgICAgIG9uYm9hcmRpbmdTZWVuPXtvbmJvYXJkaW5nU2Vlbn1cbiAgICAgICAgb25EaXNtaXNzT25ib2FyZGluZz17ZGlzbWlzc09uYm9hcmRpbmdDdWV9XG4gICAgICAgIG9uU2lkZVRhcD17aGFuZGxlU2lkZVRhcH1cbiAgICAgICAgb25QYXVzZVJlc3VtZT17aGFuZGxlUGF1c2VSZXN1bWV9XG4gICAgICAgIG9uVW5kbz17aGFuZGxlVW5kb31cbiAgICAgICAgb25SZXNldD17aGFuZGxlUmVzZXR9XG4gICAgICAgIG9uQmFja1RvU2V0dXA9e2JhY2tUb1NldHVwfVxuICAgICAgLz5cbiAgICApXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxTZXR1cFNjcmVlblxuICAgICAgaGVhZGVyQWN0aW9ucz17aGVhZGVyQWN0aW9uc31cbiAgICAgIHdhcm5pbmdCYW5uZXI9e3dhcm5pbmdCYW5uZXJ9XG4gICAgICBzZXR0aW5nc0RyYXdlcj17c2V0dGluZ3NEcmF3ZXJ9XG4gICAgICBhY3Rpb25NZXNzYWdlPXthY3Rpb25NZXNzYWdlfVxuICAgICAgbGl2ZUFubm91bmNlbWVudD17bGl2ZUFubm91bmNlbWVudH1cbiAgICAgIGNvbnRyb2xTb3VyY2U9e2NvbnRyb2xTb3VyY2V9XG4gICAgICBzZWxlY3RlZFByZXNldD17c2VsZWN0ZWRQcmVzZXR9XG4gICAgICBjdXN0b21CYXNlTWludXRlcz17Y3VzdG9tQmFzZU1pbnV0ZXN9XG4gICAgICBjdXN0b21JbmNyZW1lbnRTZWNvbmRzPXtjdXN0b21JbmNyZW1lbnRTZWNvbmRzfVxuICAgICAgY3VzdG9tRGVsYXlTZWNvbmRzPXtjdXN0b21EZWxheVNlY29uZHN9XG4gICAgICBzaG93Q3VzdG9tQmFzZUVycm9yPXtzaG93Q3VzdG9tQmFzZUVycm9yfVxuICAgICAgc2hvd0N1c3RvbUluY3JlbWVudEVycm9yPXtzaG93Q3VzdG9tSW5jcmVtZW50RXJyb3J9XG4gICAgICBzaG93Q3VzdG9tRGVsYXlFcnJvcj17c2hvd0N1c3RvbURlbGF5RXJyb3J9XG4gICAgICBzZWxlY3RlZENvbnRyb2w9e3NlbGVjdGVkQ29udHJvbH1cbiAgICAgIHN0YXJ0RXJyb3I9e3N0YXJ0RXJyb3J9XG4gICAgICBhdHRlbXB0ZWRTdGFydD17YXR0ZW1wdGVkU3RhcnR9XG4gICAgICBjYW5TdGFydD17Y2FuU3RhcnR9XG4gICAgICBvbkNvbnRyb2xTb3VyY2VDaGFuZ2U9eyhzb3VyY2U6IENvbnRyb2xTb3VyY2UpID0+IHNldENvbnRyb2xTb3VyY2Uoc291cmNlKX1cbiAgICAgIG9uUHJlc2V0U2VsZWN0PXtoYW5kbGVQcmVzZXRTZWxlY3R9XG4gICAgICBvbkN1c3RvbUJhc2VNaW51dGVzQ2hhbmdlPXtzZXRDdXN0b21CYXNlTWludXRlc31cbiAgICAgIG9uQ3VzdG9tSW5jcmVtZW50U2Vjb25kc0NoYW5nZT17c2V0Q3VzdG9tSW5jcmVtZW50U2Vjb25kc31cbiAgICAgIG9uQ3VzdG9tRGVsYXlTZWNvbmRzQ2hhbmdlPXtzZXRDdXN0b21EZWxheVNlY29uZHN9XG4gICAgICBvbkN1c3RvbUJhc2VCbHVyPXsoKSA9PiBzZXRUb3VjaGVkKHsgYmFzZTogdHJ1ZSB9KX1cbiAgICAgIG9uQ3VzdG9tSW5jcmVtZW50Qmx1cj17KCkgPT4gc2V0VG91Y2hlZCh7IGluY3JlbWVudDogdHJ1ZSB9KX1cbiAgICAgIG9uQ3VzdG9tRGVsYXlCbHVyPXsoKSA9PiBzZXRUb3VjaGVkKHsgZGVsYXk6IHRydWUgfSl9XG4gICAgICBvblN0YXJ0PXtoYW5kbGVTdGFydH1cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcFxuIl0sImZpbGUiOiIvVXNlcnMvcmlja3lzdWxsaXZhbi9Qcm9qZWN0cy9jaGVzcy10aW1lci9zcmMvQXBwLnRzeCJ9