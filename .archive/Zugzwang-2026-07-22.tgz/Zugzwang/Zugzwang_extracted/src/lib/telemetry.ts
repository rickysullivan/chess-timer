import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};import * as Sentry from "/node_modules/.vite/deps/@sentry_react.js?v=5db2b99c";
import posthog from "/node_modules/.vite/deps/posthog-js.js?v=5db2b99c";
const SESSION_ID_STORAGE_KEY = "chess_timer.session_id";
let cachedSessionId = null;
const toSnakeCase = (value) => value.trim().replace(/([a-z0-9])([A-Z])/g, "$1_$2").replace(/[\s-]+/g, "_").replace(/[^a-zA-Z0-9_]/g, "_").replace(/_{2,}/g, "_").replace(/^_+|_+$/g, "").toLowerCase();
const normalizeProperties = (properties) => {
  const normalized = {};
  if (!properties) return normalized;
  for (const [key, value] of Object.entries(properties)) {
    normalized[toSnakeCase(key)] = value;
  }
  return normalized;
};
const createSessionId = () => {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
};
const getSessionId = () => {
  if (cachedSessionId) return cachedSessionId;
  if (typeof window === "undefined") {
    cachedSessionId = createSessionId();
    return cachedSessionId;
  }
  try {
    const persisted = window.localStorage.getItem(SESSION_ID_STORAGE_KEY);
    if (persisted) {
      cachedSessionId = persisted;
      return persisted;
    }
    const generated = createSessionId();
    window.localStorage.setItem(SESSION_ID_STORAGE_KEY, generated);
    cachedSessionId = generated;
    return generated;
  } catch {
    cachedSessionId = createSessionId();
    return cachedSessionId;
  }
};
export function initTelemetry() {
  const posthogKey = import.meta.env.VITE_POSTHOG_KEY;
  const posthogHost = import.meta.env.VITE_POSTHOG_HOST;
  const sentryDsn = import.meta.env.VITE_SENTRY_DSN;
  const sentryEnvironment = import.meta.env.VITE_SENTRY_ENVIRONMENT;
  if (posthogKey) {
    try {
      posthog.init(posthogKey, {
        api_host: posthogHost || "https://us.i.posthog.com",
        person_profiles: "identified_only",
        capture_pageview: true,
        capture_pageleave: true
      });
    } catch {
    }
  }
  if (sentryDsn) {
    try {
      Sentry.init({
        dsn: sentryDsn,
        environment: sentryEnvironment || "development",
        tracesSampleRate: 0.1
      });
    } catch {
    }
  }
}
export function captureEvent(eventName, properties) {
  const normalizedEventName = toSnakeCase(eventName);
  if (!normalizedEventName) return;
  const payload = normalizeProperties(properties);
  payload.session_id = getSessionId();
  try {
    posthog.capture(normalizedEventName, payload);
  } catch {
  }
  try {
    Sentry.addBreadcrumb({
      category: "analytics",
      message: normalizedEventName,
      level: "info",
      data: payload
    });
  } catch {
  }
}
export function captureError(error, context) {
  const normalizedContext = normalizeProperties(context);
  const normalizedError = error instanceof Error ? error : new Error(String(error ?? "unknown_error"));
  const errorPayload = {
    ...normalizedContext,
    session_id: getSessionId(),
    error_name: normalizedError.name,
    error_message: normalizedError.message
  };
  try {
    posthog.capture("error_captured", errorPayload);
  } catch {
  }
  try {
    Sentry.captureException(normalizedError, {
      extra: normalizedContext
    });
  } catch {
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlbGVtZXRyeS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBTZW50cnkgZnJvbSAnQHNlbnRyeS9yZWFjdCdcbmltcG9ydCBwb3N0aG9nIGZyb20gJ3Bvc3Rob2ctanMnXG5cbmNvbnN0IFNFU1NJT05fSURfU1RPUkFHRV9LRVkgPSAnY2hlc3NfdGltZXIuc2Vzc2lvbl9pZCdcblxubGV0IGNhY2hlZFNlc3Npb25JZDogc3RyaW5nIHwgbnVsbCA9IG51bGxcblxuY29uc3QgdG9TbmFrZUNhc2UgPSAodmFsdWU6IHN0cmluZykgPT5cbiAgdmFsdWVcbiAgICAudHJpbSgpXG4gICAgLnJlcGxhY2UoLyhbYS16MC05XSkoW0EtWl0pL2csICckMV8kMicpXG4gICAgLnJlcGxhY2UoL1tcXHMtXSsvZywgJ18nKVxuICAgIC5yZXBsYWNlKC9bXmEtekEtWjAtOV9dL2csICdfJylcbiAgICAucmVwbGFjZSgvX3syLH0vZywgJ18nKVxuICAgIC5yZXBsYWNlKC9eXyt8XyskL2csICcnKVxuICAgIC50b0xvd2VyQ2FzZSgpXG5cbmNvbnN0IG5vcm1hbGl6ZVByb3BlcnRpZXMgPSAocHJvcGVydGllcz86IFJlY29yZDxzdHJpbmcsIHVua25vd24+KSA9PiB7XG4gIGNvbnN0IG5vcm1hbGl6ZWQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge31cbiAgaWYgKCFwcm9wZXJ0aWVzKSByZXR1cm4gbm9ybWFsaXplZFxuXG4gIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKHByb3BlcnRpZXMpKSB7XG4gICAgbm9ybWFsaXplZFt0b1NuYWtlQ2FzZShrZXkpXSA9IHZhbHVlXG4gIH1cblxuICByZXR1cm4gbm9ybWFsaXplZFxufVxuXG5jb25zdCBjcmVhdGVTZXNzaW9uSWQgPSAoKSA9PiB7XG4gIGlmICh0eXBlb2YgY3J5cHRvICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgY3J5cHRvLnJhbmRvbVVVSUQgPT09ICdmdW5jdGlvbicpIHtcbiAgICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKVxuICB9XG5cbiAgcmV0dXJuIGAke0RhdGUubm93KCl9XyR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMiwgMTApfWBcbn1cblxuY29uc3QgZ2V0U2Vzc2lvbklkID0gKCkgPT4ge1xuICBpZiAoY2FjaGVkU2Vzc2lvbklkKSByZXR1cm4gY2FjaGVkU2Vzc2lvbklkXG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykge1xuICAgIGNhY2hlZFNlc3Npb25JZCA9IGNyZWF0ZVNlc3Npb25JZCgpXG4gICAgcmV0dXJuIGNhY2hlZFNlc3Npb25JZFxuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBwZXJzaXN0ZWQgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oU0VTU0lPTl9JRF9TVE9SQUdFX0tFWSlcbiAgICBpZiAocGVyc2lzdGVkKSB7XG4gICAgICBjYWNoZWRTZXNzaW9uSWQgPSBwZXJzaXN0ZWRcbiAgICAgIHJldHVybiBwZXJzaXN0ZWRcbiAgICB9XG5cbiAgICBjb25zdCBnZW5lcmF0ZWQgPSBjcmVhdGVTZXNzaW9uSWQoKVxuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShTRVNTSU9OX0lEX1NUT1JBR0VfS0VZLCBnZW5lcmF0ZWQpXG4gICAgY2FjaGVkU2Vzc2lvbklkID0gZ2VuZXJhdGVkXG4gICAgcmV0dXJuIGdlbmVyYXRlZFxuICB9IGNhdGNoIHtcbiAgICBjYWNoZWRTZXNzaW9uSWQgPSBjcmVhdGVTZXNzaW9uSWQoKVxuICAgIHJldHVybiBjYWNoZWRTZXNzaW9uSWRcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gaW5pdFRlbGVtZXRyeSgpIHtcbiAgY29uc3QgcG9zdGhvZ0tleSA9IGltcG9ydC5tZXRhLmVudi5WSVRFX1BPU1RIT0dfS0VZXG4gIGNvbnN0IHBvc3Rob2dIb3N0ID0gaW1wb3J0Lm1ldGEuZW52LlZJVEVfUE9TVEhPR19IT1NUXG4gIGNvbnN0IHNlbnRyeURzbiA9IGltcG9ydC5tZXRhLmVudi5WSVRFX1NFTlRSWV9EU05cbiAgY29uc3Qgc2VudHJ5RW52aXJvbm1lbnQgPSBpbXBvcnQubWV0YS5lbnYuVklURV9TRU5UUllfRU5WSVJPTk1FTlRcblxuICBpZiAocG9zdGhvZ0tleSkge1xuICAgIHRyeSB7XG4gICAgICBwb3N0aG9nLmluaXQocG9zdGhvZ0tleSwge1xuICAgICAgICBhcGlfaG9zdDogcG9zdGhvZ0hvc3QgfHwgJ2h0dHBzOi8vdXMuaS5wb3N0aG9nLmNvbScsXG4gICAgICAgIHBlcnNvbl9wcm9maWxlczogJ2lkZW50aWZpZWRfb25seScsXG4gICAgICAgIGNhcHR1cmVfcGFnZXZpZXc6IHRydWUsXG4gICAgICAgIGNhcHR1cmVfcGFnZWxlYXZlOiB0cnVlLFxuICAgICAgfSlcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIG5vb3BcbiAgICB9XG4gIH1cblxuICBpZiAoc2VudHJ5RHNuKSB7XG4gICAgdHJ5IHtcbiAgICAgIFNlbnRyeS5pbml0KHtcbiAgICAgICAgZHNuOiBzZW50cnlEc24sXG4gICAgICAgIGVudmlyb25tZW50OiBzZW50cnlFbnZpcm9ubWVudCB8fCAnZGV2ZWxvcG1lbnQnLFxuICAgICAgICB0cmFjZXNTYW1wbGVSYXRlOiAwLjEsXG4gICAgICB9KVxuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gbm9vcFxuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY2FwdHVyZUV2ZW50KGV2ZW50TmFtZTogc3RyaW5nLCBwcm9wZXJ0aWVzPzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pIHtcbiAgY29uc3Qgbm9ybWFsaXplZEV2ZW50TmFtZSA9IHRvU25ha2VDYXNlKGV2ZW50TmFtZSlcbiAgaWYgKCFub3JtYWxpemVkRXZlbnROYW1lKSByZXR1cm5cblxuICBjb25zdCBwYXlsb2FkID0gbm9ybWFsaXplUHJvcGVydGllcyhwcm9wZXJ0aWVzKVxuICBwYXlsb2FkLnNlc3Npb25faWQgPSBnZXRTZXNzaW9uSWQoKVxuXG4gIHRyeSB7XG4gICAgcG9zdGhvZy5jYXB0dXJlKG5vcm1hbGl6ZWRFdmVudE5hbWUsIHBheWxvYWQpXG4gIH0gY2F0Y2gge1xuICAgIC8vIG5vb3BcbiAgfVxuXG4gIHRyeSB7XG4gICAgU2VudHJ5LmFkZEJyZWFkY3J1bWIoe1xuICAgICAgY2F0ZWdvcnk6ICdhbmFseXRpY3MnLFxuICAgICAgbWVzc2FnZTogbm9ybWFsaXplZEV2ZW50TmFtZSxcbiAgICAgIGxldmVsOiAnaW5mbycsXG4gICAgICBkYXRhOiBwYXlsb2FkLFxuICAgIH0pXG4gIH0gY2F0Y2gge1xuICAgIC8vIG5vb3BcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY2FwdHVyZUVycm9yKGVycm9yOiB1bmtub3duLCBjb250ZXh0PzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pIHtcbiAgY29uc3Qgbm9ybWFsaXplZENvbnRleHQgPSBub3JtYWxpemVQcm9wZXJ0aWVzKGNvbnRleHQpXG4gIGNvbnN0IG5vcm1hbGl6ZWRFcnJvciA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvciA6IG5ldyBFcnJvcihTdHJpbmcoZXJyb3IgPz8gJ3Vua25vd25fZXJyb3InKSlcblxuICBjb25zdCBlcnJvclBheWxvYWQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgIC4uLm5vcm1hbGl6ZWRDb250ZXh0LFxuICAgIHNlc3Npb25faWQ6IGdldFNlc3Npb25JZCgpLFxuICAgIGVycm9yX25hbWU6IG5vcm1hbGl6ZWRFcnJvci5uYW1lLFxuICAgIGVycm9yX21lc3NhZ2U6IG5vcm1hbGl6ZWRFcnJvci5tZXNzYWdlLFxuICB9XG5cbiAgdHJ5IHtcbiAgICBwb3N0aG9nLmNhcHR1cmUoJ2Vycm9yX2NhcHR1cmVkJywgZXJyb3JQYXlsb2FkKVxuICB9IGNhdGNoIHtcbiAgICAvLyBub29wXG4gIH1cblxuICB0cnkge1xuICAgIFNlbnRyeS5jYXB0dXJlRXhjZXB0aW9uKG5vcm1hbGl6ZWRFcnJvciwge1xuICAgICAgZXh0cmE6IG5vcm1hbGl6ZWRDb250ZXh0LFxuICAgIH0pXG4gIH0gY2F0Y2gge1xuICAgIC8vIG5vb3BcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxZQUFZLFlBQVk7QUFDeEIsT0FBTyxhQUFhO0FBRXBCLE1BQU0seUJBQXlCO0FBRS9CLElBQUksa0JBQWlDO0FBRXJDLE1BQU0sY0FBYyxDQUFDLFVBQ25CLE1BQ0csS0FBSyxFQUNMLFFBQVEsc0JBQXNCLE9BQU8sRUFDckMsUUFBUSxXQUFXLEdBQUcsRUFDdEIsUUFBUSxrQkFBa0IsR0FBRyxFQUM3QixRQUFRLFVBQVUsR0FBRyxFQUNyQixRQUFRLFlBQVksRUFBRSxFQUN0QixZQUFZO0FBRWpCLE1BQU0sc0JBQXNCLENBQUMsZUFBeUM7QUFDcEUsUUFBTSxhQUFzQyxDQUFDO0FBQzdDLE1BQUksQ0FBQyxXQUFZLFFBQU87QUFFeEIsYUFBVyxDQUFDLEtBQUssS0FBSyxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDckQsZUFBVyxZQUFZLEdBQUcsQ0FBQyxJQUFJO0FBQUEsRUFDakM7QUFFQSxTQUFPO0FBQ1Q7QUFFQSxNQUFNLGtCQUFrQixNQUFNO0FBQzVCLE1BQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxPQUFPLGVBQWUsWUFBWTtBQUM1RSxXQUFPLE9BQU8sV0FBVztBQUFBLEVBQzNCO0FBRUEsU0FBTyxHQUFHLEtBQUssSUFBSSxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNqRTtBQUVBLE1BQU0sZUFBZSxNQUFNO0FBQ3pCLE1BQUksZ0JBQWlCLFFBQU87QUFDNUIsTUFBSSxPQUFPLFdBQVcsYUFBYTtBQUNqQyxzQkFBa0IsZ0JBQWdCO0FBQ2xDLFdBQU87QUFBQSxFQUNUO0FBRUEsTUFBSTtBQUNGLFVBQU0sWUFBWSxPQUFPLGFBQWEsUUFBUSxzQkFBc0I7QUFDcEUsUUFBSSxXQUFXO0FBQ2Isd0JBQWtCO0FBQ2xCLGFBQU87QUFBQSxJQUNUO0FBRUEsVUFBTSxZQUFZLGdCQUFnQjtBQUNsQyxXQUFPLGFBQWEsUUFBUSx3QkFBd0IsU0FBUztBQUM3RCxzQkFBa0I7QUFDbEIsV0FBTztBQUFBLEVBQ1QsUUFBUTtBQUNOLHNCQUFrQixnQkFBZ0I7QUFDbEMsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVPLGdCQUFTLGdCQUFnQjtBQUM5QixRQUFNLGFBQWEsWUFBWSxJQUFJO0FBQ25DLFFBQU0sY0FBYyxZQUFZLElBQUk7QUFDcEMsUUFBTSxZQUFZLFlBQVksSUFBSTtBQUNsQyxRQUFNLG9CQUFvQixZQUFZLElBQUk7QUFFMUMsTUFBSSxZQUFZO0FBQ2QsUUFBSTtBQUNGLGNBQVEsS0FBSyxZQUFZO0FBQUEsUUFDdkIsVUFBVSxlQUFlO0FBQUEsUUFDekIsaUJBQWlCO0FBQUEsUUFDakIsa0JBQWtCO0FBQUEsUUFDbEIsbUJBQW1CO0FBQUEsTUFDckIsQ0FBQztBQUFBLElBQ0gsUUFBUTtBQUFBLElBRVI7QUFBQSxFQUNGO0FBRUEsTUFBSSxXQUFXO0FBQ2IsUUFBSTtBQUNGLGFBQU8sS0FBSztBQUFBLFFBQ1YsS0FBSztBQUFBLFFBQ0wsYUFBYSxxQkFBcUI7QUFBQSxRQUNsQyxrQkFBa0I7QUFBQSxNQUNwQixDQUFDO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFDRjtBQUVPLGdCQUFTLGFBQWEsV0FBbUIsWUFBc0M7QUFDcEYsUUFBTSxzQkFBc0IsWUFBWSxTQUFTO0FBQ2pELE1BQUksQ0FBQyxvQkFBcUI7QUFFMUIsUUFBTSxVQUFVLG9CQUFvQixVQUFVO0FBQzlDLFVBQVEsYUFBYSxhQUFhO0FBRWxDLE1BQUk7QUFDRixZQUFRLFFBQVEscUJBQXFCLE9BQU87QUFBQSxFQUM5QyxRQUFRO0FBQUEsRUFFUjtBQUVBLE1BQUk7QUFDRixXQUFPLGNBQWM7QUFBQSxNQUNuQixVQUFVO0FBQUEsTUFDVixTQUFTO0FBQUEsTUFDVCxPQUFPO0FBQUEsTUFDUCxNQUFNO0FBQUEsSUFDUixDQUFDO0FBQUEsRUFDSCxRQUFRO0FBQUEsRUFFUjtBQUNGO0FBRU8sZ0JBQVMsYUFBYSxPQUFnQixTQUFtQztBQUM5RSxRQUFNLG9CQUFvQixvQkFBb0IsT0FBTztBQUNyRCxRQUFNLGtCQUFrQixpQkFBaUIsUUFBUSxRQUFRLElBQUksTUFBTSxPQUFPLFNBQVMsZUFBZSxDQUFDO0FBRW5HLFFBQU0sZUFBd0M7QUFBQSxJQUM1QyxHQUFHO0FBQUEsSUFDSCxZQUFZLGFBQWE7QUFBQSxJQUN6QixZQUFZLGdCQUFnQjtBQUFBLElBQzVCLGVBQWUsZ0JBQWdCO0FBQUEsRUFDakM7QUFFQSxNQUFJO0FBQ0YsWUFBUSxRQUFRLGtCQUFrQixZQUFZO0FBQUEsRUFDaEQsUUFBUTtBQUFBLEVBRVI7QUFFQSxNQUFJO0FBQ0YsV0FBTyxpQkFBaUIsaUJBQWlCO0FBQUEsTUFDdkMsT0FBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0gsUUFBUTtBQUFBLEVBRVI7QUFDRjsiLCJuYW1lcyI6W119